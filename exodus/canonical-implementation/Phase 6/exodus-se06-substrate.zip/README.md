# EXODUS · SE-06 Browser-Native Substrate

A single-file demonstration of the constraint substrate where the rendering
substrate (per SE-06) is the actual CSS cascade, not a CPU oracle. The
constraint compiler emits real CSS rules; resolution happens via
`setAttribute` + `getComputedStyle` on a probe DOM element. The execution
substrate (CT engine) is JS. They share the field. Delta is the coupling.

## To run

Open `exodus-se06-browser.html` in any modern browser. No server, no
dependencies, no build step. ASCII-only, single file, ~1880 lines.

## What's in view

Spec stack as of session end: DEFINITION v1.1, KERNEL v1.1, INVARIANTS v1.3,
SE-01 through SE-09 plus the algorithm catalog 02, 04, 05, 09, 10, 13, 14, 22.

Invariants honored: F1 (seed permanent), F2 (one delta formula at every
scope), F3 (no engine commands another), F4 (operation indefinite), F5
(observation irreversible), S1 (substrate shared), S2 (resolution
deterministic), S3 (no command path), M5 (trace at the channel), I3
(bounded everything), K1 (sub-cascades from fidelity), X1 (every
configuration includes the seed), O1 (observation read-only).

## Sections inside the file

The script is divided into 18 numbered sections with comments at each
boundary. Section 1 is configuration. Sections 2 through 6 set up
defenses, the field, delta, modulation, and trace. Section 7 is the
constraint compiler — the load-bearing piece that emits real CSS rules.
Section 8 is the ER engine. Sections 9 through 11 are the CT engine
including sub-cascade emergence and the main op cycle. Section 12 is
the VSF codec compatible with VSFGenerator_v1.3.html. Sections 13
through 18 are commit, nav, UI, frame loop, button wiring, and boot.

## What this file is

A Phase 6 candidate for the architecture's first browser-native SE-06
demonstration. The cascade is the resolver, not a CPU oracle running in
Node. CT-side change becomes ER-readable through edits to a shared
style element. No protocol between engines.

## What this file is not

A replacement for Phase 5. Phase 5's 115 passing tests and 22/22 GPU
bridge equivalence remain the production-grade verification. This is a
single artifact putting the cascade in the rendering-substrate role
SE-06 names, in a form anyone can open and inspect.

## Things to try

Type a few words and click TICK. Watch derived constraints accumulate
and the field-scalar delta drop. Repeat words across multiple TICKs and
watch the gap rise — once it crosses 0.12, predictive constraints
appear. If subsequent input matches a prediction's co-occurs pattern,
ratification fires in the right column. After enough varied input,
sub-cascades emerge in the middle column.

Change the probe coord with the nav controls while CT is idle and
watch the resolved record update in real time. That is the ER engine
ticking on its own clock — SE-06 substrate duality in observable form.

Commit a few coords, click EXPORT, then click IMPORT & VERIFY to
round-trip through the parser and re-resolve every row through the
cascade. The alert reports how many rows resolved byte-identical.
