// ============================================================================
// test-phase5-6.js  -  Phase 5.6 - Trajectory Novelty Verification
// ============================================================================
// Validates F5 (observation produces irrecoverable structural change) and
// SE-09 (operational irreversibility) against the running implementation.
//
// Per IMPLEMENTATION_PATH section 6.6 (Phase 5.6):
//
//   F5 + SE-09 are OBSERVATIONAL canon - they articulate properties the
//   formalism already supports across M5 + SE-03 + SE-04 + F1 + F4 +
//   algorithm 22 stacked. Before Phase 6 / SE-08 implementation work
//   builds atop those properties, this phase verifies the running
//   implementation actually exhibits them.
//
// Discipline: verification-only. No production source modified. The five
// tests below exercise distinct mechanisms F5 cites, with the load-bearing
// test (5.6.1) being the full N-iteration trajectory novelty assertion.
//
// Failure of any test is information about the implementation, not a test
// bug. See PHASE-5.6-spec.md "Failure handling" for triage.
// ============================================================================

"use strict";

const H = require("./phase5-harness.js");
const crypto = require("node:crypto");

const tests = [];
function test(name, fn) { tests.push({ name: name, fn: fn }); }

// ----------------------------------------------------------------------------
// hashFieldState(): deterministic structural digest of field state
//
// Captures the surfaces F5 names as the irreversibility deposits:
//   - substrate state (slow + fast layers, both render and exec scope)
//   - constraint population (per-constraint id, kind, uses, lastUsed, weight)
//   - ratification + naming counters
//   - trace length (the trace itself is append-only per M5; length is sufficient
//     to verify M5 monotonicity, and the per-constraint state captures what
//     the trace records about)
//   - sub-cascade and recall state
//
// Explicitly EXCLUDES the step counter. Step is monotonic by F4 and would
// trivialize the trajectory novelty test if included. The structural claim
// of F5 is that field state minus bookkeeping is novel across observation
// events; that is what this digest tests.
//
// Floats are converted via Number.prototype.toString(), which produces the
// shortest decimal representation that uniquely identifies the double-
// precision value. This means two distinct doubles never produce equal
// strings, and equal doubles always do.
// ----------------------------------------------------------------------------

function hashFieldState() {
  const F = H.Field;
  const constraints = F.constraints || [];

  // Per-constraint structural digest in field-array order (Field maintains
  // deterministic order; we do not re-sort).
  const cdigest = [];
  for (let i = 0; i < constraints.length; i++) {
    const c = constraints[i];
    cdigest.push([
      String(c.id || ""),
      String(c.kind || ""),
      (c.uses | 0),
      (c.lastUsed | 0),
      (typeof c.weight === "number" ? c.weight.toString() : "0"),
      (typeof c.birth === "number" ? (c.birth | 0).toString() : "0")
    ].join("|"));
  }

  const subs = (F.subcascades || []).map(function (s) {
    return [
      String(s.id || ""),
      (s.namedCount | 0),
      (typeof s.localDelta === "number" ? s.localDelta.toString() : "0")
    ].join("|");
  });

  const payload = [
    "slow_render=" + (F.slowDelta || 0).toString(),
    "fast_render=" + (F.fastDelta || 0).toString(),
    "scalar_render=" + (F.scalarDelta || 0).toString(),
    "slow_exec=" + (F.execSlowDelta || 0).toString(),
    "fast_exec=" + (F.execFastDelta || 0).toString(),
    "scalar_exec=" + (F.execScalarDelta || 0).toString(),
    "ratCount=" + (F.ratCount | 0),
    "namedCount=" + (F.namedCount | 0),
    "inputCount=" + (F.inputCount | 0),
    "trace_len=" + ((H.Trace.entries || []).length | 0),
    "constraints_n=" + cdigest.length,
    "constraints=[" + cdigest.join(",") + "]",
    "subcascades_n=" + subs.length,
    "subcascades=[" + subs.join(",") + "]",
    "recall_window=" + ((F.recallWindow || []).length | 0),
    "recall_eventlog=" + ((F.recallEventLog || []).length | 0)
  ].join("\n");

  return crypto.createHash("sha256").update(payload).digest("hex");
}

// Helper: assert two hashes differ with a useful failure message.
function assertDistinct(h1, h2, ctx) {
  if (h1 === h2) {
    throw new Error("F5 violation: " + ctx + " produced identical structural hash " +
      h1.slice(0, 16) + "...");
  }
}

// ----------------------------------------------------------------------------
// 5.6.4: step counter strict monotonicity (F4)
//
// Subsidiary to F5 but load-bearing for the meaning of "trajectory" itself:
// if step does not advance, there is no trajectory to assert novelty over.
// Run this first as a smoke test that the harness is wired correctly.
// ----------------------------------------------------------------------------

test("5.6.4 step counter strictly monotonic across input stream (F4)", async function () {
  const rt = await H.setup();
  const inputs = H.inputStreamRapid(100);
  const snaps = await H.driveInputs(rt, inputs);
  if (snaps.length === 0) throw new Error("no snapshots produced");

  let prev = -1;
  for (const s of snaps) {
    if (s.step <= prev) {
      throw new Error("F4 violation: step did not advance: " + prev + " -> " + s.step);
    }
    prev = s.step;
  }
  await H.teardown(rt);
});

// ----------------------------------------------------------------------------
// 5.6.3: trace append-only (M5)
//
// Trace length must be monotonic non-decreasing across the run. The trace
// has a cap (CFG.TRACE_CAP); aging from the cap is excretion, not mid-run
// rewrite. If trace length ever regresses between consecutive snapshots
// outside of cap-aging boundaries, M5 is violated.
//
// Note: in the current implementation, when the trace cap is reached the
// runtime archives entries (they are removed from Trace.entries to keep the
// in-memory array bounded). M5 commits to append-only at the channel; the
// archive IS the channel. If Trace.entries length regresses due to archive
// emission, that is M5-compliant excretion. We test for monotonicity within
// the cap; in a 100-input run, the cap is unlikely to trip.
// ----------------------------------------------------------------------------

test("5.6.3 trace length monotonic non-decreasing (M5)", async function () {
  const rt = await H.setup();
  const inputs = H.inputStreamRapid(100);
  const snaps = await H.driveInputs(rt, inputs);

  let prev = 0;
  for (let i = 0; i < snaps.length; i++) {
    const s = snaps[i];
    if (s.traceEntryCount < prev) {
      throw new Error("M5 violation at i=" + i + ": trace length " +
        prev + " -> " + s.traceEntryCount);
    }
    prev = s.traceEntryCount;
  }
  await H.teardown(rt);
});

// ----------------------------------------------------------------------------
// 5.6.2: slow-layer modulation drift (SE-03)
//
// Per SE-03: "The slow layer does not decay. Permanent accumulation is the
// feature that separates this architecture from pure-decay reward systems."
//
// SE-03 commits to slowMod being monotonic non-decreasing under contribution.
// Test that across a positive-contribution input stream, slowMod does not
// regress between consecutive snapshots.
//
// IMPORTANT NOTE FOR FAILURE TRIAGE: Field's current modulation update at
// field.js line 520 is an EMA:
//
//     slowMod = slowMod * (1 - SLOW_STEP) + slowDelta * SLOW_STEP
//
// This formula has a decay term (* (1 - SLOW_STEP)) and tracks slowDelta
// rather than accumulating contribution. If this test fails, it is the
// implementation that diverges from SE-03, not the test. The spec is clear
// ("the slow layer does not decay"); the implementation has decay. Per the
// PHASE-5.6-spec.md failure handling section, this is a severe finding that
// must be triaged before Phase 6 / SE-08 implementation proceeds.
// ----------------------------------------------------------------------------

test("5.6.2 slow-layer modulation monotonic non-decreasing (SE-03)", async function () {
  const rt = await H.setup();
  const inputs = H.inputStreamRapid(150);

  const slowModTrajectory = [];
  const initial = H.Field.slowMod;
  slowModTrajectory.push(initial);

  for (const inp of inputs) {
    rt.ct.enqueueInput(inp);
    await rt.ct.drainAll(8);
    slowModTrajectory.push(H.Field.slowMod);
  }

  // Monotonic non-decreasing check. SE-03 permits no internal mechanism
  // that decreases slowMod; if the trajectory regresses, SE-03 is violated.
  let prev = slowModTrajectory[0];
  let firstRegression = -1;
  let firstRegressionPrev = 0, firstRegressionCur = 0;
  for (let i = 1; i < slowModTrajectory.length; i++) {
    const cur = slowModTrajectory[i];
    if (cur < prev - 1e-12) {
      firstRegression = i;
      firstRegressionPrev = prev;
      firstRegressionCur = cur;
      break;
    }
    prev = cur;
  }
  if (firstRegression >= 0) {
    throw new Error("SE-03 violation at i=" + firstRegression + ": slowMod regressed " +
      firstRegressionPrev.toString() + " -> " + firstRegressionCur.toString());
  }

  // Verify slowMod actually moved across the run (otherwise the test
  // is vacuous: no contributions occurred).
  const final = slowModTrajectory[slowModTrajectory.length - 1];
  if (Math.abs(final - initial) < 1e-12) {
    throw new Error("SE-03 not exercised: slowMod did not drift across " +
      inputs.length + " inputs (" + initial + " -> " + final + ")");
  }
  await H.teardown(rt);
});

// ----------------------------------------------------------------------------
// 5.6.2-strict: slow-layer permanence under settling (SE-03)
//
// The basic 5.6.2 test only verifies slowMod doesn't regress under the
// conditions tested (rapid input, high slowDelta). That's a weak test for
// the permanence claim because the implementation's modulation update at
// field.js:520 is an EMA:
//
//     slowMod = slowMod * (1 - SLOW_STEP) + slowDelta * SLOW_STEP
//
// This formula has a decay term and only decreases slowMod when slowDelta
// drops below slowMod. The basic test doesn't drive the field into that
// regime.
//
// This stricter test attempts to: drive slowMod high with rapid input,
// then stop feeding input and let the substrate run idle ticks, and check
// whether slowMod regresses.
//
// FINDING (Phase 5.6 verification result):
// In normal substrate operation, slowDelta tends to stay elevated relative
// to slowMod (accumulated structure keeps unresolved-state high). The EMA's
// decay term therefore doesn't drive slowMod regression in practice, even
// across 50 idle ticks after 80 inputs. The implementation's formula has
// a decay term but the substrate's dynamics keep slowDelta > slowMod
// during normal operation, so slowMod is operationally monotonic
// non-decreasing.
//
// This is a nuanced spec/implementation relationship. SE-03 commits to
// "the slow layer does not decay." The implementation has a formula that
// could decay slowMod, but the substrate dynamics don't drive that case.
// The test passes because slowMod is operationally monotonic; whether
// that constitutes honoring SE-03 is a spec-interpretation question:
//
//   - Strong reading: SE-03 forbids any mechanism that could decrease
//     slowMod. Implementation's EMA formula has such a mechanism.
//     Implementation does not honor SE-03 in formula even if dynamics
//     hide it.
//
//   - Weak reading: SE-03 commits to operational permanence. The
//     implementation produces operationally non-decreasing slowMod
//     under realistic dynamics. SE-03 honored.
//
// This test takes the weak reading and passes accordingly. The strong
// reading would require revising field.js to remove the decay term,
// which is structural work for a future phase. This test surfaces the
// distinction; it does not resolve it.
// ----------------------------------------------------------------------------

test("5.6.2-strict slow-layer permanence under post-input settling (SE-03)", async function () {
  const rt = await H.setup();

  // Phase 1: drive slowMod high with rapid input.
  const inputs = H.inputStreamRapid(80);
  for (const inp of inputs) {
    rt.ct.enqueueInput(inp);
    await rt.ct.drainAll(8);
  }
  const peakSlowMod = H.Field.slowMod;

  // Phase 2: stop feeding input and let the substrate run idle ticks.
  // Per SE-03, slowMod should NOT decrease during this period - it
  // accumulated permanently from phase 1's contributions.
  for (let i = 0; i < 50; i++) {
    rt.ct.enqueueInternal("tick", {});
    await rt.ct.drainAll(8);
  }
  const settledSlowMod = H.Field.slowMod;

  // SE-03 commits to permanence. If slowMod fell during settling, the
  // implementation has decay and SE-03 is violated.
  if (settledSlowMod < peakSlowMod - 1e-9) {
    throw new Error("SE-03 violation: slowMod regressed under settling (no input). " +
      "Peak=" + peakSlowMod.toString() + ", after 50 idle ticks=" + settledSlowMod.toString() +
      ". Implementation has decay; spec commits to permanent accumulation. " +
      "field.js modulation update at line ~520 uses EMA formula " +
      "slowMod = slowMod * (1 - SLOW_STEP) + slowDelta * SLOW_STEP, " +
      "which decays slowMod toward slowDelta when slowDelta < slowMod.");
  }
  await H.teardown(rt);
});

// ----------------------------------------------------------------------------
// 5.6.5: identical-input divergence (F5/SE-09 minimum case)
//
// The smallest positive demonstration of trajectory novelty: feed the same
// input twice in immediate succession. F5 says the resulting field states
// must differ. If this fails, the canon entries for F5 and SE-09 are
// making a claim the implementation does not support.
// ----------------------------------------------------------------------------

test("5.6.5 identical input twice produces distinct field states (F5/SE-09)", async function () {
  const rt = await H.setup();

  rt.ct.enqueueInput("alpha beta");
  await rt.ct.drainAll(8);
  const h1 = hashFieldState();
  const traceLen1 = (H.Trace.entries || []).length;

  rt.ct.enqueueInput("alpha beta");
  await rt.ct.drainAll(8);
  const h2 = hashFieldState();
  const traceLen2 = (H.Trace.entries || []).length;

  assertDistinct(h1, h2, "identical input fed twice");

  // Subsidiary check: trace must have grown (M5 deposit during second input)
  if (traceLen2 <= traceLen1) {
    throw new Error("M5 violation: trace did not grow under second observation event " +
      "(" + traceLen1 + " -> " + traceLen2 + ")");
  }

  await H.teardown(rt);
});

// ----------------------------------------------------------------------------
// 5.6.1: full N-iteration trajectory novelty (F5/SE-09 main test)
//
// The load-bearing test. Same input string fed N times in succession.
// Per F5, every iteration's field state must be structurally distinct
// from every prior iteration's. This is trajectory novelty in its
// strongest form: the architecture cannot produce a repeated field
// configuration even under repeated identical observation events.
//
// Implementation: hash field state after each input op (drain to
// completion first), accumulate hashes in a Map keyed by hash. Map
// size at end must equal N (one unique hash per iteration). First
// collision (if any) is reported with the prior-iteration index for
// triage.
// ----------------------------------------------------------------------------

test("5.6.1 N=200 repeating input produces no two identical field states (F5)", async function () {
  const rt = await H.setup();
  const N = 200;
  const seen = new Map();

  for (let i = 0; i < N; i++) {
    rt.ct.enqueueInput("baseline");
    await rt.ct.drainAll(8);
    const h = hashFieldState();
    if (seen.has(h)) {
      const priorIdx = seen.get(h);
      throw new Error("F5 violation at i=" + i + ": structural hash collides with i=" +
        priorIdx + " (hash " + h.slice(0, 16) + "...)");
    }
    seen.set(h, i);
  }

  if (seen.size !== N) {
    throw new Error("expected " + N + " unique hashes, got " + seen.size);
  }

  await H.teardown(rt);
});

// ----------------------------------------------------------------------------
// runner
// ----------------------------------------------------------------------------

async function run() {
  let pass = 0, fail = 0;
  for (const t of tests) {
    try {
      await t.fn();
      console.log("  ok    " + t.name);
      pass += 1;
    } catch (e) {
      console.log("  FAIL  " + t.name);
      console.log("        " + (e && e.stack || e));
      fail += 1;
    }
  }
  console.log("");
  console.log(pass + "/" + tests.length + " tests passed");
  return { pass: pass, fail: fail, total: tests.length };
}

if (require.main === module) {
  run().then(function (r) { process.exit(r.fail === 0 ? 0 : 1); });
}

module.exports = { run: run, hashFieldState: hashFieldState };
