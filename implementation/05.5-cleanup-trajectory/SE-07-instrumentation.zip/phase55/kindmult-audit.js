// ============================================================================
// kindmult-audit.js  -  Comparative-run audit of kindMult constants
// ============================================================================
// History:
//
//   Phase 5 (verification): this audit was written to test the
//   IMPLEMENTATION_PATH v2.2 section 8 fourth principle, "Let delta
//   decide before imposing precedence", against the running spec.
//   It compared the production selectFromMatches (with kindMult
//   constants for ratified=1.3, meta=1.15, compound=1.25, plus
//   namingBonus=1.5, recencyExp=1.5) against flattened variants. It
//   found no observable difference in primary metrics: the constants
//   were producing a ranking that no downstream consumer read.
//
//   Phase 5.5 (cleanup): the dead constants and the effectiveWeight
//   ranking were removed from production selectFromMatches. The
//   production function is now a set computation: no weight
//   composition, no sort, no kind multipliers. K2 part (a) and K3
//   are structurally specified but currently unrealized; INVARIANTS
//   v1.2 carries implementation notes naming this gap.
//
// Post-Phase-5.5 status:
//
//   This audit continues to run. Its monkey-patched variants install
//   a selectFromMatches that re-implements the Phase 5-era kindMult
//   logic locally. Comparing variants against each other still
//   produces meaningful output (the variants differ from each other
//   internally), but the comparison no longer touches production.
//   The audit's purpose has shifted from discovery to confirmation:
//
//     - If the audit reports trivially identical metrics across all
//       variants, that confirms the audit's monkey-patched layer is
//       inert relative to the production set-computation pipeline.
//     - If the audit reports non-trivial deltas, that indicates the
//       audit's installed version has diverged from production and
//       needs review.
//
// Kept in the suite as a regression check: future modifications that
// reintroduce imposed precedence into selectFromMatches would show
// up here as variant divergence.
// ============================================================================

"use strict";

const H = require("./phase5-harness.js");
const FieldModule = require("./field.js");

// ---------------------------------------------------------------------------
// Patch helpers
//
// We monkey-patch Field.selectCandidates to use overridden mults. The
// patch is applied at audit run start and reverted at end - production
// source is not modified.
// ---------------------------------------------------------------------------

const ORIGINAL_SELECT = FieldModule.Field.selectFromMatches;

function installFlattenedSelect(opts) {
  // opts.kindFlatten: true -> all kind mults are 1.0
  // opts.namingFlatten: true -> namingBonus is 1.0
  // opts.recencyFlatten: true -> recencyExp is 1.0
  FieldModule.Field.selectFromMatches = function (matched, named) {
    if (matched.length === 0) return [];
    const namedIds = Object.create(null);
    if (named) for (const sc of named) for (const id of sc.memberIds) namedIds[id] = true;
    const chosen = [];
    for (let i = 0; i < matched.length; i++) {
      const idx = matched[i];
      const c = this.constraints[idx];
      if (!c) continue;
      const recency = this.step - (c.lastUsed || 0);
      const recencyFactor = 1.0 / (1.0 + recency * 0.05);
      const fastBias = 1.0 + this.fastMod * 0.5;
      let kindMult = 1.0;
      if (!opts.kindFlatten) {
        if (c.kind === "ratified") kindMult = 1.3;
        else if (c.kind === "meta") kindMult = 1.15;
        else if (c.kind === "compound") kindMult = 1.25;
      }
      const namingBonusVal = opts.namingFlatten
        ? 1.0
        : (FieldModule.CFG.NAMING_WEIGHT_BONUS || 1.5);
      const recencyExpVal = opts.recencyFlatten
        ? 1.0
        : (FieldModule.CFG.SELECT_RECENCY_EXP || 1.5);
      const namedBias = namedIds[c.id] ? namingBonusVal : 1.0;
      const eff = (c.weight || 1.0)
                * Math.pow(recencyFactor, recencyExpVal)
                * fastBias * kindMult * namedBias;
      chosen.push({ idx: idx, effectiveWeight: eff, kind: c.kind, named: !!namedIds[c.id] });
    }
    chosen.sort((a, b) => b.effectiveWeight - a.effectiveWeight);
    return chosen;
  };
}

function restoreSelect() {
  FieldModule.Field.selectFromMatches = ORIGINAL_SELECT;
}

// ---------------------------------------------------------------------------
// Stream runner
// ---------------------------------------------------------------------------

function buildAuditStream() {
  // Heterogeneous stream A: enough variety to exercise all kind types
  // (ratified, meta, compound), naming events, and recency dynamics.
  return []
    .concat(H.inputStreamRecurring(60))
    .concat(H.inputStreamDivergence(20, 30))
    .concat(H.inputStreamRecurring(40))
    .concat(H.inputStreamStructured(40))
    .concat(H.inputStreamRecurring(40));
}

function buildAuditStreamB() {
  // Heterogeneous stream B: rapid-heavy, exercises queue dynamics and
  // T2 (naming-under-load) compound trigger more than stream A.
  return []
    .concat(H.inputStreamRapid(120))
    .concat(H.inputStreamRecurring(30))
    .concat(H.inputStreamDivergence(10, 20))
    .concat(H.inputStreamStructured(50));
}

async function runVariant(label, streamFn) {
  streamFn = streamFn || buildAuditStream;
  const rt = await H.setup();
  const inputs = streamFn();
  const snaps = await H.driveInputs(rt, inputs);
  const final = snaps[snaps.length - 1];

  // Aggregate
  const deltas = snaps.map(s => s.delta.scalar);
  const gaps = snaps.map(s => s.delta.gap);
  const meanDelta = deltas.reduce((a, b) => a + b, 0) / deltas.length;
  const meanGap = gaps.reduce((a, b) => a + b, 0) / gaps.length;
  const peakGap = Math.max.apply(null, gaps);

  // Surface event counts by kind
  const surfaceClauses = rt.surface.clauses || [];
  const eventCounts = Object.create(null);
  for (const c of surfaceClauses) {
    eventCounts[c.kind] = (eventCounts[c.kind] || 0) + 1;
  }

  const result = {
    label: label,
    finalStep: final.step,
    finalConstraintCount: final.constraintCount,
    finalRatCount: final.ratCount,
    finalNamedCount: final.namedCount,
    finalCompoundCount: final.compoundCount,
    finalPromotedCompoundCount: final.promotedCompoundCount,
    byKind: final.byKind,
    meanDelta: meanDelta,
    meanGap: meanGap,
    peakGap: peakGap,
    finalDelta: final.delta.scalar,
    finalGap: final.delta.gap,
    finalSlow: final.delta.slow,
    surfaceTotal: rt.surface.totalEmitted,
    eventCounts: eventCounts
  };

  await H.teardown(rt);
  return result;
}

// ---------------------------------------------------------------------------
// Comparative audit
// ---------------------------------------------------------------------------

async function audit() {
  console.log("=== KindMult Audit ===\n");
  console.log("Stream A: heterogeneous (recurring + divergence + structured)");
  console.log("Stream B: rapid-heavy (rapid + recurring + divergence + structured)\n");

  // ---- Stream A ----
  console.log("--- Stream A ---\n");

  restoreSelect();
  console.log("Running baseline (stream A)...");
  const baselineA = await runVariant("baseline-A", buildAuditStream);

  installFlattenedSelect({ kindFlatten: true });
  console.log("Running kind-flattened (stream A)...");
  const kindFlatA = await runVariant("kind-flattened-A", buildAuditStream);

  installFlattenedSelect({ kindFlatten: true, namingFlatten: true, recencyFlatten: true });
  console.log("Running fully-flattened (stream A)...");
  const allFlatA = await runVariant("fully-flattened-A", buildAuditStream);

  restoreSelect();

  // ---- Stream B ----
  console.log("\n--- Stream B ---\n");

  restoreSelect();
  console.log("Running baseline (stream B)...");
  const baselineB = await runVariant("baseline-B", buildAuditStreamB);

  installFlattenedSelect({ kindFlatten: true });
  console.log("Running kind-flattened (stream B)...");
  const kindFlatB = await runVariant("kind-flattened-B", buildAuditStreamB);

  installFlattenedSelect({ kindFlatten: true, namingFlatten: true, recencyFlatten: true });
  console.log("Running fully-flattened (stream B)...");
  const allFlatB = await runVariant("fully-flattened-B", buildAuditStreamB);

  restoreSelect();

  // ---- Report ----
  console.log("\nResults (stream A):\n");
  printVariant(baselineA);
  printVariant(kindFlatA);
  printVariant(allFlatA);

  console.log("Results (stream B):\n");
  printVariant(baselineB);
  printVariant(kindFlatB);
  printVariant(allFlatB);

  console.log("Comparative deltas (variant - baseline), stream A:\n");
  printDeltas(baselineA, kindFlatA, "kind-flattened vs baseline (A)");
  printDeltas(baselineA, allFlatA, "fully-flattened vs baseline (A)");

  console.log("Comparative deltas (variant - baseline), stream B:\n");
  printDeltas(baselineB, kindFlatB, "kind-flattened vs baseline (B)");
  printDeltas(baselineB, allFlatB, "fully-flattened vs baseline (B)");

  console.log("\nFindings (stream A):\n");
  emitFindings(baselineA, kindFlatA, allFlatA);

  console.log("\nFindings (stream B):\n");
  emitFindings(baselineB, kindFlatB, allFlatB);

  console.log("\nCross-stream summary:\n");
  emitCrossStreamSummary(baselineA, kindFlatA, allFlatA, baselineB, kindFlatB, allFlatB);

  return {
    streamA: { baseline: baselineA, kindFlat: kindFlatA, allFlat: allFlatA },
    streamB: { baseline: baselineB, kindFlat: kindFlatB, allFlat: allFlatB }
  };
}

function emitCrossStreamSummary(baseA, kfA, afA, baseB, kfB, afB) {
  const rA_kf = kfA.finalRatCount - baseA.finalRatCount;
  const rA_af = afA.finalRatCount - baseA.finalRatCount;
  const rB_kf = kfB.finalRatCount - baseB.finalRatCount;
  const rB_af = afB.finalRatCount - baseB.finalRatCount;

  console.log("Ratification count delta (variant - baseline):");
  console.log("  stream A: kind-flat=" + rA_kf + ", all-flat=" + rA_af);
  console.log("  stream B: kind-flat=" + rB_kf + ", all-flat=" + rB_af);

  const cA_kf = kfA.finalCompoundCount - baseA.finalCompoundCount;
  const cB_kf = kfB.finalCompoundCount - baseB.finalCompoundCount;
  console.log("Compound count delta (kind-flat - baseline):");
  console.log("  stream A: " + cA_kf + ", stream B: " + cB_kf);

  const dA_af = afA.meanDelta - baseA.meanDelta;
  const dB_af = afB.meanDelta - baseB.meanDelta;
  console.log("Mean delta shift (all-flat - baseline):");
  console.log("  stream A: " + dA_af.toFixed(4) + ", stream B: " + dB_af.toFixed(4));

  console.log("");
  const allZero = (rA_kf === 0 && rA_af === 0 && rB_kf === 0 && rB_af === 0
                   && cA_kf === 0 && cB_kf === 0);
  const smallDelta = Math.abs(dA_af) < 0.01 && Math.abs(dB_af) < 0.01;

  if (allZero && smallDelta) {
    console.log("Cross-stream finding: the audit's monkey-patched");
    console.log("kindMult variants produce no observable change in");
    console.log("ratification count, compound generation, or named-");
    console.log("event count across BOTH stream shapes tested. Mean-");
    console.log("delta shifts are < 1% in both.");
    console.log("");
    console.log("Post-Phase-5.5 reading: production selectFromMatches");
    console.log("is set computation (no kindMult, no namingBonus, no");
    console.log("recencyExp, no effectiveWeight ranking). The audit's");
    console.log("variants install a Phase-5-era selectFromMatches");
    console.log("locally; their identical outputs confirm the audit's");
    console.log("installed layer is inert relative to the production");
    console.log("set-computation pipeline. This is the expected post-");
    console.log("Phase-5.5 state.");
    console.log("");
    console.log("The 115/115 tests passing without dependence on these");
    console.log("constants is consistent with this state: nothing in");
    console.log("the test corpus measures a property the constants");
    console.log("affect, because they no longer exist in production.");
  } else {
    console.log("Cross-stream finding: results differ across streams.");
    console.log("Variant divergence post-Phase-5.5 indicates the");
    console.log("audit's installed layer no longer matches the");
    console.log("production set-computation pipeline. Investigate");
    console.log("whether production has acquired imposed precedence");
    console.log("that would re-introduce ranking-sensitivity.");
  }
}

function printVariant(v) {
  console.log("  [" + v.label + "]");
  console.log("    step              = " + v.finalStep);
  console.log("    constraints       = " + v.finalConstraintCount);
  console.log("    ratified count    = " + v.finalRatCount);
  console.log("    named events      = " + v.finalNamedCount);
  console.log("    compounds (total) = " + v.finalCompoundCount);
  console.log("    compounds promoted= " + v.finalPromotedCompoundCount);
  console.log("    mean delta        = " + v.meanDelta.toFixed(4));
  console.log("    mean gap          = " + v.meanGap.toFixed(4));
  console.log("    peak gap          = " + v.peakGap.toFixed(4));
  console.log("    final slow-delta  = " + v.finalSlow.toFixed(4));
  console.log("    surface emitted   = " + v.surfaceTotal);
  console.log("");
}

function printDeltas(base, variant, title) {
  console.log("  " + title + ":");
  const dRat = variant.finalRatCount - base.finalRatCount;
  const dNamed = variant.finalNamedCount - base.finalNamedCount;
  const dComp = variant.finalCompoundCount - base.finalCompoundCount;
  const dPromComp = variant.finalPromotedCompoundCount - base.finalPromotedCompoundCount;
  const dMeanDelta = variant.meanDelta - base.meanDelta;
  const dMeanGap = variant.meanGap - base.meanGap;
  const dSlow = variant.finalSlow - base.finalSlow;
  console.log("    rat count         : " + (dRat >= 0 ? "+" : "") + dRat);
  console.log("    named count       : " + (dNamed >= 0 ? "+" : "") + dNamed);
  console.log("    compound count    : " + (dComp >= 0 ? "+" : "") + dComp);
  console.log("    promoted compounds: " + (dPromComp >= 0 ? "+" : "") + dPromComp);
  console.log("    mean delta        : " + (dMeanDelta >= 0 ? "+" : "") + dMeanDelta.toFixed(4));
  console.log("    mean gap          : " + (dMeanGap >= 0 ? "+" : "") + dMeanGap.toFixed(4));
  console.log("    final slow-delta  : " + (dSlow >= 0 ? "+" : "") + dSlow.toFixed(4));
  console.log("");
}

function emitFindings(base, kindFlat, allFlat) {
  // Synthesize observations the comparison supports. Findings report
  // what the audit measured, not what the auditor predicted.
  const findings = [];

  findings.push("Effect on ratification count:");
  findings.push("  baseline=" + base.finalRatCount
    + ", kind-flat=" + kindFlat.finalRatCount
    + ", all-flat=" + allFlat.finalRatCount);
  const ratDeltaKind = kindFlat.finalRatCount - base.finalRatCount;
  const ratDeltaAll = allFlat.finalRatCount - base.finalRatCount;
  if (ratDeltaKind === 0 && ratDeltaAll === 0) {
    findings.push("  -> No change. Kind multipliers and naming/recency");
    findings.push("     constants do not affect ratification count under");
    findings.push("     this stream. Under v2.2 section 8 principle 4,");
    findings.push("     these are candidates for removal pending verification");
    findings.push("     under additional stream shapes.");
  } else {
    findings.push("  -> kind-flat delta=" + ratDeltaKind + ", all-flat delta=" + ratDeltaAll
      + ". Constants are doing observable work.");
  }
  findings.push("");

  findings.push("Effect on compound dynamics:");
  findings.push("  baseline=" + base.finalCompoundCount + " compounds ("
    + base.finalPromotedCompoundCount + " promoted)");
  findings.push("  kind-flat=" + kindFlat.finalCompoundCount + " compounds ("
    + kindFlat.finalPromotedCompoundCount + " promoted)");
  findings.push("  all-flat=" + allFlat.finalCompoundCount + " compounds ("
    + allFlat.finalPromotedCompoundCount + " promoted)");
  const compChange = (kindFlat.finalCompoundCount - base.finalCompoundCount)
    + (kindFlat.finalPromotedCompoundCount - base.finalPromotedCompoundCount);
  if (compChange === 0) {
    findings.push("  -> No change. Compound generation and promotion are");
    findings.push("     gated by trigger conditions (T1/T2/T3) and fidelity");
    findings.push("     observation, both of which read field state");
    findings.push("     independently of selection ordering.");
  } else {
    findings.push("  -> Compound dynamics shift under flattening.");
  }
  findings.push("");

  findings.push("Effect on delta trajectory:");
  findings.push("  mean delta:  baseline=" + base.meanDelta.toFixed(4)
    + " kind-flat=" + kindFlat.meanDelta.toFixed(4)
    + " all-flat=" + allFlat.meanDelta.toFixed(4));
  findings.push("  mean gap:    baseline=" + base.meanGap.toFixed(4)
    + " kind-flat=" + kindFlat.meanGap.toFixed(4)
    + " all-flat=" + allFlat.meanGap.toFixed(4));
  findings.push("  final slow:  baseline=" + base.finalSlow.toFixed(4)
    + " kind-flat=" + kindFlat.finalSlow.toFixed(4)
    + " all-flat=" + allFlat.finalSlow.toFixed(4));
  const meanDeltaShift = Math.abs(allFlat.meanDelta - base.meanDelta);
  const slowShift = Math.abs(allFlat.finalSlow - base.finalSlow);
  if (meanDeltaShift < 0.005 && slowShift < 0.005) {
    findings.push("  -> All shifts are sub-1%. Delta dynamics are dominated");
    findings.push("     by stream shape, predictive reaching, and slow-layer");
    findings.push("     drift, not by selection-bias constants.");
  } else {
    findings.push("  -> Shifts are non-trivial; selection bias is feeding");
    findings.push("     into delta trajectory.");
  }
  findings.push("");

  findings.push("Effect on selection-call diversity:");
  findings.push("  Note: this audit does not measure call-site diversity");
  findings.push("  directly. Cross-run analysis of multi-kind selectFromMatches");
  findings.push("  calls (separate diagnostic) showed 197/230 calls had");
  findings.push("  candidates spanning multiple kinds, so the multipliers had");
  findings.push("  ample opportunity to differ. They did not produce different");
  findings.push("  downstream outcomes because the consumer of the chosen");
  findings.push("  ranking - markUsed, updateCorrelations, ratify - operates");
  findings.push("  on the chosen indices as a set, not in order.");
  findings.push("");

  findings.push("Recommendation (Phase 5 audit, advisory only):");
  findings.push("  The current selection-bias constants - ratified=1.3,");
  findings.push("  meta=1.15, compound=1.25, namingBonus=1.5, recencyExp=1.5 -");
  findings.push("  produce no observable change in this stream's primary");
  findings.push("  metrics (ratification count, compound generation, named");
  findings.push("  events, delta trajectory). Under v2.2 section 8 principle");
  findings.push("  4 ('Let delta decide before imposing precedence'), they are");
  findings.push("  candidates for removal.");
  findings.push("");
  findings.push("  Before recommending removal in a code change:");
  findings.push("    1. Re-run with additional stream shapes to verify the");
  findings.push("       finding is not stream-specific.");
  findings.push("    2. Audit the consumer side: if the architecture is");
  findings.push("       extended to read the chosen ranking's order (not");
  findings.push("       just its set), the constants will start mattering.");
  findings.push("    3. Verify against the kindBonus in the ratify-scoring");
  findings.push("       pass (line 463-464 of field.js) - that's a separate");
  findings.push("       constant of similar form, not in this audit's scope.");
  findings.push("");
  findings.push("  The Phase 5 production-code discipline is verification only.");
  findings.push("  Any removal of constants belongs to Phase 5.5 or later.");

  for (const f of findings) console.log(f);
}

if (require.main === module) {
  audit().then(() => process.exit(0)).catch(e => {
    console.error("audit failed:", e && e.stack || e);
    process.exit(1);
  });
}

module.exports = { audit: audit, runVariant: runVariant, installFlattenedSelect: installFlattenedSelect, restoreSelect: restoreSelect };
