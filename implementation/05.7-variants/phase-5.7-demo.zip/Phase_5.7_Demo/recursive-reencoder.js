// ============================================================================
// recursive-reencoder.js  -  Re-encode substrate output as bytes for re-feed
// ============================================================================
//
// Cascade-intake reads Layer N's output node and produces TOKENS for Layer N+1.
// This module reads Layer N's output node and produces BYTES that can be
// fed back into Layer N (or Layer 1) as if they were external sensor input.
//
// Why bytes and not tokens? Because the recursive coupling test asks:
// what happens when upstream's settled state arrives back at Layer 1 in the
// same form Layer 1 originally saw the input - as a binary stream?
//
// The substrate's intake doesn't care where bytes came from; binary-intake.js
// processes them identically. So re-encoded upstream bytes interleaved with
// or appended to original input produce a closed-loop signal: input ->
// settle -> re-encode -> input.
//
// Encoding scheme:
//
// We define a deterministic mapping from substrate output properties to
// bytes. The mapping must be:
//   1. Deterministic: same output node produces same bytes every time
//   2. Bounded: produces a fixed number of bytes for a given configuration
//   3. Distinct from raw WASM bytes in distribution: re-encoded bytes
//      should occupy a distinguishable region of byte space so Layer 1
//      can settle around the (raw, re-encoded) joint distribution
//
// Choice: each scalar substrate property gets a 4-byte block:
//   [marker_byte, value_msb, value_lsb, separator]
//
// Marker bytes are chosen from 0xC0-0xFF (high-bit, infrequent in WASM
// headers). Each property has a unique marker. Value is a 16-bit
// quantization of the property value. Separator is 0xFF.
//
// Per-constraint slots get a 5-byte block:
//   [c_marker, slot_idx, kind_code, weight_byte, uses_byte]
//
// Per-subcascade slots get a 4-byte block:
//   [s_marker, slot_idx, named_byte, delta_byte]
//
// The total byte stream is bounded and deterministic.
//
// ============================================================================

"use strict";

// ----------------------------------------------------------------------------
// Marker bytes - chosen from high-bit space to be distinguishable from
// typical WASM bytes in the 0x00-0x7F range
// ----------------------------------------------------------------------------

const MARKER = Object.freeze({
  SCALAR_DELTA:  0xC0,
  FAST_DELTA:    0xC1,
  SLOW_DELTA:    0xC2,
  FAST_MOD:      0xC3,
  SLOW_MOD:      0xC4,
  CONSTRAINT:    0xC8,    // followed by slot+kind+weight+uses
  SUBCASCADE:    0xC9,    // followed by slot+named+delta
  KIND_COUNT:    0xCA,    // followed by kind-code, count
  STEP:          0xCB,
  CONSTRAINT_CT: 0xCC,
  SUBCASCADE_CT: 0xCD,
  SEPARATOR:     0xFF
});

const KIND_CODE = Object.freeze({
  seed:       0x10,
  derived:    0x11,
  predictive: 0x12,
  meta:       0x13,
  compound:   0x14,
  ratified:   0x15,
  unknown:    0x1F
});

// ----------------------------------------------------------------------------
// Quantizers: float -> byte (or 2 bytes)
// ----------------------------------------------------------------------------

function quantizeScalar01(v) {
  // [0, 1] -> 0..255
  v = +v;
  if (!isFinite(v)) return 0;
  if (v < 0) v = 0; else if (v > 1) v = 1;
  return Math.floor(v * 255) & 0xFF;
}

function quantizeSigned(v) {
  // [-1, 1] -> 0..255 with 0 at midpoint
  v = +v;
  if (!isFinite(v)) return 128;
  if (v < -1) v = -1; else if (v > 1) v = 1;
  return Math.floor((v + 1) * 127.5) & 0xFF;
}

function quantizeWeight(w) {
  // weight is typically 1.0..2.0; quantize over that range
  w = +w;
  if (!isFinite(w)) return 0;
  if (w < 1) w = 1; else if (w > 2) w = 2;
  return Math.floor((w - 1) * 255) & 0xFF;
}

function quantizeUses(u) {
  // uses can be unbounded; cap at 255
  u = (u | 0);
  if (u < 0) return 0;
  if (u > 255) return 255;
  return u;
}

function quantizeCount(n) {
  // population count; cap at 255
  n = (n | 0);
  if (n < 0) return 0;
  if (n > 255) return 255;
  return n;
}

function kindCodeOf(kind) {
  return KIND_CODE[kind] !== undefined ? KIND_CODE[kind] : KIND_CODE.unknown;
}

// ----------------------------------------------------------------------------
// reencode(node, opts) -> Uint8Array
//
// Read all relevant properties from the output node and produce a
// deterministic byte sequence.
//
// opts:
//   maxConstraintSlots (default 16) - how many constraint slots to encode
//   maxSubcascadeSlots (default 8)  - how many subcascade slots to encode
//   includeScalars     (default true)
//   includeKindCounts  (default true)
//   lowSaturation      (default false) - use rotating markers, no separators,
//                                        to prevent any single marker byte
//                                        from dominating the byte distribution
// ----------------------------------------------------------------------------

function reencode(node, opts) {
  opts = opts || {};
  if (opts.lowSaturation) return reencodeLowSat(node, opts);
  const maxC = (opts.maxConstraintSlots | 0) || 16;
  const maxS = (opts.maxSubcascadeSlots | 0) || 8;
  const includeScalars = opts.includeScalars !== false;
  const includeKindCounts = opts.includeKindCounts !== false;

  const get = name => node.style.getPropertyValue(name) || "";
  const out = [];

  // --- scalar properties ---
  if (includeScalars) {
    const scalar = +get("--scalar-delta");
    const fast   = +get("--fast-delta");
    const slow   = +get("--slow-delta");
    const fmod   = +get("--fast-mod");
    const smod   = +get("--slow-mod");

    out.push(MARKER.SCALAR_DELTA, quantizeScalar01(scalar), MARKER.SEPARATOR);
    out.push(MARKER.FAST_DELTA,   quantizeScalar01(fast),   MARKER.SEPARATOR);
    out.push(MARKER.SLOW_DELTA,   quantizeScalar01(slow),   MARKER.SEPARATOR);
    out.push(MARKER.FAST_MOD,     quantizeSigned(fmod),     MARKER.SEPARATOR);
    out.push(MARKER.SLOW_MOD,     quantizeScalar01(smod),   MARKER.SEPARATOR);
  }

  // --- step ---
  const step = +get("--step");
  if (isFinite(step)) {
    out.push(MARKER.STEP, quantizeUses(step | 0), MARKER.SEPARATOR);
  }

  // --- population counts ---
  const cc = +get("--constraint-count");
  const sc = +get("--subcascade-count");
  if (isFinite(cc)) out.push(MARKER.CONSTRAINT_CT, quantizeCount(cc | 0), MARKER.SEPARATOR);
  if (isFinite(sc)) out.push(MARKER.SUBCASCADE_CT, quantizeCount(sc | 0), MARKER.SEPARATOR);

  // --- kind counts ---
  if (includeKindCounts) {
    for (const k of ["seed", "derived", "predictive", "meta", "compound", "ratified"]) {
      const n = +get("--kind-" + k + "-count");
      if (isFinite(n) && n > 0) {
        out.push(MARKER.KIND_COUNT, kindCodeOf(k), quantizeCount(n | 0), MARKER.SEPARATOR);
      }
    }
  }

  // --- constraint slots ---
  for (let i = 0; i < maxC; i++) {
    const id = get("--c-" + i + "-id");
    if (!id) continue;
    const kind = get("--c-" + i + "-kind") || "unknown";
    const weight = +get("--c-" + i + "-weight");
    const uses = +get("--c-" + i + "-uses");
    out.push(
      MARKER.CONSTRAINT,
      i & 0xFF,
      kindCodeOf(kind),
      quantizeWeight(weight),
      quantizeUses(uses)
    );
  }

  // --- subcascade slots ---
  for (let i = 0; i < maxS; i++) {
    const id = get("--sc-" + i + "-id");
    if (!id) continue;
    const named = +get("--sc-" + i + "-named");
    const delta = +get("--sc-" + i + "-delta");
    out.push(
      MARKER.SUBCASCADE,
      i & 0xFF,
      quantizeCount(named | 0),
      quantizeScalar01(delta)
    );
  }

  return new Uint8Array(out);
}

// ----------------------------------------------------------------------------
// reencodeLowSat(node, opts) -> Uint8Array
//
// Low-saturation re-encoding. Avoids fixed marker/separator bytes that
// would dominate the byte distribution. Each property's representation is
// just its quantized value byte(s); no markers, no separators. The only
// structure in the byte stream is the value sequence itself.
//
// Trade-off: the resulting byte stream is harder to decode back to substrate
// state (no markers to delimit fields) and is structurally less informative
// (no metadata about which value is which). But it preserves the WASM
// signal in the cascade because no byte recurs purely from encoding overhead.
//
// This is the desaturation that was structurally predicted: prevent the
// recursive feedback from saturating around encoding-overhead patterns
// without modifying any substrate commitment.
// ----------------------------------------------------------------------------

function reencodeLowSat(node, opts) {
  opts = opts || {};
  const maxC = (opts.maxConstraintSlots | 0) || 16;
  const maxS = (opts.maxSubcascadeSlots | 0) || 8;
  const includeScalars = opts.includeScalars !== false;
  const includeKindCounts = opts.includeKindCounts !== false;
  const get = name => node.style.getPropertyValue(name) || "";

  const out = [];

  if (includeScalars) {
    out.push(quantizeScalar01(+get("--scalar-delta")));
    out.push(quantizeScalar01(+get("--fast-delta")));
    out.push(quantizeScalar01(+get("--slow-delta")));
    out.push(quantizeSigned(+get("--fast-mod")));
    out.push(quantizeScalar01(+get("--slow-mod")));
  }

  out.push(quantizeUses((+get("--step")) | 0));
  out.push(quantizeCount((+get("--constraint-count")) | 0));
  out.push(quantizeCount((+get("--subcascade-count")) | 0));

  if (includeKindCounts) {
    for (const k of ["seed", "derived", "predictive", "meta", "compound", "ratified"]) {
      const n = +get("--kind-" + k + "-count");
      if (isFinite(n) && n > 0) out.push(quantizeCount(n | 0));
    }
  }

  // Constraint slots: just kind code + weight + uses (no slot-marker)
  for (let i = 0; i < maxC; i++) {
    const id = get("--c-" + i + "-id");
    if (!id) continue;
    out.push(kindCodeOf(get("--c-" + i + "-kind") || "unknown"));
    out.push(quantizeWeight(+get("--c-" + i + "-weight")));
    out.push(quantizeUses(+get("--c-" + i + "-uses")));
  }

  // Subcascade slots: named + delta
  for (let i = 0; i < maxS; i++) {
    const id = get("--sc-" + i + "-id");
    if (!id) continue;
    out.push(quantizeCount((+get("--sc-" + i + "-named")) | 0));
    out.push(quantizeScalar01(+get("--sc-" + i + "-delta")));
  }

  return new Uint8Array(out);
}

// ----------------------------------------------------------------------------
// reencodeDelta(node, prevBytes, opts) -> Uint8Array
//
// Spectral-subtraction encoding. Computes the low-saturation byte sequence
// for the current state, then XORs against the previous cycle's bytes.
// The output is the delta - bytes that changed since last cycle.
//
// Constant patterns (fields that don't change) produce 0x00 bytes in the
// delta. Changes produce non-zero bytes. The substrate sees the changes,
// not the constancy.
//
// This is the desaturation that mechanism three from the architecture
// discussion named: emit derivative not absolute, suppress what's always
// there, emphasize what's characteristic of this moment.
//
// First call (no previous bytes) returns the absolute encoding so the
// substrate has something to work with; subsequent calls return deltas.
// ----------------------------------------------------------------------------

function reencodeDelta(node, prevBytes, opts) {
  const current = reencodeLowSat(node, opts);
  if (!prevBytes || prevBytes.length === 0) return current;
  // XOR against previous; result is 0 where unchanged, non-zero where changed
  const len = Math.max(current.length, prevBytes.length);
  const out = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    const a = i < current.length ? current[i] : 0;
    const b = i < prevBytes.length ? prevBytes[i] : 0;
    out[i] = a ^ b;
  }
  return { current: current, delta: out };
}

// ----------------------------------------------------------------------------
// driveRecursive(substrate, originalBytes, opts) -> array of cycle records
//
// Run a recursive feedback experiment on a single substrate.
//
// On each cycle:
//   1. Feed originalBytes into the substrate (windowed binary-intake)
//   2. Render the substrate to its output node
//   3. Re-encode the output node as bytes
//   4. Feed those re-encoded bytes back into the substrate
//   5. Snapshot metrics
//
// Phase=ZERO opts (no recursive feedback) skips steps 3-4 to compare against
// the baseline.
//
// Returns an array of per-cycle records suitable for plotting trajectory.
// ----------------------------------------------------------------------------

async function driveRecursive(substrate, originalBytes, opts) {
  opts = opts || {};
  const cycles = (opts.cycles | 0) || 10;
  const recursive = opts.recursive !== false;
  const windowSize = (opts.windowSize | 0) || 4;
  const reencodeOpts = opts.reencodeOpts || {};
  const useDelta = !!opts.useDelta;

  const BI = require("./binary-intake.js");
  const OR = require("./output-renderer.js");
  const SM = require("./substrate-metrics.js");

  const node = OR.createOutputNode();
  const records = [];
  let prevAbsolute = null;  // for delta mode

  for (let cy = 0; cy < cycles; cy++) {
    // 1. Original input
    await BI.feedBinary(substrate, originalBytes, { mode: "windowed", windowSize: windowSize });

    // 2. Render
    OR.render(substrate, node);

    let reencodedLen = 0;
    if (recursive) {
      // 3. Re-encode (delta mode or absolute)
      let reBytes;
      if (useDelta) {
        const r = reencodeDelta(node, prevAbsolute, reencodeOpts);
        if (r.current && r.delta) {
          prevAbsolute = r.current;
          reBytes = r.delta;
        } else {
          // First cycle: absolute encoding
          prevAbsolute = r;
          reBytes = r;
        }
      } else {
        reBytes = reencode(node, reencodeOpts);
      }
      reencodedLen = reBytes.length;

      // 4. Feed re-encoded back as input
      if (reBytes.length >= windowSize) {
        await BI.feedBinary(substrate, reBytes, { mode: "windowed", windowSize: windowSize });
      }
    }

    // 5. Snapshot
    const m = SM.extract(substrate);
    records.push({
      cycle: cy,
      reencodedBytesIn: reencodedLen,
      step: m.step,
      constraintCount: m.constraintCount,
      subcascadeCount: m.subcascades.count,
      scalarDelta: m.reachState.scalarDelta,
      fastDelta: m.reachState.fastDelta,
      slowDelta: m.reachState.slowDelta,
      slowMod: m.reachState.slowMod,
      topByteHex: m.topBytes.slice(0, 5).map(e => e.byte.toString(16).padStart(2, "0")).join(","),
      kindCounts: Object.assign({}, m.constraintsByKind)
    });
  }

  return records;
}

module.exports = {
  MARKER: MARKER,
  KIND_CODE: KIND_CODE,
  reencode: reencode,
  driveRecursive: driveRecursive,
  quantizeScalar01: quantizeScalar01,
  quantizeWeight: quantizeWeight
};
