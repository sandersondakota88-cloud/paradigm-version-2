// ============================================================================
// test-phase5-7-layer2.js  -  Phase 5.7 Layer 2 end-to-end test
// ============================================================================
//
// Wires Layer 1 + cascade-intake + Layer 2 and verifies the substrate stack:
//
//   bytes -> binary-intake -> Layer 1 -> output-renderer -> output node
//                                                            |
//          cascade-intake reads custom properties <----------+
//                          |
//                          v
//                       Layer 2 input -> Layer 2 substrate -> Layer 2 output
//
// What this verifies:
//
//   1. cascade-intake reads upstream node's custom properties without
//      mutating the upstream side (per O1)
//   2. Tokens produced by cascade-intake drive Layer 2's substrate
//      (constraints form, deltas evolve)
//   3. Layer 2 settles around patterns in Layer 1's structural output -
//      i.e., similar Layer 1 states produce similar Layer 2 tokens which
//      produce similar Layer 2 settling
//   4. Two-layer composition: same binary fed twice produces equivalent
//      stack state (modulo per-instance ID counter)
//   5. Different binaries produce different stack state at both layers
//   6. driveStack helper works for arbitrary-depth stacks
//
// ============================================================================

"use strict";

const SI = require("./substrate-instance.js");
const BI = require("./binary-intake.js");
const OR = require("./output-renderer.js");
const CI = require("./cascade-intake.js");

const tests = [];
function test(name, fn) { tests.push({ name: name, fn: fn }); }

function makeWasmFixture() {
  return new Uint8Array([
    0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00,
    0x01, 0x07, 0x01, 0x60, 0x02, 0x7F, 0x7F, 0x01, 0x7F,
    0x03, 0x02, 0x01, 0x00,
    0x07, 0x07, 0x01, 0x03, 0x61, 0x64, 0x64, 0x00, 0x00,
    0x0A, 0x09, 0x01, 0x07, 0x00,
    0x20, 0x00, 0x20, 0x01, 0x6A, 0x0B
  ]);
}

function makeDifferentFixture() {
  const bytes = [];
  for (let i = 0; i < 64; i++) bytes.push((i * 7 + 13) & 0xFF);
  return new Uint8Array(bytes);
}

// ----------------------------------------------------------------------------
// 5.7.L2.1: cascade-intake produces non-empty tokens from a populated node
// ----------------------------------------------------------------------------

test("5.7.L2.1 cascade-intake produces tokens from Layer 1 output", async function () {
  const L1 = SI.createSubstrate({ id: "L1" });
  const L1node = OR.createOutputNode();
  const bytes = makeWasmFixture();

  await BI.feedBinary(L1, bytes, { mode: "windowed", windowSize: 8 });
  OR.render(L1, L1node);

  const tokens = CI.readNode(L1node);
  if (!tokens || tokens.length === 0) {
    throw new Error("cascade-intake produced empty tokens from populated node");
  }
  if (tokens.split(/\s+/).length < 5) {
    throw new Error("cascade-intake produced suspiciously few tokens: " + tokens);
  }
  // Should include constraint slot tokens
  if (tokens.indexOf("c0-") < 0) {
    throw new Error("cascade-intake missing constraint slot tokens: " + tokens);
  }
  // Should include scalar bucket tokens
  if (tokens.indexOf("delta-scalar-") < 0) {
    throw new Error("cascade-intake missing scalar bucket tokens: " + tokens);
  }

  await L1.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.L2.2: cascade-intake is read-only with respect to upstream node
// ----------------------------------------------------------------------------

test("5.7.L2.2 cascade-intake does not mutate upstream node (per O1)", async function () {
  const L1 = SI.createSubstrate({ id: "L1" });
  const L1node = OR.createOutputNode();
  const bytes = makeWasmFixture();

  await BI.feedBinary(L1, bytes, { mode: "windowed", windowSize: 8 });
  OR.render(L1, L1node);

  const before = JSON.stringify(L1node.getAllProperties());
  CI.readNode(L1node);
  CI.readNode(L1node, { maxConstraintSlots: 32 });
  CI.readNode(L1node, { includeScalars: false });
  const after = JSON.stringify(L1node.getAllProperties());

  if (before !== after) {
    throw new Error("cascade-intake mutated upstream node");
  }

  await L1.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.L2.3: Layer 2 substrate consumes Layer 1's tokens and settles
// ----------------------------------------------------------------------------

test("5.7.L2.3 Layer 2 settles when fed Layer 1 output", async function () {
  const L1 = SI.createSubstrate({ id: "L1" });
  const L2 = SI.createSubstrate({ id: "L2" });
  const L1node = OR.createOutputNode();
  const bytes = makeWasmFixture();

  // Drive Layer 1 with binary
  await BI.feedBinary(L1, bytes, { mode: "windowed", windowSize: 8 });
  OR.render(L1, L1node);

  // Capture Layer 2 state before any input
  const L2Before = L2.getState();

  // Feed Layer 1's output to Layer 2
  await CI.drive(L2, L1node);

  const L2After = L2.getState();

  if (L2After.constraintCount <= L2Before.constraintCount) {
    throw new Error("Layer 2 constraint count did not grow: " +
      L2Before.constraintCount + " -> " + L2After.constraintCount);
  }
  if (L2After.step <= L2Before.step) {
    throw new Error("Layer 2 step did not advance");
  }
  if (L2After.traceLength <= L2Before.traceLength) {
    throw new Error("Layer 2 trace did not grow");
  }

  await L1.teardown();
  await L2.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.L2.4: repeated cycles drive Layer 2 to richer state
// ----------------------------------------------------------------------------

test("5.7.L2.4 multiple stack cycles produce progressively richer Layer 2 state",
async function () {
  const L1 = SI.createSubstrate({ id: "L1" });
  const L2 = SI.createSubstrate({ id: "L2" });
  const L1node = OR.createOutputNode();
  const bytes = makeWasmFixture();

  // Drive 3 cycles of: input bytes to L1, render, intake to L2
  let lastConstraintCount = 0;
  for (let cy = 0; cy < 3; cy++) {
    await BI.feedBinary(L1, bytes, { mode: "windowed", windowSize: 8 });
    OR.render(L1, L1node);
    await CI.drive(L2, L1node);

    const s = L2.getState();
    if (cy > 0 && s.constraintCount < lastConstraintCount) {
      throw new Error("L2 constraint count regressed across cycles");
    }
    lastConstraintCount = s.constraintCount;
  }

  // After 3 cycles, Layer 2 should have non-trivial structure
  const finalState = L2.getState();
  if (finalState.constraintCount < 5) {
    throw new Error("L2 has too few constraints after 3 cycles: " +
      finalState.constraintCount);
  }
  if (finalState.inputCount !== 3) {
    throw new Error("L2 expected 3 input events, got " + finalState.inputCount);
  }

  await L1.teardown();
  await L2.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.L2.5: same binary on two fresh stacks produces equivalent state at
// both layers (modulo per-instance ID counter)
// ----------------------------------------------------------------------------

test("5.7.L2.5 same binary produces equivalent two-layer state",
async function () {
  const bytes = makeWasmFixture();

  async function runStack(idSuffix) {
    const L1 = SI.createSubstrate({ id: "L1." + idSuffix });
    const L2 = SI.createSubstrate({ id: "L2." + idSuffix });
    const L1node = OR.createOutputNode();
    const L2node = OR.createOutputNode();
    for (let cy = 0; cy < 2; cy++) {
      await BI.feedBinary(L1, bytes, { mode: "windowed", windowSize: 8 });
      OR.render(L1, L1node);
      await CI.drive(L2, L1node);
      OR.render(L2, L2node);
    }
    const s1 = L1.getState(), s2 = L2.getState();
    await L1.teardown();
    await L2.teardown();
    return { L1: s1, L2: s2 };
  }

  const a = await runStack("a");
  const b = await runStack("b");

  // Layer 1 structural state should match
  const struct1 = (s) => ({
    step: s.step,
    constraintCount: s.constraintCount,
    subcascadeCount: s.subcascades.length,
    scalarDelta: s.scalarDelta,
    fastDelta: s.fastDelta,
    slowDelta: s.slowDelta,
    ratCount: s.ratCount,
    inputCount: s.inputCount
  });
  const a1 = JSON.stringify(struct1(a.L1));
  const b1 = JSON.stringify(struct1(b.L1));
  if (a1 !== b1) throw new Error("L1 structural state differs: " + a1 + " vs " + b1);

  // Layer 2 structural state should also match
  const a2 = JSON.stringify(struct1(a.L2));
  const b2 = JSON.stringify(struct1(b.L2));
  if (a2 !== b2) throw new Error("L2 structural state differs: " + a2 + " vs " + b2);
});

// ----------------------------------------------------------------------------
// 5.7.L2.6: different binaries produce different state at both layers
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// 5.7.L2.6: different binaries produce different state at both layers
//
// EMPIRICAL FINDING (Phase 5.7 verification):
// At low cycle counts (2-3 cycles), Layer 2 has not had enough exposure
// to Layer 1's distinct token streams to differentiate. Layer 2's settling
// converges to similar generic structure across different upstream inputs
// because the constraint compiler over a few input events with similar
// token-count and char-class profile produces similar constraints.
//
// Differentiation emerges with exposure. Empirical observations:
//   cycles=2:  identical (12 constraints, identical delta)
//   cycles=5:  divergent (47 vs 30 constraints, divergent deltas)
//   cycles=10: strongly divergent (87 vs 60 constraints)
//   cycles=20: strongly divergent (110 vs 60 constraints, distinct subcascades)
//
// This is consistent with the substrate's promotion mechanics: K1 fidelity-
// based promotion requires repeated co-occurrence; the first few inputs
// generate baseline structure that's similar regardless of input specifics,
// then sustained input drives divergence as token-specific patterns recur.
//
// The test runs 5+ cycles to operate in the regime where Layer 2 has
// differentiated.
// ----------------------------------------------------------------------------

test("5.7.L2.6 different binaries produce different two-layer state",
async function () {
  async function runStack(bytes, idSuffix) {
    const L1 = SI.createSubstrate({ id: "L1." + idSuffix });
    const L2 = SI.createSubstrate({ id: "L2." + idSuffix });
    const L1node = OR.createOutputNode();
    for (let cy = 0; cy < 5; cy++) {  // 5 cycles - past the convergence regime
      await BI.feedBinary(L1, bytes, { mode: "windowed", windowSize: 8 });
      OR.render(L1, L1node);
      await CI.drive(L2, L1node);
    }
    const s = { L1: L1.getState(), L2: L2.getState() };
    await L1.teardown(); await L2.teardown();
    return s;
  }

  const a = await runStack(makeWasmFixture(), "wasm");
  const b = await runStack(makeDifferentFixture(), "diff");

  // L1 should differ
  if (a.L1.constraintCount === b.L1.constraintCount &&
      a.L1.scalarDelta === b.L1.scalarDelta) {
    throw new Error("L1 state identical across different binaries");
  }
  // L2 should also differ - this is the load-bearing claim that signal
  // propagates up the stack. After 5 cycles, divergence is empirically
  // observed.
  if (a.L2.constraintCount === b.L2.constraintCount &&
      a.L2.scalarDelta === b.L2.scalarDelta &&
      a.L2.subcascades.length === b.L2.subcascades.length) {
    throw new Error("L2 state identical across different binaries after 5 " +
      "cycles (signal did not propagate up the stack at the regime where " +
      "differentiation should be observable)");
  }
});

// ----------------------------------------------------------------------------
// 5.7.L2.7: driveStack helper works for a 3-layer stack
// ----------------------------------------------------------------------------

test("5.7.L2.7 driveStack helper drives 3-layer stack",
async function () {
  const L1 = SI.createSubstrate({ id: "L1" });
  const L2 = SI.createSubstrate({ id: "L2" });
  const L3 = SI.createSubstrate({ id: "L3" });
  const layers = [
    { substrate: L1, outputNode: OR.createOutputNode() },
    { substrate: L2, outputNode: OR.createOutputNode() },
    { substrate: L3, outputNode: OR.createOutputNode() }
  ];
  const bytes = makeWasmFixture();

  const result = await CI.driveStack(
    layers,
    async function (l1) {
      await BI.feedBinary(l1, bytes, { mode: "windowed", windowSize: 8 });
      return 1;
    },
    { cycles: 3 }
  );

  if (result.layerStates.length !== 3) {
    throw new Error("driveStack returned wrong number of layer states");
  }
  // All three layers should have advanced
  for (let i = 0; i < 3; i++) {
    if (result.layerStates[i].step === 0) {
      throw new Error("Layer " + (i + 1) + " step is 0 after driveStack");
    }
    if (result.layerStates[i].constraintCount <= 1) {
      throw new Error("Layer " + (i + 1) + " has only seed after driveStack");
    }
  }

  await L1.teardown();
  await L2.teardown();
  await L3.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.L2.8: bucketing functions are stable
// ----------------------------------------------------------------------------

test("5.7.L2.8 bucketing functions produce stable buckets across calls",
async function () {
  // Same input must always produce same bucket
  if (CI.bucketScalar01(0.5) !== CI.bucketScalar01(0.5)) {
    throw new Error("bucketScalar01 not stable");
  }
  if (CI.bucketUses(7) !== CI.bucketUses(7)) {
    throw new Error("bucketUses not stable");
  }
  // Buckets near boundaries
  if (CI.bucketScalar01(0.099) === CI.bucketScalar01(0.101)) {
    throw new Error("bucketScalar01 should differ across the 0.1 boundary");
  }
  // Edge cases
  if (CI.bucketScalar01(NaN) !== "nan") throw new Error("NaN bucket missing");
  if (CI.bucketUses(0) !== "0") throw new Error("zero use bucket wrong");
});

// ----------------------------------------------------------------------------
// 5.7.L2.9: prefix tagging works in multi-layer stacks
// ----------------------------------------------------------------------------

test("5.7.L2.9 prefix tagging differentiates upstream layers",
async function () {
  const L1 = SI.createSubstrate({ id: "L1" });
  const L1node = OR.createOutputNode();
  await BI.feedBinary(L1, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  OR.render(L1, L1node);

  const noTag = CI.readNode(L1node);
  const withTag = CI.readNode(L1node, { prefix: "L0-" });

  if (noTag === withTag) {
    throw new Error("prefix had no effect on output");
  }
  if (withTag.indexOf("L0-c0") < 0) {
    throw new Error("prefix not prepended to constraint tokens");
  }
  if (noTag.indexOf("L0-") >= 0) {
    throw new Error("untagged token output contains prefix");
  }

  await L1.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.L2.10: stack does not regress upstream layer (Layer 1 is intact
// after Layer 2 reads its node)
// ----------------------------------------------------------------------------

test("5.7.L2.10 reading upstream node does not regress upstream substrate",
async function () {
  const L1 = SI.createSubstrate({ id: "L1" });
  const L2 = SI.createSubstrate({ id: "L2" });
  const L1node = OR.createOutputNode();

  await BI.feedBinary(L1, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  OR.render(L1, L1node);

  const beforeL1 = L1.getState();
  await CI.drive(L2, L1node);
  await CI.drive(L2, L1node);  // multiple reads
  const afterL1 = L1.getState();

  // Layer 1 should be unchanged (modulo refreshVectorDelta which getState
  // calls; that's read-only with respect to non-cache state)
  if (afterL1.constraintCount !== beforeL1.constraintCount) {
    throw new Error("L1 constraint count changed during Layer 2 reads");
  }
  if (afterL1.step !== beforeL1.step) {
    throw new Error("L1 step changed during Layer 2 reads");
  }
  if (afterL1.inputCount !== beforeL1.inputCount) {
    throw new Error("L1 input count changed during Layer 2 reads");
  }

  await L1.teardown();
  await L2.teardown();
});

// ============================================================================
// runner
// ============================================================================

async function run() {
  let pass = 0, fail = 0;
  const failures = [];
  for (const t of tests) {
    try {
      await t.fn();
      console.log("  ok    " + t.name);
      pass += 1;
    } catch (e) {
      console.log("  FAIL  " + t.name);
      console.log("        " + (e && e.message || e));
      fail += 1;
      failures.push({ name: t.name, error: e && e.message || String(e) });
    }
  }
  console.log("");
  console.log(pass + "/" + tests.length + " tests passed");
  if (failures.length > 0) {
    console.log("");
    console.log("Failures:");
    for (const f of failures) {
      console.log("  " + f.name);
      console.log("    " + f.error);
    }
  }
  return { pass, fail, total: tests.length, failures };
}

if (require.main === module) {
  run().then(r => process.exit(r.fail === 0 ? 0 : 1));
}

module.exports = { run };
