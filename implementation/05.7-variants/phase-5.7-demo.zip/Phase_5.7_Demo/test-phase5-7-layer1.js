// ============================================================================
// test-phase5-7-layer1.js  -  Phase 5.7 Layer 1 end-to-end test
// ============================================================================
//
// Wires up the three Phase 5.7 components for a single substrate layer and
// verifies the path: binary bytes -> intake adapter -> substrate -> output
// port populated with cascade-resolved-shape custom properties.
//
// What this test verifies for Phase 5.7 / Layer 1:
//
//   1. Per-instance substrate isolation works across multiple instances
//   2. Binary intake produces input that drives the substrate (constraints
//      form, deltas evolve, trace grows)
//   3. Output renderer writes the expected custom-property surface
//   4. Same binary input on two fresh instances produces structurally
//      equivalent output (modulo the constraint-ID counter finding from
//      test-invariants.js, which is now per-instance)
//   5. Different binary inputs produce structurally different output
//   6. Substrate-stack determinism: feeding the same WASM-shaped fixture
//      twice produces the same output port state
//
// What this test does NOT yet verify (those are Layer 2+ work):
//   - Multi-layer composition (Layer 1 -> Layer 2)
//   - SE-08 intake reading from another layer's output node
//   - Trajectory shapes across compression levels
//   - Recovery of encoded structure from real WASM
//
// ============================================================================

"use strict";

const SI = require("./substrate-instance.js");
const BI = require("./binary-intake.js");
const OR = require("./output-renderer.js");

const tests = [];
function test(name, fn) { tests.push({ name: name, fn: fn }); }

// ----------------------------------------------------------------------------
// Test fixture: a WASM-shaped binary
//
// Real WASM modules begin with the magic number 0x00 0x61 0x73 0x6D and
// version 0x01 0x00 0x00 0x00. After that, sections each have:
//   - 1 byte section ID
//   - LEB128 size
//   - section payload
//
// We construct a tiny fixture that has enough structural regularity for
// Layer 1 to potentially find patterns in.
// ----------------------------------------------------------------------------

function makeWasmFixture() {
  const bytes = [
    // WASM magic + version
    0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00,
    // type section: id=1, size=7, 1 entry: func(i32,i32)->i32
    0x01, 0x07, 0x01, 0x60, 0x02, 0x7F, 0x7F, 0x01, 0x7F,
    // function section: id=3, size=2, 1 entry, type 0
    0x03, 0x02, 0x01, 0x00,
    // export section: id=7, size=7, 1 export "add"->func 0
    0x07, 0x07, 0x01, 0x03, 0x61, 0x64, 0x64, 0x00, 0x00,
    // code section: id=10, size=9, 1 body
    0x0A, 0x09, 0x01, 0x07, 0x00,
    // body: get_local 0, get_local 1, i32.add, end
    0x20, 0x00, 0x20, 0x01, 0x6A, 0x0B
  ];
  return new Uint8Array(bytes);
}

// A different fixture with different statistical properties for distinct-input tests
function makeDifferentFixture() {
  const bytes = [];
  for (let i = 0; i < 64; i++) {
    bytes.push((i * 7 + 13) & 0xFF);  // pseudo-uniform spread
  }
  return new Uint8Array(bytes);
}

// ============================================================================
// Tests
// ============================================================================

// ----------------------------------------------------------------------------
// 5.7.L1.1: per-instance isolation between two substrates
// ----------------------------------------------------------------------------

test("5.7.L1.1 two substrates have independent Field/Trace state", async function () {
  const a = SI.createSubstrate({ id: "L1.A" });
  const b = SI.createSubstrate({ id: "L1.B" });

  if (a.Field === b.Field) throw new Error("Field aliased between instances");
  if (a.Trace === b.Trace) throw new Error("Trace aliased between instances");

  await a.input("alpha");
  const sA = a.getState();
  const sB = b.getState();

  if (sB.step !== 0) throw new Error("b.step changed after only a was fed");
  if (sA.constraintCount === sB.constraintCount &&
      sA.constraintCount > 1) {
    throw new Error("Both instances have same constraint count after only a was fed");
  }

  await a.teardown();
  await b.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.L1.2: binary intake produces text input that drives the substrate
// ----------------------------------------------------------------------------

test("5.7.L1.2 windowed binary intake drives substrate (constraints form)", async function () {
  const sub = SI.createSubstrate({ id: "L1.bin" });
  const bytes = makeWasmFixture();

  const before = sub.getState();
  const eventCount = await BI.feedBinary(sub, bytes, { mode: "windowed", windowSize: 8 });
  const after = sub.getState();

  if (eventCount === 0) {
    throw new Error("intake produced 0 input events for " + bytes.length + " bytes");
  }
  if (after.constraintCount <= before.constraintCount) {
    throw new Error("constraint count did not grow under binary input: " +
      before.constraintCount + " -> " + after.constraintCount);
  }
  if (after.step <= before.step) {
    throw new Error("step did not advance under binary input");
  }
  if (after.traceLength <= before.traceLength) {
    throw new Error("trace did not grow under binary input");
  }

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.L1.3: streamed binary intake also drives the substrate
// ----------------------------------------------------------------------------

test("5.7.L1.3 streamed binary intake drives substrate", async function () {
  const sub = SI.createSubstrate({ id: "L1.stream" });
  const bytes = makeWasmFixture();

  await BI.feedBinary(sub, bytes, { mode: "streamed" });
  const state = sub.getState();

  if (state.constraintCount <= 1) {
    throw new Error("streamed intake did not produce constraints (only seed remained)");
  }
  if (state.step === 0) throw new Error("step did not advance");

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.L1.4: structured intake (caller-chunked) drives the substrate
// ----------------------------------------------------------------------------

test("5.7.L1.4 structured binary intake drives substrate", async function () {
  const sub = SI.createSubstrate({ id: "L1.struct" });
  // Manually chunk the WASM fixture into "sections"
  const chunks = [
    new Uint8Array([0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00]),  // magic+version
    new Uint8Array([0x01, 0x07, 0x01, 0x60, 0x02, 0x7F, 0x7F, 0x01, 0x7F]),  // type
    new Uint8Array([0x03, 0x02, 0x01, 0x00]),  // function
    new Uint8Array([0x07, 0x07, 0x01, 0x03, 0x61, 0x64, 0x64, 0x00, 0x00])  // export
  ];

  await BI.feedBinary(sub, [], { mode: "structured" });  // empty-chunks edge
  const inputs = BI.structuredInputs(chunks);
  for (const inp of inputs) await sub.input(inp);

  const state = sub.getState();
  if (state.constraintCount <= 1) throw new Error("structured intake produced no constraints");

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.L1.5: output renderer populates expected custom properties
// ----------------------------------------------------------------------------

test("5.7.L1.5 output renderer writes expected custom-property surface", async function () {
  const sub = SI.createSubstrate({ id: "L1.render" });
  const node = OR.createOutputNode();
  const bytes = makeWasmFixture();

  await BI.feedBinary(sub, bytes, { mode: "windowed", windowSize: 8 });
  OR.render(sub, node);

  const expected = [
    "--substrate-id", "--step",
    "--scalar-delta", "--fast-delta", "--slow-delta",
    "--fast-mod", "--slow-mod",
    "--constraint-count", "--subcascade-count",
    "--rat-count", "--named-count",
    "--kind-seed-count", "--kind-derived-count"
  ];
  for (const p of expected) {
    const v = node.style.getPropertyValue(p);
    if (v === "") throw new Error("expected property " + p + " not written");
  }
  if (node.style.getPropertyValue("--substrate-id") !== "L1.render") {
    throw new Error("substrate-id did not propagate to output node");
  }

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.L1.6: per-constraint slots populated when constraints exist
// ----------------------------------------------------------------------------

test("5.7.L1.6 per-constraint slots populated up to maxConstraints", async function () {
  const sub = SI.createSubstrate({ id: "L1.slots" });
  const node = OR.createOutputNode();
  const bytes = makeDifferentFixture();

  await BI.feedBinary(sub, bytes, { mode: "windowed", windowSize: 8 });
  OR.render(sub, node, { maxConstraints: 8 });

  // At least one --c-N-id should be set; the seed alone gives us slot 0
  const c0 = node.style.getPropertyValue("--c-0-id");
  if (c0 === "") throw new Error("no constraint slot 0 written");

  // The seed should appear in the constraint slots (it has high weight by spec)
  const allProps = node.getAllProperties();
  let foundSeed = false;
  for (const k of Object.keys(allProps)) {
    if (k.startsWith("--c-") && k.endsWith("-id") && allProps[k].indexOf("seed") >= 0) {
      foundSeed = true;
      break;
    }
  }
  if (!foundSeed) throw new Error("seed not present in constraint slots");

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.L1.7: same binary on two fresh instances produces structurally
// equivalent output (modulo per-instance ID counter)
// ----------------------------------------------------------------------------

test("5.7.L1.7 same binary on fresh instances produces equivalent output", async function () {
  const bytes = makeWasmFixture();

  const a = SI.createSubstrate({ id: "L1.eq.a" });
  const nodeA = OR.createOutputNode();
  await BI.feedBinary(a, bytes, { mode: "windowed", windowSize: 8 });
  OR.render(a, nodeA);
  const propsA = nodeA.getAllProperties();
  await a.teardown();

  const b = SI.createSubstrate({ id: "L1.eq.b" });
  const nodeB = OR.createOutputNode();
  await BI.feedBinary(b, bytes, { mode: "windowed", windowSize: 8 });
  OR.render(b, nodeB);
  const propsB = nodeB.getAllProperties();
  await b.teardown();

  // Compare structural keys (excluding id-bearing keys which differ per
  // instance per the constraint-ID counter finding from test-invariants.js)
  const structuralKeys = [
    "--scalar-delta", "--fast-delta", "--slow-delta",
    "--fast-mod", "--slow-mod",
    "--constraint-count", "--subcascade-count",
    "--rat-count", "--named-count",
    "--kind-seed-count", "--kind-derived-count",
    "--kind-predictive-count", "--kind-meta-count",
    "--kind-compound-count", "--kind-ratified-count"
  ];
  for (const k of structuralKeys) {
    if (propsA[k] !== propsB[k]) {
      throw new Error("structural key " + k + " differs: a=" + propsA[k] +
        " b=" + propsB[k]);
    }
  }
});

// ----------------------------------------------------------------------------
// 5.7.L1.8: different binaries produce different output
// ----------------------------------------------------------------------------

test("5.7.L1.8 different binaries produce different output", async function () {
  const bytesA = makeWasmFixture();
  const bytesB = makeDifferentFixture();

  const a = SI.createSubstrate({ id: "L1.diff.a" });
  const nodeA = OR.createOutputNode();
  await BI.feedBinary(a, bytesA, { mode: "windowed", windowSize: 8 });
  OR.render(a, nodeA);
  const propsA = nodeA.getAllProperties();
  await a.teardown();

  const b = SI.createSubstrate({ id: "L1.diff.b" });
  const nodeB = OR.createOutputNode();
  await BI.feedBinary(b, bytesB, { mode: "windowed", windowSize: 8 });
  OR.render(b, nodeB);
  const propsB = nodeB.getAllProperties();
  await b.teardown();

  // Some structural value should differ. With distinct inputs this must
  // hold or the substrate isn't doing its job.
  let differs = false;
  for (const k of Object.keys(propsA)) {
    if (k.endsWith("-id")) continue;  // ID counter is incidental
    if (propsB[k] !== propsA[k]) { differs = true; break; }
  }
  if (!differs) throw new Error("Different binaries produced identical structural output");
});

// ----------------------------------------------------------------------------
// 5.7.L1.9: WASM magic + version produces detectable byte structure
//
// A quick sanity test: WASM begins with 0x00 0x61 0x73 0x6D 0x01 0x00 0x00
// 0x00. The byte 0x00 appears 5 times. Layer 1 should see 'b00' as a
// frequently-firing token.
// ----------------------------------------------------------------------------

test("5.7.L1.9 WASM-shape input produces b00 token activity", async function () {
  const sub = SI.createSubstrate({ id: "L1.wasm" });
  const wasm = makeWasmFixture();
  const desc = BI.describeBytes(wasm);

  // Verify our describeBytes is sane
  const b00Entry = desc.topBytes.find(e => e.token === "b00");
  if (!b00Entry || b00Entry.n < 4) {
    throw new Error("WASM fixture should have many 0x00 bytes; describe says: " +
      JSON.stringify(desc.topBytes));
  }

  // Drive substrate and check that it processed the input
  await BI.feedBinary(sub, wasm, { mode: "windowed", windowSize: 4 });
  const state = sub.getState();
  if (state.inputCount === 0) throw new Error("substrate processed no input events");

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.L1.10: render is idempotent on stable substrate state
// ----------------------------------------------------------------------------

test("5.7.L1.10 render is idempotent on quiescent substrate", async function () {
  const sub = SI.createSubstrate({ id: "L1.idem" });
  const node = OR.createOutputNode();
  const bytes = makeWasmFixture();

  await BI.feedBinary(sub, bytes, { mode: "windowed", windowSize: 8 });

  OR.render(sub, node);
  const snap1 = node.getAllProperties();

  // Render again without driving the substrate further
  OR.render(sub, node);
  const snap2 = node.getAllProperties();

  // Compare key-by-key (JSON string comparison is sensitive to key
  // insertion order in plain objects, which changes when removeProperty
  // is followed by setProperty - that's a property-set artifact, not a
  // semantic difference)
  const keys1 = Object.keys(snap1).sort();
  const keys2 = Object.keys(snap2).sort();
  if (keys1.length !== keys2.length) {
    throw new Error("idempotence: key count differs " +
      keys1.length + " -> " + keys2.length);
  }
  for (let i = 0; i < keys1.length; i++) {
    if (keys1[i] !== keys2[i]) {
      throw new Error("idempotence: key set differs at " + i +
        ": " + keys1[i] + " vs " + keys2[i]);
    }
  }
  for (const k of keys1) {
    if (snap1[k] !== snap2[k]) {
      throw new Error("idempotence: value of " + k + " differs: " +
        snap1[k] + " vs " + snap2[k]);
    }
  }

  await sub.teardown();
});

// ============================================================================
// runner
// ============================================================================

async function run() {
  let pass = 0, fail = 0;
  const failures = [];
  for (const t of tests) {
    try {
      await t.fn();
      console.log("  ok    " + t.name);
      pass += 1;
    } catch (e) {
      console.log("  FAIL  " + t.name);
      console.log("        " + (e && e.message || e));
      fail += 1;
      failures.push({ name: t.name, error: e && e.message || String(e) });
    }
  }
  console.log("");
  console.log(pass + "/" + tests.length + " tests passed");
  if (failures.length > 0) {
    console.log("");
    console.log("Failures:");
    for (const f of failures) {
      console.log("  " + f.name);
      console.log("    " + f.error);
    }
  }
  return { pass, fail, total: tests.length, failures };
}

if (require.main === module) {
  run().then(r => process.exit(r.fail === 0 ? 0 : 1));
}

module.exports = { run };
