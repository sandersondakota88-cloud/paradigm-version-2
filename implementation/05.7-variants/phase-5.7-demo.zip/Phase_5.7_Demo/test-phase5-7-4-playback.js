// ============================================================================
// test-phase5-7-4-playback.js  -  Phase 5.7.4 Playback Adapters tests
// ============================================================================
//
// Wires playback-adapters.js (InputAdapter, RenderAdapter, PlaybackSession)
// against substrate-instance.js and verifies the interactive-playback layer.
//
// What this verifies:
//
//   1. InputAdapter tokenizes interactive events into substrate-readable
//      tokens and feeds them through the substrate input pipeline
//   2. Default tokenizers cover click / key / mousemove / scroll / gesture /
//      text events
//   3. Unknown event types are skipped without failure
//   4. RenderAdapter projects substrate state to a structured scene with
//      reach / kindIntensity / regions / affordances / activity
//   5. PlaybackSession glues input + render and exposes the full playback
//      surface
//   6. Event log is bounded and recorded
//   7. Repeated equivalent events drive the substrate to develop structure
//      around them (promotion via interaction, not just binary input)
//   8. Scene reflects substrate state evolution under interaction
//   9. Custom tokenizers can override defaults
//  10. Reading scene does not mutate substrate
//
// ============================================================================

"use strict";

const SI = require("./substrate-instance.js");
const PA = require("./playback-adapters.js");

const tests = [];
function test(name, fn) { tests.push({ name: name, fn: fn }); }

// ----------------------------------------------------------------------------
// 5.7.4.1: click event tokenizes and drives substrate
// ----------------------------------------------------------------------------

test("5.7.4.1 click event drives substrate via InputAdapter", async function () {
  const sub = SI.createSubstrate({ id: "P1" });
  const adapter = new PA.InputAdapter(sub);

  const before = sub.getState();
  const result = await adapter.handle({
    type: "click",
    region: "header",
    target: "button-submit",
    x: 250, y: 80,
    button: 0
  });

  if (!result.sent) throw new Error("click event was not sent to substrate");
  if (!result.tokens || result.tokens.length === 0) {
    throw new Error("click produced no tokens");
  }
  if (result.tokens.indexOf("click") < 0) {
    throw new Error("click token missing from output: " + result.tokens);
  }
  if (result.tokens.indexOf("region-header") < 0) {
    throw new Error("region token missing");
  }

  const after = sub.getState();
  if (after.step <= before.step) throw new Error("substrate step did not advance");
  if (after.constraintCount <= before.constraintCount) {
    throw new Error("substrate constraints did not grow");
  }

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.4.2: key event tokenizes with modifiers
// ----------------------------------------------------------------------------

test("5.7.4.2 key event tokenizes with modifiers and key class",
async function () {
  const sub = SI.createSubstrate({ id: "P2" });
  const adapter = new PA.InputAdapter(sub);

  const result = await adapter.handle({
    type: "key",
    key: "a",
    code: "KeyA",
    shiftKey: true,
    ctrlKey: false
  });

  if (!result.sent) throw new Error("key event not sent");
  if (result.tokens.indexOf("key") < 0) throw new Error("key token missing");
  if (result.tokens.indexOf("k-alpha") < 0) throw new Error("k-alpha class missing");
  if (result.tokens.indexOf("mod-shift") < 0) throw new Error("mod-shift missing");
  if (result.tokens.indexOf("mod-ctrl") >= 0) {
    throw new Error("mod-ctrl present when ctrl was false");
  }

  // Digit key
  const r2 = await adapter.handle({ type: "key", key: "5" });
  if (r2.tokens.indexOf("k-digit") < 0) throw new Error("digit class missing");

  // Symbol key
  const r3 = await adapter.handle({ type: "key", key: "!" });
  if (r3.tokens.indexOf("k-symbol") < 0) throw new Error("symbol class missing");

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.4.3: text event tokenizes by length and content class
// ----------------------------------------------------------------------------

test("5.7.4.3 text event tokenizes content", async function () {
  const sub = SI.createSubstrate({ id: "P3" });
  const adapter = new PA.InputAdapter(sub);

  const result = await adapter.handle({
    type: "text",
    text: "alpha beta gamma"
  });
  if (!result.sent) throw new Error("text event not sent");
  if (result.tokens.length === 0) throw new Error("text produced no tokens");

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.4.4: mousemove tokenizes with direction
// ----------------------------------------------------------------------------

test("5.7.4.4 mousemove event tokenizes direction and magnitude",
async function () {
  const sub = SI.createSubstrate({ id: "P4" });
  const adapter = new PA.InputAdapter(sub);

  const result = await adapter.handle({
    type: "mousemove",
    x: 200, y: 200,
    dx: 50, dy: 0  // east motion
  });
  if (!result.sent) throw new Error("mousemove not sent");
  // direction token expected; the bucketing helper produces one of the 8 compass directions
  const dirTokens = ["west", "nw", "north", "ne", "east", "se", "south", "sw"];
  let foundDir = false;
  for (const d of dirTokens) {
    if (result.tokens.indexOf("dir-" + d) >= 0) { foundDir = true; break; }
  }
  if (!foundDir) throw new Error("no direction token in mousemove output: " + result.tokens);

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.4.5: unknown event types are skipped, not errored
// ----------------------------------------------------------------------------

test("5.7.4.5 unknown event types are skipped", async function () {
  const sub = SI.createSubstrate({ id: "P5" });
  const adapter = new PA.InputAdapter(sub);

  const result = await adapter.handle({ type: "phantom-event-type", foo: "bar" });
  if (!result.skipped) throw new Error("unknown event was not skipped");
  if (result.eventType !== "phantom-event-type") {
    throw new Error("skipped event type not echoed back");
  }

  // Substrate should not have advanced on the skipped event
  const state = sub.getState();
  if (state.step !== 0) throw new Error("substrate advanced on skipped event");

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.4.6: RenderAdapter scene has all expected fields
// ----------------------------------------------------------------------------

test("5.7.4.6 RenderAdapter scene exposes structural surface", async function () {
  const sub = SI.createSubstrate({ id: "P6" });
  const adapter = new PA.InputAdapter(sub);
  const renderer = new PA.RenderAdapter(sub);

  // Drive some interactions
  for (let i = 0; i < 5; i++) {
    await adapter.handle({
      type: "click",
      region: i % 2 === 0 ? "header" : "footer",
      x: 100 + i * 20, y: 50
    });
  }

  const scene = renderer.scene();

  if (typeof scene.substrateId !== "string") throw new Error("scene missing substrateId");
  if (typeof scene.step !== "number") throw new Error("scene missing step");
  if (!scene.reach || typeof scene.reach.scalar !== "number") {
    throw new Error("scene.reach incomplete");
  }
  if (typeof scene.kindIntensity !== "object") {
    throw new Error("scene missing kindIntensity");
  }
  if (!Array.isArray(scene.regions)) throw new Error("scene.regions not array");
  if (!Array.isArray(scene.affordances)) {
    throw new Error("scene.affordances not array");
  }
  if (!scene.activity || typeof scene.activity.traceLength !== "number") {
    throw new Error("scene.activity incomplete");
  }

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.4.7: scene reflects substrate evolution under interaction
// ----------------------------------------------------------------------------

test("5.7.4.7 scene evolves under sustained interaction", async function () {
  const sub = SI.createSubstrate({ id: "P7" });
  const session = new PA.PlaybackSession(sub);

  const sceneInit = session.currentScene();
  if (sceneInit.step !== 0) throw new Error("initial scene step should be 0");

  // Drive 10 clicks in the same region to encourage promotion
  for (let i = 0; i < 10; i++) {
    await session.handle({
      type: "click", region: "main", target: "btn", x: 100, y: 100
    });
  }

  const sceneAfter = session.currentScene();

  if (sceneAfter.step <= sceneInit.step) throw new Error("scene step did not advance");
  // Scalar delta should be different (settling occurred)
  if (sceneAfter.reach.scalar === sceneInit.reach.scalar) {
    throw new Error("reach.scalar did not change under sustained interaction");
  }

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.4.8: PlaybackSession records history with bound
// ----------------------------------------------------------------------------

test("5.7.4.8 PlaybackSession records bounded history", async function () {
  const sub = SI.createSubstrate({ id: "P8" });
  const session = new PA.PlaybackSession(sub, { maxHistory: 5 });

  for (let i = 0; i < 12; i++) {
    await session.handle({ type: "click", region: "r" + i, x: i, y: i });
  }

  const history = session.getHistory();
  if (history.length !== 5) {
    throw new Error("history not bounded to 5: got " + history.length);
  }
  // Last entry should reflect last event
  const last = history[history.length - 1];
  if (typeof last.atStep !== "number") {
    throw new Error("history entry missing atStep");
  }
  if (last.eventType !== "click") {
    throw new Error("history entry has wrong eventType");
  }

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.4.9: custom tokenizer overrides default
// ----------------------------------------------------------------------------

test("5.7.4.9 custom tokenizer overrides default", async function () {
  const sub = SI.createSubstrate({ id: "P9" });
  const adapter = new PA.InputAdapter(sub, {
    tokenizers: {
      click: function (event) {
        return ["custom-click", "marker-" + (event.region || "none")];
      }
    }
  });

  const result = await adapter.handle({ type: "click", region: "test", x: 1, y: 1 });
  if (result.tokens.indexOf("custom-click") < 0) {
    throw new Error("custom tokenizer was not used: " + result.tokens);
  }
  if (result.tokens.indexOf("marker-test") < 0) {
    throw new Error("custom tokenizer marker missing");
  }
  // Default click tokens should NOT appear (we replaced the tokenizer)
  if (result.tokens === "click" ||
      result.tokens.indexOf("region-test") >= 0) {
    throw new Error("default click tokens leaked through custom tokenizer");
  }

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.4.10: rendering is read-only with respect to substrate (per O1)
// ----------------------------------------------------------------------------

test("5.7.4.10 RenderAdapter does not mutate substrate (per O1)",
async function () {
  const sub = SI.createSubstrate({ id: "P10" });
  const adapter = new PA.InputAdapter(sub);
  const renderer = new PA.RenderAdapter(sub);

  for (let i = 0; i < 5; i++) {
    await adapter.handle({ type: "click", region: "test", x: i, y: i });
  }

  const before = sub.getState();
  const beforeStep = before.step;
  const beforeCount = before.constraintCount;
  const beforeTrace = before.traceLength;

  // Multiple scene reads should not advance state
  renderer.scene();
  renderer.scene();
  renderer.scene();

  const after = sub.getState();
  if (after.step !== beforeStep) {
    throw new Error("scene reads advanced step: " + beforeStep + " -> " + after.step);
  }
  if (after.constraintCount !== beforeCount) {
    throw new Error("scene reads changed constraint count");
  }
  if (after.traceLength !== beforeTrace) {
    throw new Error("scene reads grew trace");
  }

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.4.11: equivalent click sequences produce structurally equivalent scenes
// ----------------------------------------------------------------------------

test("5.7.4.11 same event sequence produces equivalent scenes",
async function () {
  const events = [
    { type: "click", region: "main", x: 100, y: 100 },
    { type: "click", region: "main", x: 100, y: 100 },
    { type: "key", key: "a" },
    { type: "click", region: "footer", x: 200, y: 400 }
  ];

  async function runSession(suffix) {
    const sub = SI.createSubstrate({ id: "eq." + suffix });
    const session = new PA.PlaybackSession(sub);
    let lastScene = null;
    for (const e of events) {
      lastScene = await session.handle(e);
    }
    const state = sub.getState();
    await sub.teardown();
    return { scene: lastScene, state: state };
  }

  const a = await runSession("a");
  const b = await runSession("b");

  // Structural reach should match exactly
  if (a.scene.reach.scalar !== b.scene.reach.scalar) {
    throw new Error("reach.scalar differs across runs: " +
      a.scene.reach.scalar + " vs " + b.scene.reach.scalar);
  }
  if (a.scene.regions.length !== b.scene.regions.length) {
    throw new Error("region count differs across runs");
  }
  if (a.state.constraintCount !== b.state.constraintCount) {
    throw new Error("constraint count differs across runs");
  }
});

// ----------------------------------------------------------------------------
// 5.7.4.12: distinct event sequences produce distinct scenes
// ----------------------------------------------------------------------------

test("5.7.4.12 distinct event sequences produce distinct scenes",
async function () {
  async function runSession(events, suffix) {
    const sub = SI.createSubstrate({ id: "diff." + suffix });
    const session = new PA.PlaybackSession(sub);
    let lastScene = null;
    for (const e of events) lastScene = await session.handle(e);
    const state = sub.getState();
    await sub.teardown();
    return { scene: lastScene, state: state };
  }

  // Two distinct event sequences
  const eventsA = [];
  for (let i = 0; i < 10; i++) {
    eventsA.push({ type: "click", region: "main", x: 100, y: 100 });
  }
  const eventsB = [];
  for (let i = 0; i < 10; i++) {
    eventsB.push({ type: "key", key: String.fromCharCode(0x61 + (i % 26)) });
  }

  const a = await runSession(eventsA, "a");
  const b = await runSession(eventsB, "b");

  // Scenes should differ - distinct events produce distinct substrate state
  if (a.state.constraintCount === b.state.constraintCount &&
      a.scene.reach.scalar === b.scene.reach.scalar) {
    throw new Error("distinct sequences produced equivalent state " +
      "(scenes did not differentiate)");
  }
});

// ============================================================================
// runner
// ============================================================================

async function run() {
  let pass = 0, fail = 0;
  const failures = [];
  for (const t of tests) {
    try {
      await t.fn();
      console.log("  ok    " + t.name);
      pass += 1;
    } catch (e) {
      console.log("  FAIL  " + t.name);
      console.log("        " + (e && e.message || e));
      fail += 1;
      failures.push({ name: t.name, error: e && e.message || String(e) });
    }
  }
  console.log("");
  console.log(pass + "/" + tests.length + " tests passed");
  if (failures.length > 0) {
    console.log("");
    console.log("Failures:");
    for (const f of failures) {
      console.log("  " + f.name);
      console.log("    " + f.error);
    }
  }
  return { pass, fail, total: tests.length, failures };
}

if (require.main === module) {
  run().then(r => process.exit(r.fail === 0 ? 0 : 1));
}

module.exports = { run };
