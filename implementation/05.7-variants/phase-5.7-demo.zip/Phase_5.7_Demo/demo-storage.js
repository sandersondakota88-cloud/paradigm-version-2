// ============================================================================
// demo-storage.js  -  IndexedDB-backed MediaStore for the Phase 5.7 demo
// ============================================================================
//
// The Phase 5.7.2 substrate-media.js shipped an in-memory MediaStore for
// Node-side testing. The demo uses IndexedDB instead, so substrate state
// persists across page reloads and browser restarts.
//
// API mirrors substrate-media.js's MediaStore:
//
//   const store = new IndexedDBMediaStore("substrate-demo-v1");
//   await store.open();
//   await store.put(address, artifact);    // artifact is a JSON-cloneable object
//   const a = await store.get(address);    // null if not found
//   const exists = await store.has(address);
//   await store.delete(address);
//   const addresses = await store.list();  // array of addresses
//   const count = await store.count();
//   await store.clear();
//
// Address scheme: 8-char hex content hash (computed by the demo over a
// canonical JSON serialization). The store doesn't care; it stores whatever
// keys you give it.
//
// Browser-only. In Node this module would throw on `indexedDB` reference.
//
// ============================================================================

(function (global) {
"use strict";

const STORE_NAME = "media";
const DB_VERSION = 1;

class IndexedDBMediaStore {
  constructor(dbName) {
    this.dbName = dbName || "substrate-media";
    this.db = null;
  }

  // -------------------------------------------------------------------
  // Open the database. Creates the object store on first open.
  // Idempotent: subsequent calls return the cached connection.
  // -------------------------------------------------------------------
  open() {
    if (this.db) return Promise.resolve(this.db);
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(this.dbName, DB_VERSION);
      req.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME);
        }
      };
      req.onsuccess = (event) => {
        this.db = event.target.result;
        resolve(this.db);
      };
      req.onerror = (event) => {
        reject(new Error("IndexedDBMediaStore.open: " +
          (event.target.error && event.target.error.message || "unknown")));
      };
    });
  }

  // -------------------------------------------------------------------
  // Internal: run a transaction with the given mode and callback. The
  // callback receives the object store and may issue requests against
  // it; we resolve with whatever the transaction returns when it
  // completes successfully.
  // -------------------------------------------------------------------
  _tx(mode, fn) {
    return this.open().then(db => new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, mode);
      const store = tx.objectStore(STORE_NAME);
      let result;
      try {
        result = fn(store);
      } catch (e) {
        reject(e);
        return;
      }
      tx.oncomplete = () => resolve(result);
      tx.onerror = () => reject(new Error("IndexedDB transaction: " +
        (tx.error && tx.error.message || "unknown")));
      tx.onabort = () => reject(new Error("IndexedDB transaction aborted"));
    }));
  }

  // -------------------------------------------------------------------
  // put(key, value): store value at key. Value must be structured-
  // clone-compatible (JSON-cloneable is sufficient).
  // -------------------------------------------------------------------
  put(key, value) {
    return this._tx("readwrite", store => {
      store.put(value, key);
      return key;
    });
  }

  // -------------------------------------------------------------------
  // get(key): return the value at key, or null if not present.
  // -------------------------------------------------------------------
  get(key) {
    return this._tx("readonly", store => {
      return new Promise((resolve, reject) => {
        const req = store.get(key);
        req.onsuccess = () => resolve(req.result === undefined ? null : req.result);
        req.onerror = () => reject(new Error("get failed"));
      });
    }).then(p => p);
  }

  // -------------------------------------------------------------------
  // has(key): true if a value is stored at key.
  // -------------------------------------------------------------------
  has(key) {
    return this.get(key).then(v => v !== null);
  }

  // -------------------------------------------------------------------
  // delete(key): remove the value at key. No-op if absent.
  // -------------------------------------------------------------------
  delete(key) {
    return this._tx("readwrite", store => { store.delete(key); return true; });
  }

  // -------------------------------------------------------------------
  // list(): array of all keys currently in the store.
  // -------------------------------------------------------------------
  list() {
    return this._tx("readonly", store => {
      return new Promise((resolve, reject) => {
        const req = store.getAllKeys();
        req.onsuccess = () => resolve(Array.from(req.result));
        req.onerror = () => reject(new Error("list failed"));
      });
    }).then(p => p);
  }

  // -------------------------------------------------------------------
  // count(): number of entries in the store.
  // -------------------------------------------------------------------
  count() {
    return this._tx("readonly", store => {
      return new Promise((resolve, reject) => {
        const req = store.count();
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(new Error("count failed"));
      });
    }).then(p => p);
  }

  // -------------------------------------------------------------------
  // clear(): remove all entries.
  // -------------------------------------------------------------------
  clear() {
    return this._tx("readwrite", store => { store.clear(); return true; });
  }

  close() {
    if (this.db) { this.db.close(); this.db = null; }
  }
}

// -------------------------------------------------------------------
// SHA-256 content addressing using SubtleCrypto (browser-native).
// Produces an 8-char hex prefix sufficient for collision avoidance
// in a small demo store.
// -------------------------------------------------------------------

async function contentAddress(value) {
  // Canonicalize: stringify with sorted keys. This is the same scheme
  // substrate-media.js uses for its content addressing.
  const canonical = canonicalStringify(value);
  const bytes = new TextEncoder().encode(canonical);
  const hashBuf = await crypto.subtle.digest("SHA-256", bytes);
  const hashArr = Array.from(new Uint8Array(hashBuf));
  return hashArr.map(b => b.toString(16).padStart(2, "0")).join("").slice(0, 16);
}

function canonicalStringify(v) {
  if (v === null || typeof v !== "object") return JSON.stringify(v);
  if (Array.isArray(v)) {
    return "[" + v.map(canonicalStringify).join(",") + "]";
  }
  const keys = Object.keys(v).sort();
  return "{" + keys.map(k =>
    JSON.stringify(k) + ":" + canonicalStringify(v[k])
  ).join(",") + "}";
}

// -------------------------------------------------------------------
// Export
// -------------------------------------------------------------------

const DemoStorage = Object.freeze({
  IndexedDBMediaStore: IndexedDBMediaStore,
  contentAddress: contentAddress,
  canonicalStringify: canonicalStringify
});

if (typeof module !== "undefined" && module.exports) {
  module.exports = DemoStorage;
} else {
  global.DemoStorage = DemoStorage;
}

})(typeof globalThis !== "undefined" ? globalThis : (typeof window !== "undefined" ? window : this));
