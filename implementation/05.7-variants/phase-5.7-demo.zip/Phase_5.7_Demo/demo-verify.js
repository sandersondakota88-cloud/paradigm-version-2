// ============================================================================
// demo-verify.js  -  End-to-end browser verification of the Phase 5.7 demo
// ============================================================================
//
// Spins up local HTTP server, launches Chromium via Playwright, loads
// demo.html, and verifies all surfaces in tandem:
//
//   1. Module scripts loaded (status -> READY)
//   2. ER engine initialized (runtime is GPU or CPU fallback - either is OK
//      per SE-06 substrate independence; Chromium headless typically has no
//      GPU so CPU fallback is the expected path here)
//   3. IndexedDB opened (storage pill -> READY)
//   4. WASM corpus rendered with 3 entries
//   5. Train button feeds substrate (constraints grow, alignment metric appears)
//   6. WGSL shader is fetched (network log shows resolve-fresh.wgsl)
//   7. Save creates an IndexedDB record (saved-list updates)
//   8. **Full page reload** then verify saved record persists across reload
//   9. Load restores the substrate state from IndexedDB
//  10. Canvas click drives substrate
//  11. Text input drives substrate
//  12. Reset returns to fresh state
//  13. No console errors, no page exceptions
//
// Failure of any of these prints a FAIL line; success is OK lines and a
// final OK summary plus screenshot.
//
// ============================================================================

"use strict";

const path = require("path");
const http = require("http");
const fs = require("fs");
const url = require("url");

const PLAYWRIGHT_PATH = "/home/claude/.npm-global/lib/node_modules/playwright";
const pw = require(PLAYWRIGHT_PATH);

const ROOT = __dirname;
const PORT = 18374;

function startServer() {
  const MIME = {
    ".html": "text/html",
    ".js":   "application/javascript",
    ".css":  "text/css",
    ".json": "application/json",
    ".wgsl": "text/plain"
  };
  const server = http.createServer((req, res) => {
    const u = url.parse(req.url);
    const requested = decodeURIComponent(u.pathname);
    const safe = path.normalize(requested).replace(/^(\.\.[\/\\])+/, "");
    const filepath = path.join(ROOT, safe);
    if (!filepath.startsWith(ROOT)) {
      res.writeHead(403); res.end("forbidden"); return;
    }
    fs.stat(filepath, (err, stat) => {
      if (err || !stat.isFile()) {
        res.writeHead(404); res.end("not found: " + safe); return;
      }
      const ext = path.extname(filepath).toLowerCase();
      res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
      fs.createReadStream(filepath).pipe(res);
    });
  });
  return new Promise(resolve => server.listen(PORT, "127.0.0.1", () => resolve(server)));
}

async function verify() {
  const issues = [];
  const checks = [];
  function log(kind, msg) {
    const line = "  " + kind.padEnd(6, " ") + " " + msg;
    console.log(line);
    checks.push({ kind, msg });
    if (kind === "FAIL") issues.push(msg);
  }

  const server = await startServer();
  log("ok", "static server up on 127.0.0.1:" + PORT);

  let browser;
  try {
    browser = await pw.chromium.launch();
    // Use a persistent context so IndexedDB survives across reloads.
    // Playwright contexts are isolated by default but persist for the
    // lifetime of the context, which is what we want here.
    const context = await browser.newContext();
    const page = await context.newPage();

    const consoleErrors = [];
    const pageErrors = [];
    const fetchedUrls = [];
    page.on("console", m => {
      if (m.type() === "error") consoleErrors.push(m.text());
    });
    page.on("pageerror", e => pageErrors.push(e.message + (e.stack ? "\n" + e.stack : "")));
    page.on("request", req => fetchedUrls.push(req.url()));

    await page.goto("http://127.0.0.1:" + PORT + "/demo.html", {
      waitUntil: "networkidle",
      timeout: 20000
    });
    log("ok", "page navigated to demo.html");

    // Wait for status pill to reach READY (script initialization complete)
    try {
      await page.waitForFunction(() => {
        const el = document.getElementById("pill-status");
        return el && el.textContent === "READY";
      }, { timeout: 15000 });
      log("ok", "status reached READY");
    } catch (e) {
      const status = await page.$eval("#pill-status", el => el.textContent).catch(() => "<missing>");
      log("FAIL", "status never reached READY (current: " + status + ")");
    }

    // Check WGSL was fetched (regardless of whether GPU was actually available)
    const fetchedWGSL = fetchedUrls.some(u => u.endsWith("resolve-fresh.wgsl"));
    if (fetchedWGSL) {
      log("ok", "WGSL shader fetched (resolve-fresh.wgsl)");
    } else {
      // Note: WGSL is fetched only if GPU is available. In headless Chromium,
      // navigator.gpu is typically undefined, so the engine takes the CPU
      // fallback before fetching. This is expected and not a failure.
      log("info", "WGSL shader not fetched (likely CPU fallback - headless has no GPU)");
    }

    // Read runtime state
    const runtime = await page.$eval("#runtime-v", el => el.textContent).catch(() => "?");
    log("info", "runtime: " + runtime);

    // Check IndexedDB pill
    const storage = await page.$eval("#storage-v", el => el.textContent).catch(() => "?");
    if (storage !== "READY") {
      log("FAIL", "IndexedDB did not reach READY (got: " + storage + ")");
    } else {
      log("ok", "IndexedDB opened (READY)");
    }

    // Verify WASM corpus rendered with 3 options
    const wasmCount = await page.$$eval("#wasm-pick .wopt", els => els.length).catch(() => 0);
    if (wasmCount !== 3) {
      log("FAIL", "WASM corpus has " + wasmCount + " entries, expected 3");
    } else {
      log("ok", "WASM corpus rendered (3 entries)");
    }

    // Train on selected WASM
    const preTrainCN = await page.$eval("#m-cn", el => +el.textContent).catch(() => -1);
    await page.click("#btn-train");
    await page.waitForFunction(prev => {
      const el = document.getElementById("m-cn");
      return el && +el.textContent > prev + 5;
    }, preTrainCN, { timeout: 15000 }).catch(() => null);
    const postTrainCN = await page.$eval("#m-cn", el => +el.textContent).catch(() => -1);
    if (postTrainCN <= preTrainCN) {
      log("FAIL", "Train did not advance constraints: " + preTrainCN + " -> " + postTrainCN);
    } else {
      log("ok", "Train advanced constraints (" + preTrainCN + " -> " + postTrainCN + ")");
    }

    // Verify alignment metric populated (Spearman rho)
    const rho = await page.$eval("#met-rho", el => el.textContent).catch(() => "?");
    if (rho === "-" || rho === "?") {
      log("FAIL", "alignment Spearman not computed");
    } else {
      log("ok", "alignment Spearman vs WASM: " + rho);
      const rhoNum = parseFloat(rho);
      if (isFinite(rhoNum) && rhoNum >= 0.7) {
        log("ok", "alignment passes Phase 5.7.5 threshold (>= 0.7)");
      } else if (isFinite(rhoNum)) {
        log("info", "alignment below 5.7.5 threshold; in-browser run produced " + rhoNum.toFixed(3));
      }
    }

    // Save to IndexedDB
    await page.click("#btn-save");
    await page.waitForTimeout(300);
    const savedCount1 = await page.$$eval("#saved-list .item", els => els.length).catch(() => 0);
    if (savedCount1 < 1) {
      log("FAIL", "Save did not produce IndexedDB record");
    } else {
      log("ok", "Save created IndexedDB record (saved-list has " + savedCount1 + " entries)");
    }

    // Capture an "after train" screenshot before reload
    const shotBefore = path.join(ROOT, "demo.before-reload.png");
    await page.screenshot({ path: shotBefore });
    log("ok", "screenshot before reload: " + path.basename(shotBefore));

    // ===== THE PAGE RELOAD - critical test of IndexedDB persistence =====
    await page.reload({ waitUntil: "networkidle", timeout: 20000 });
    log("ok", "page reloaded");

    // Wait for re-init
    await page.waitForFunction(() => {
      const el = document.getElementById("pill-status");
      return el && el.textContent === "READY";
    }, { timeout: 15000 });

    // After reload: substrate should be fresh (constraint count 1)
    const afterReloadCN = await page.$eval("#m-cn", el => +el.textContent).catch(() => -1);
    if (afterReloadCN > 5) {
      log("FAIL", "after reload, substrate is not fresh: cn=" + afterReloadCN);
    } else {
      log("ok", "after reload, substrate is fresh (cn=" + afterReloadCN + ")");
    }

    // After reload: IndexedDB should still have the saved record
    const savedCountAfterReload = await page.$$eval("#saved-list .item", els => els.length).catch(() => 0);
    if (savedCountAfterReload < 1) {
      log("FAIL", "IndexedDB record did NOT persist across reload " +
        "(saved-list has " + savedCountAfterReload + " entries)");
    } else {
      log("ok", "IndexedDB record persisted across reload (" + savedCountAfterReload + " entries)");
    }

    // Click Load to restore the saved state
    await page.click("#btn-load");
    await page.waitForTimeout(300);
    const afterLoadCN = await page.$eval("#m-cn", el => +el.textContent).catch(() => -1);
    if (afterLoadCN <= afterReloadCN) {
      log("FAIL", "Load did not restore from IndexedDB across reload: " +
        afterReloadCN + " -> " + afterLoadCN);
    } else {
      log("ok", "Load restored from IndexedDB across reload (" +
        afterReloadCN + " -> " + afterLoadCN + ")");
    }

    // Canvas click
    const preClickStep = await page.$eval("#m-step", el => +el.textContent).catch(() => -1);
    const canvasBox = await page.$("#canvas").then(h => h.boundingBox());
    if (canvasBox) {
      await page.mouse.click(canvasBox.x + 200, canvasBox.y + 150);
      await page.waitForTimeout(200);
      const postClickStep = await page.$eval("#m-step", el => +el.textContent).catch(() => -1);
      if (postClickStep <= preClickStep) {
        log("FAIL", "Canvas click did not advance substrate");
      } else {
        log("ok", "Canvas click advanced substrate (step " + preClickStep + " -> " + postClickStep + ")");
      }
    }

    // Text input
    const preTextStep = await page.$eval("#m-step", el => +el.textContent).catch(() => -1);
    await page.fill("#text-input", "alpha beta gamma delta");
    await page.press("#text-input", "Enter");
    await page.waitForTimeout(200);
    const postTextStep = await page.$eval("#m-step", el => +el.textContent).catch(() => -1);
    if (postTextStep <= preTextStep) {
      log("FAIL", "Text input did not advance substrate");
    } else {
      log("ok", "Text input advanced substrate (step " + preTextStep + " -> " + postTextStep + ")");
    }

    // Tick (settle without external input)
    const preTickStep = await page.$eval("#m-step", el => +el.textContent).catch(() => -1);
    const preTickTrace = await page.$eval("#m-tr", el => +el.textContent).catch(() => -1);
    await page.click("#btn-tick");
    await page.waitForTimeout(300);
    const postTickTrace = await page.$eval("#m-tr", el => +el.textContent).catch(() => -1);
    if (postTickTrace <= preTickTrace) {
      log("FAIL", "Tick did not extend trace");
    } else {
      log("ok", "Tick extended trace (" + preTickTrace + " -> " + postTickTrace + ")");
    }

    // Reset
    await page.click("#btn-reset");
    await page.waitForTimeout(200);
    const afterResetCN = await page.$eval("#m-cn", el => +el.textContent).catch(() => -1);
    if (afterResetCN > 5) {
      log("FAIL", "Reset did not return to fresh state: cn=" + afterResetCN);
    } else {
      log("ok", "Reset returned to fresh state (cn=" + afterResetCN + ")");
    }

    // Final screenshot
    const shotFinal = path.join(ROOT, "demo.final.png");
    await page.screenshot({ path: shotFinal });
    log("ok", "final screenshot: " + path.basename(shotFinal));

    // Console / page errors
    if (consoleErrors.length > 0) {
      log("FAIL", consoleErrors.length + " console error(s):");
      for (const ce of consoleErrors) console.log("         | " + ce);
    } else {
      log("ok", "no console errors");
    }
    if (pageErrors.length > 0) {
      log("FAIL", pageErrors.length + " page exception(s):");
      for (const pe of pageErrors) console.log("         | " + pe.split("\n")[0]);
    } else {
      log("ok", "no page exceptions");
    }
  } catch (e) {
    log("FAIL", "verification threw: " + e.message);
    if (e.stack) console.log(e.stack);
  } finally {
    if (browser) await browser.close();
    server.close();
  }

  console.log("");
  if (issues.length === 0) {
    console.log("VERIFY OK - Phase 5.7 demo verified end-to-end");
    return 0;
  } else {
    console.log("VERIFY FAILED with " + issues.length + " issue(s):");
    for (const i of issues) console.log("  - " + i);
    return 1;
  }
}

if (require.main === module) {
  verify().then(code => process.exit(code));
}
