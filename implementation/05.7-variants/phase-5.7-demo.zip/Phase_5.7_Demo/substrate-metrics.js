// ============================================================================
// substrate-metrics.js  -  Extract structural metrics from a substrate
// ============================================================================
//
// Reads a substrate's accumulated state and produces metrics in the same
// shape as wasm-analyzer's output. Used to compare substrate-side behavior
// against WASM-spec-derived ground truth.
//
// Key insight: when binary-intake feeds bytes into the substrate, each byte
// becomes a hex token like "b41" (for byte 0x41). The substrate's
// constraints carry these tokens as their patterns. To extract substrate
// metrics in byte-space, we read constraint patterns and translate "bNN"
// tokens back to byte values.
//
// What gets extracted:
//
//   topSubstrateBytes:
//     For each constraint with a pattern referencing "bNN" tokens, read
//     the constraint's weight and uses. Aggregate per byte. The top-N
//     bytes by aggregate weight*uses are the substrate's analog to
//     wasm-analyzer's topByteRanks.
//
//   substrateCoOccurrences:
//     The substrate represents co-occurrence in two places:
//       1. Constraints with pattern.type === "co-occurs" reference two
//          tokens (a and b). These map to byte pairs.
//       2. Sub-cascades group constraints that fire together; their
//          member tokens form an unordered set of co-occurring bytes.
//
//   constraintByKind:
//     Distribution of constraint kinds (seed/derived/predictive/meta/
//     compound/ratified). Used to verify the substrate's promotion
//     mechanics fired.
//
//   subcascadeCount:
//     Number of sub-cascades. Higher counts indicate the substrate
//     found more recurring co-occurring patterns.
//
//   reachState:
//     scalarDelta, fastDelta, slowDelta - the substrate's settling state.
//     A WASM-fed substrate at sufficient cycles should have low scalar
//     delta (settling occurred).
//
// ============================================================================

"use strict";

// ----------------------------------------------------------------------------
// Token decoder: "bNN" hex token -> byte value (or null if not a byte token)
// ----------------------------------------------------------------------------

function decodeByteToken(token) {
  if (typeof token !== "string") return null;
  if (token.length !== 3) return null;
  if (token[0] !== "b") return null;
  const hex = token.slice(1);
  if (!/^[0-9a-f]{2}$/.test(hex)) return null;
  return parseInt(hex, 16);
}

// ----------------------------------------------------------------------------
// Aggregate per-byte weight*uses across all constraints whose pattern
// references "bNN" tokens
// ----------------------------------------------------------------------------

function topSubstrateBytes(substrate, n) {
  n = (n | 0) || 10;
  const Field = substrate.Field;
  const constraints = Field.constraints || [];

  const byteScore = new Array(256).fill(0);
  const byteUses = new Array(256).fill(0);

  for (const c of constraints) {
    const pattern = c.pattern;
    if (!pattern) continue;
    const weight = (typeof c.weight === "number" ? c.weight : 0);
    const uses = (c.uses | 0);
    const score = weight * Math.max(1, uses);

    // Single-token patterns: pattern.token
    if (pattern.type === "has-token" && pattern.token) {
      const b = decodeByteToken(pattern.token);
      if (b !== null) {
        byteScore[b] += score;
        byteUses[b] += uses;
      }
    }
    // Co-occurrence patterns: pattern.a and pattern.b
    if (pattern.type === "co-occurs") {
      for (const t of [pattern.a, pattern.b]) {
        const b = decodeByteToken(t);
        if (b !== null) {
          byteScore[b] += score / 2;  // shared between both tokens
          byteUses[b] += uses;
        }
      }
    }
  }

  const entries = [];
  for (let b = 0; b < 256; b++) {
    if (byteScore[b] > 0) {
      entries.push({ byte: b, score: byteScore[b], uses: byteUses[b] });
    }
  }
  entries.sort((a, b) => b.score - a.score || a.byte - b.byte);
  return entries.slice(0, n);
}

// ----------------------------------------------------------------------------
// Extract co-occurrence pairs from constraint patterns
// ----------------------------------------------------------------------------

function substrateCoOccurrences(substrate, n) {
  n = (n | 0) || 10;
  const constraints = substrate.Field.constraints || [];

  const pairs = Object.create(null);
  for (const c of constraints) {
    const pattern = c.pattern;
    if (!pattern || pattern.type !== "co-occurs") continue;
    const a = decodeByteToken(pattern.a);
    const b = decodeByteToken(pattern.b);
    if (a === null || b === null) continue;
    const weight = (typeof c.weight === "number" ? c.weight : 1);
    const uses = (c.uses | 0);
    const score = weight * Math.max(1, uses);
    const key = a.toString(16).padStart(2, "0") + "-" +
                b.toString(16).padStart(2, "0");
    pairs[key] = (pairs[key] || 0) + score;
  }

  const entries = Object.entries(pairs)
    .map(([k, v]) => ({ pair: k, score: v }))
    .sort((a, b) => b.score - a.score || (a.pair < b.pair ? -1 : 1));
  return entries.slice(0, n);
}

// ----------------------------------------------------------------------------
// Distribution of constraints by kind
// ----------------------------------------------------------------------------

function constraintsByKind(substrate) {
  const constraints = substrate.Field.constraints || [];
  const out = Object.create(null);
  for (const c of constraints) {
    out[c.kind] = (out[c.kind] || 0) + 1;
  }
  return out;
}

// ----------------------------------------------------------------------------
// Reach state - the substrate's settling indicators
// ----------------------------------------------------------------------------

function reachState(substrate) {
  const F = substrate.Field;
  if (typeof F.refreshVectorDelta === "function") F.refreshVectorDelta();
  return {
    scalarDelta: F.scalarDelta,
    fastDelta:   F.fastDelta,
    slowDelta:   F.slowDelta,
    fastMod:     F.fastMod,
    slowMod:     F.slowMod
  };
}

// ----------------------------------------------------------------------------
// Sub-cascade summary
// ----------------------------------------------------------------------------

function subcascadeSummary(substrate) {
  const subs = substrate.Field.subcascades || [];
  return {
    count: subs.length,
    totalNamed: subs.reduce((s, x) => s + (x.namedCount | 0), 0),
    averageDelta: subs.length > 0
      ? subs.reduce((s, x) => s + (x.localDelta || 0), 0) / subs.length
      : 0
  };
}

// ----------------------------------------------------------------------------
// extract: bundle everything for one substrate
// ----------------------------------------------------------------------------

function extract(substrate, opts) {
  opts = opts || {};
  return {
    topBytes: topSubstrateBytes(substrate, opts.topN || 10),
    topCoOccurrences: substrateCoOccurrences(substrate, opts.topN || 10),
    constraintsByKind: constraintsByKind(substrate),
    reachState: reachState(substrate),
    subcascades: subcascadeSummary(substrate),
    constraintCount: (substrate.Field.constraints || []).length,
    inputCount: substrate.Field.inputCount | 0,
    step: substrate.Field.step | 0
  };
}

// ----------------------------------------------------------------------------
// Spearman rank correlation between two ranked lists
//
// Each input is an array of items with the same identifier (here: byte
// number). Spearman returns -1..1 measuring how aligned the two rankings
// are. 1 = perfect agreement, 0 = no correlation, -1 = perfect opposition.
//
// Used by alignment tests: how well does the substrate's top-byte ranking
// correlate with the WASM-derived top-byte ranking?
// ----------------------------------------------------------------------------

function rankCorrelation(rankingA, rankingB, keyFn) {
  keyFn = keyFn || (x => x.byte);
  // Build position maps: key -> rank (0-based)
  const posA = new Map();
  for (let i = 0; i < rankingA.length; i++) posA.set(keyFn(rankingA[i]), i);
  const posB = new Map();
  for (let i = 0; i < rankingB.length; i++) posB.set(keyFn(rankingB[i]), i);

  // Common keys across both rankings
  const common = [];
  for (const k of posA.keys()) {
    if (posB.has(k)) common.push(k);
  }
  if (common.length < 2) return null;  // can't compute correlation

  // Spearman: 1 - (6 * sum(d^2)) / (n * (n^2 - 1))
  const n = common.length;
  let dSquaredSum = 0;
  for (const k of common) {
    const d = posA.get(k) - posB.get(k);
    dSquaredSum += d * d;
  }
  return 1 - (6 * dSquaredSum) / (n * (n * n - 1));
}

// ----------------------------------------------------------------------------
// Coverage of co-occurrence pairs
//
// What fraction of the WASM analyzer's top-K co-occurrence pairs appear
// somewhere in the substrate's co-occurrence pairs? Returns 0..1.
// ----------------------------------------------------------------------------

function coOccurrenceCoverage(wasmTopPairs, substratePairs) {
  if (wasmTopPairs.length === 0) return 0;
  const subSet = new Set(substratePairs.map(p => p.pair));
  let hits = 0;
  for (const wp of wasmTopPairs) {
    if (subSet.has(wp.pair)) hits += 1;
  }
  return hits / wasmTopPairs.length;
}

module.exports = {
  decodeByteToken: decodeByteToken,
  topSubstrateBytes: topSubstrateBytes,
  substrateCoOccurrences: substrateCoOccurrences,
  constraintsByKind: constraintsByKind,
  reachState: reachState,
  subcascadeSummary: subcascadeSummary,
  extract: extract,
  rankCorrelation: rankCorrelation,
  coOccurrenceCoverage: coOccurrenceCoverage
};
