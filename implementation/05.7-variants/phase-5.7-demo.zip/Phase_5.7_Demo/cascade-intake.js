// ============================================================================
// cascade-intake.js  -  Inter-substrate intake adapter (Phase 5.7 / Layer 2+)
// ============================================================================
//
// Per the substrate stack architecture (Phase 5.7+), each layer's output is
// a set of CSS custom properties on a designated DOM node. The next layer
// reads those properties via this adapter and converts them into input
// tokens for its own substrate.
//
// This is SE-08 (render-substrate intake) instantiated for inter-substrate
// composition: the rendering substrate's output IS the next substrate's
// input. No command path; the cascade is the channel.
//
// The adapter is read-only with respect to the upstream layer's node and
// upstream layer's substrate (per O1). The adapter writes nothing to the
// upstream side; it produces tokens that the downstream substrate consumes
// through its standard text-input pipeline.
//
// What the adapter reads:
//
//   1. Per-constraint slots (--c-N-id, --c-N-kind, --c-N-uses, --c-N-weight)
//      Tokenized as: c<slot>-<kind>-w<weight-bucket>-u<use-bucket>
//      e.g. "c0-seed-w10-u5", "c3-derived-w11-u3"
//
//   2. Per-subcascade slots (--sc-N-id, --sc-N-named, --sc-N-delta)
//      Tokenized as: sc<slot>-n<named-bucket>
//
//   3. Kind-distribution counts (--kind-X-count)
//      Tokenized as: kc-<kind>-<count-bucket>
//      e.g. "kc-derived-19", bucketed into ranges
//
//   4. Scalar substrate state (deltas, modulation)
//      Tokenized as bucketed range tokens: dl-low / dl-mid / dl-high
//      for each scalar channel.
//
// Bucketing is essential: continuous floats produce a different token every
// step, which gives Layer 2's promotion mechanics nothing to recur on. The
// bucketing scheme groups float values into discrete bands that DO recur
// across reads when the upstream state is in a similar band.
//
// ============================================================================

"use strict";

// ----------------------------------------------------------------------------
// Bucketing helpers
// ----------------------------------------------------------------------------

// Bucket a [0, 1] scalar into named bands.
function bucketScalar01(v) {
  v = +v;
  if (!isFinite(v)) return "nan";
  if (v < 0.1)  return "vlow";
  if (v < 0.3)  return "low";
  if (v < 0.5)  return "mid-low";
  if (v < 0.7)  return "mid";
  if (v < 0.9)  return "high";
  return "vhigh";
}

// Bucket modulation values which can be negative for the fast layer.
function bucketSigned(v) {
  v = +v;
  if (!isFinite(v)) return "nan";
  if (v < -0.5) return "neg-strong";
  if (v < -0.1) return "neg";
  if (v < 0.1)  return "near-zero";
  if (v < 0.5)  return "pos";
  return "pos-strong";
}

// Bucket a use count into log-spaced buckets.
function bucketUses(n) {
  n = +n;
  if (!isFinite(n)) return "nan";
  if (n === 0) return "0";
  if (n <= 2) return "1-2";
  if (n <= 5) return "3-5";
  if (n <= 10) return "6-10";
  if (n <= 25) return "11-25";
  return "many";
}

// Bucket a weight (typically 1.0..2.0 in the substrate's range).
function bucketWeight(w) {
  w = +w;
  if (!isFinite(w)) return "nan";
  if (w < 1.001) return "base";
  if (w < 1.05)  return "low";
  if (w < 1.10)  return "mid-low";
  if (w < 1.20)  return "mid";
  if (w < 1.50)  return "high";
  return "vhigh";
}

// Bucket a population count.
function bucketCount(n) {
  n = +n;
  if (!isFinite(n)) return "nan";
  if (n === 0) return "0";
  if (n <= 3) return "1-3";
  if (n <= 8) return "4-8";
  if (n <= 20) return "9-20";
  if (n <= 50) return "21-50";
  return "many";
}

// ----------------------------------------------------------------------------
// readNode(node, opts) -> string
//
// Reads custom properties from the given node and returns a single input
// string ready for substrate.input(). The string is space-separated tokens
// representing the upstream substrate's structural state.
//
// node: output node from output-renderer.js or any object exposing
//       getPropertyValue() and getAllProperties() in the same shape.
// opts:
//   maxConstraintSlots (default 16) -- read up to N constraint slots
//   maxSubcascadeSlots (default 8)  -- read up to N subcascade slots
//   includeScalars     (default true)
//   includeKindCounts  (default true)
//   prefix             (default "")  -- prefix every emitted token with
//                                       this string. Useful for tagging
//                                       which upstream layer produced
//                                       this read in a multi-layer stack.
// ----------------------------------------------------------------------------

function readNode(node, opts) {
  opts = opts || {};
  const maxC = (opts.maxConstraintSlots | 0) || 16;
  const maxS = (opts.maxSubcascadeSlots | 0) || 8;
  const includeScalars = opts.includeScalars !== false;
  const includeKindCounts = opts.includeKindCounts !== false;
  const prefix = opts.prefix || "";

  const tokens = [];
  const get = name => node.style.getPropertyValue(name) || "";

  // ---- per-constraint slots ----
  for (let i = 0; i < maxC; i++) {
    const id = get("--c-" + i + "-id");
    if (!id) continue;  // slot empty
    const kind = get("--c-" + i + "-kind") || "unknown";
    const uses = +get("--c-" + i + "-uses");
    const weight = +get("--c-" + i + "-weight");
    // Token shape: c<slot>-<kind>-w<weight-bucket>-u<use-bucket>
    // Slot index gives Layer 2 a stable position reference; kind gives
    // the role; bucketed weight and uses give activity signal.
    tokens.push(prefix + "c" + i + "-" + kind +
      "-w-" + bucketWeight(weight) +
      "-u-" + bucketUses(uses));
  }

  // ---- per-subcascade slots ----
  for (let i = 0; i < maxS; i++) {
    const id = get("--sc-" + i + "-id");
    if (!id) continue;
    const named = +get("--sc-" + i + "-named");
    const delta = +get("--sc-" + i + "-delta");
    tokens.push(prefix + "sc" + i +
      "-n-" + bucketCount(named) +
      "-d-" + bucketScalar01(delta));
  }

  // ---- kind-distribution counts ----
  if (includeKindCounts) {
    const kinds = ["seed", "derived", "predictive", "meta", "compound", "ratified"];
    for (const k of kinds) {
      const n = +get("--kind-" + k + "-count");
      if (!isFinite(n) || n === 0) continue;
      tokens.push(prefix + "kc-" + k + "-" + bucketCount(n));
    }
  }

  // ---- scalar state (deltas, modulation) ----
  if (includeScalars) {
    const scalar = +get("--scalar-delta");
    const fast = +get("--fast-delta");
    const slow = +get("--slow-delta");
    const fastMod = +get("--fast-mod");
    const slowMod = +get("--slow-mod");

    if (isFinite(scalar))   tokens.push(prefix + "delta-scalar-" + bucketScalar01(scalar));
    if (isFinite(fast))     tokens.push(prefix + "delta-fast-"   + bucketScalar01(fast));
    if (isFinite(slow))     tokens.push(prefix + "delta-slow-"   + bucketScalar01(slow));
    if (isFinite(fastMod))  tokens.push(prefix + "mod-fast-"     + bucketSigned(fastMod));
    if (isFinite(slowMod))  tokens.push(prefix + "mod-slow-"     + bucketScalar01(slowMod));

    // Gap signal: the difference between fast and slow tells Layer 2 about
    // the upstream layer's reach state.
    if (isFinite(fast) && isFinite(slow)) {
      const gap = Math.abs(fast - slow);
      tokens.push(prefix + "gap-" + bucketScalar01(gap));
    }
  }

  return tokens.join(" ");
}

// ----------------------------------------------------------------------------
// drive(downstream, upstreamNode, opts) -> Promise<number>
//
// Convenience: read the upstream node and feed the resulting tokens to the
// downstream substrate as one input event. Returns 1 (one event submitted).
// ----------------------------------------------------------------------------

async function drive(downstream, upstreamNode, opts) {
  const tokens = readNode(upstreamNode, opts);
  if (!tokens) return 0;
  await downstream.input(tokens);
  return 1;
}

// ----------------------------------------------------------------------------
// driveStack(layers, sourceFeed, opts) -> Promise<{events, layerStates}>
//
// Run a multi-layer stack. layers is an array of { substrate, outputNode }
// pairs ordered bottom -> top. sourceFeed is an async function that drives
// layers[0] for one cycle (e.g., feeds binary input).
//
// Each cycle:
//   1. sourceFeed(layers[0].substrate) drives Layer 1 with external input
//   2. render Layer 1 to layers[0].outputNode
//   3. for i from 1 to N-1:
//        cascade-intake from layers[i-1].outputNode -> drive layers[i].substrate
//        render layers[i] to layers[i].outputNode
//
// opts:
//   cycles (default 1)         -- how many full cycles to run
//   readOpts                   -- passed to readNode() for each transition
//   onAfterCycle               -- callback(cycleIdx, layers) for diagnostics
// ----------------------------------------------------------------------------

async function driveStack(layers, sourceFeed, opts) {
  opts = opts || {};
  const cycles = (opts.cycles | 0) || 1;
  const readOpts = opts.readOpts || {};
  const OR = require("./output-renderer.js");

  let totalEvents = 0;

  for (let cy = 0; cy < cycles; cy++) {
    // Drive Layer 1 with external input
    if (sourceFeed) {
      const e = await sourceFeed(layers[0].substrate);
      if (typeof e === "number") totalEvents += e;
    }
    // Render Layer 1 to its output node
    OR.render(layers[0].substrate, layers[0].outputNode);

    // Propagate up the stack
    for (let i = 1; i < layers.length; i++) {
      // Tag prefix per layer so Layer N sees which layer below produced
      // the read (helps when multiple layers are above)
      const layerReadOpts = Object.assign({}, readOpts, {
        prefix: "L" + (i - 1) + "-"
      });
      const evt = await drive(layers[i].substrate, layers[i - 1].outputNode, layerReadOpts);
      totalEvents += evt;
      OR.render(layers[i].substrate, layers[i].outputNode);
    }

    if (opts.onAfterCycle) {
      await opts.onAfterCycle(cy, layers);
    }
  }

  return {
    events: totalEvents,
    layerStates: layers.map(L => L.substrate.getState())
  };
}

// ----------------------------------------------------------------------------
// Diagnostic helpers
// ----------------------------------------------------------------------------

// Show the tokens that would be produced for a given upstream node without
// actually feeding them to a downstream substrate.
function previewTokens(upstreamNode, opts) {
  return readNode(upstreamNode, opts);
}

module.exports = {
  readNode: readNode,
  drive: drive,
  driveStack: driveStack,
  previewTokens: previewTokens,
  // Bucketing helpers exposed for testing and diagnostics
  bucketScalar01: bucketScalar01,
  bucketSigned: bucketSigned,
  bucketUses: bucketUses,
  bucketWeight: bucketWeight,
  bucketCount: bucketCount
};
