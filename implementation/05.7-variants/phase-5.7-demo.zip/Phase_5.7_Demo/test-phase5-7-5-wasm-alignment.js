// ============================================================================
// test-phase5-7-5-wasm-alignment.js  -  Phase 5.7.5 substrate alignment tests
// ============================================================================
//
// Rigorous behavior tests grounded in WASM-spec-derived ground truth.
//
// For each module in the corpus:
//   1. Compute ground-truth metrics using wasm-analyzer (no substrate).
//   2. Feed the bytes through Layer 1 for fixed cycles.
//   3. Extract substrate metrics using substrate-metrics.
//   4. Assert quantitative alignment thresholds.
//
// Thresholds chosen empirically from observed alignment in dry runs:
//   - Spearman rank correlation between WASM top-10 byte frequencies and
//     substrate top-10 byte scores: >= 0.7 (observed: 0.85-0.94)
//   - Top WASM byte appears in substrate top 5: required
//   - Substrate produces non-trivial sub-cascade structure: >= 1 sub-cascade
//   - Co-occurrence coverage of top WASM pairs: >= 0.05 (we accept low; the
//     substrate's co-occurrence representation is window-distance-blind
//     while the analyzer's is per-distance, so exact pair matching is not
//     expected. The threshold confirms at least some WASM pairs are
//     represented.)
//   - Substrate settles (scalar delta < 0.5 after 8 cycles): expected
//   - Distinct modules produce distinct substrate states: required
//
// The tests are not "the substrate behaves like WASM execution." They are
// "the substrate detects byte-level structural regularities present in
// the WASM bytes, at thresholds that exclude random behavior."
//
// ============================================================================

"use strict";

const W = require("./wasm-corpus.js");
const A = require("./wasm-analyzer.js");
const SI = require("./substrate-instance.js");
const BI = require("./binary-intake.js");
const SM = require("./substrate-metrics.js");

const tests = [];
function test(name, fn) { tests.push({ name: name, fn: fn }); }

// Standard intake protocol: 8 cycles of windowed input at window=4
async function intakeStandard(bytes, id) {
  const sub = SI.createSubstrate({ id: id });
  for (let cy = 0; cy < 8; cy++) {
    await BI.feedBinary(sub, bytes, { mode: "windowed", windowSize: 4 });
  }
  return sub;
}

// ----------------------------------------------------------------------------
// Modules execute correctly (sanity check on the corpus itself)
// ----------------------------------------------------------------------------

test("5.7.5.1 add module is valid WASM and computes correctly",
async function () {
  const corpus = W.buildCorpus();
  const mod = await WebAssembly.compile(corpus.add.bytes);
  const inst = await WebAssembly.instantiate(mod);
  if (typeof inst.exports.add !== "function") {
    throw new Error("add export not a function");
  }
  if (inst.exports.add(7, 5) !== 12) {
    throw new Error("add(7,5) = " + inst.exports.add(7, 5));
  }
  if (inst.exports.add(-3, 10) !== 7) {
    throw new Error("add(-3,10) = " + inst.exports.add(-3, 10));
  }
});

test("5.7.5.2 fib module is valid WASM and computes correctly",
async function () {
  const corpus = W.buildCorpus();
  const mod = await WebAssembly.compile(corpus.fib.bytes);
  const inst = await WebAssembly.instantiate(mod);
  // fib(0)=0, fib(1)=1, fib(2)=1, fib(3)=2, fib(10)=55
  const expected = [[0, 0], [1, 1], [2, 1], [3, 2], [10, 55]];
  for (const [n, want] of expected) {
    const got = inst.exports.fib(n);
    if (got !== want) throw new Error("fib(" + n + ") = " + got + " want " + want);
  }
});

test("5.7.5.3 multi module is valid WASM with three functions",
async function () {
  const corpus = W.buildCorpus();
  const mod = await WebAssembly.compile(corpus.multi.bytes);
  const inst = await WebAssembly.instantiate(mod);
  if (inst.exports.add(3, 4) !== 7)  throw new Error("add(3,4)");
  if (inst.exports.sub(10, 4) !== 6) throw new Error("sub(10,4)");
  if (inst.exports.mul(6, 7) !== 42) throw new Error("mul(6,7)");
  if (!(inst.exports.mem instanceof WebAssembly.Memory)) {
    throw new Error("mem export not a Memory");
  }
});

// ----------------------------------------------------------------------------
// Analyzer correctness (sanity on the ground-truth extractor)
// ----------------------------------------------------------------------------

test("5.7.5.4 analyzer recovers correct section map from add",
async function () {
  const corpus = W.buildCorpus();
  const a = A.analyze(corpus.add.bytes);
  // add module has: type, function, export, code (4 sections)
  if (a.sectionMap.length !== 4) {
    throw new Error("add has " + a.sectionMap.length + " sections, expected 4");
  }
  const ids = a.sectionMap.map(s => s.idName);
  for (const expected of ["type", "function", "export", "code"]) {
    if (ids.indexOf(expected) < 0) {
      throw new Error("missing " + expected + " section");
    }
  }
});

test("5.7.5.5 analyzer recovers correct section map from multi",
async function () {
  const corpus = W.buildCorpus();
  const a = A.analyze(corpus.multi.bytes);
  // multi has: type, function, memory, export, code (5 sections)
  if (a.sectionMap.length !== 5) {
    throw new Error("multi has " + a.sectionMap.length + " sections, expected 5");
  }
  if (!a.sectionMap.find(s => s.idName === "memory")) {
    throw new Error("multi missing memory section");
  }
});

test("5.7.5.6 analyzer counts opcodes correctly in add code section",
async function () {
  const corpus = W.buildCorpus();
  const a = A.analyze(corpus.add.bytes);
  // add body: 0 locals, local.get 0, local.get 1, i32.add, end
  // expected counts within code section: 2 local.get, 1 i32.add, 1 end
  if (a.opcodeCounts["local.get"] !== 2) {
    throw new Error("local.get count: " + a.opcodeCounts["local.get"] + " want 2");
  }
  if (a.opcodeCounts["i32.add"] !== 1) {
    throw new Error("i32.add count: " + a.opcodeCounts["i32.add"] + " want 1");
  }
  if (a.opcodeCounts["end"] !== 1) {
    throw new Error("end count: " + a.opcodeCounts["end"] + " want 1");
  }
});

test("5.7.5.7 analyzer counts opcodes correctly in fib code section",
async function () {
  const corpus = W.buildCorpus();
  const a = A.analyze(corpus.fib.bytes);
  // fib body: 4 local.get, 3 i32.const, 2 call, 2 i32.sub, 1 if, 1 else,
  // 1 i32.lt_s, 1 i32.add. End count is permissive-scan-affected; 2 expected
  // structurally but byte-scan may pick up other 0x0B occurrences.
  if (a.opcodeCounts["local.get"] !== 4) {
    throw new Error("local.get count: " + a.opcodeCounts["local.get"] + " want 4");
  }
  if (a.opcodeCounts["call"] !== 2) {
    throw new Error("call count: " + a.opcodeCounts["call"] + " want 2");
  }
  if (a.opcodeCounts["i32.sub"] !== 2) {
    throw new Error("i32.sub count: " + a.opcodeCounts["i32.sub"] + " want 2");
  }
  if (a.opcodeCounts["if"] !== 1) {
    throw new Error("if count: " + a.opcodeCounts["if"] + " want 1");
  }
  if (a.opcodeCounts["else"] !== 1) {
    throw new Error("else count: " + a.opcodeCounts["else"] + " want 1");
  }
});

// ----------------------------------------------------------------------------
// SUBSTRATE ALIGNMENT - the core empirical claims
// ----------------------------------------------------------------------------

test("5.7.5.8 add: substrate byte-rank correlates with WASM frequency (>= 0.7)",
async function () {
  const corpus = W.buildCorpus();
  const wasmA = A.analyze(corpus.add.bytes);
  const sub = await intakeStandard(corpus.add.bytes, "add-rank");
  const subA = SM.extract(sub);
  const rc = SM.rankCorrelation(wasmA.topByteRanks, subA.topBytes);
  if (rc === null) throw new Error("rank correlation undefined");
  if (rc < 0.7) {
    throw new Error("add rank correlation " + rc.toFixed(3) + " < 0.7");
  }
  await sub.teardown();
});

test("5.7.5.9 fib: substrate byte-rank correlates with WASM frequency (>= 0.7)",
async function () {
  const corpus = W.buildCorpus();
  const wasmA = A.analyze(corpus.fib.bytes);
  const sub = await intakeStandard(corpus.fib.bytes, "fib-rank");
  const subA = SM.extract(sub);
  const rc = SM.rankCorrelation(wasmA.topByteRanks, subA.topBytes);
  if (rc === null) throw new Error("rank correlation undefined");
  if (rc < 0.7) {
    throw new Error("fib rank correlation " + rc.toFixed(3) + " < 0.7");
  }
  await sub.teardown();
});

test("5.7.5.10 multi: substrate byte-rank correlates with WASM frequency (>= 0.7)",
async function () {
  const corpus = W.buildCorpus();
  const wasmA = A.analyze(corpus.multi.bytes);
  const sub = await intakeStandard(corpus.multi.bytes, "multi-rank");
  const subA = SM.extract(sub);
  const rc = SM.rankCorrelation(wasmA.topByteRanks, subA.topBytes);
  if (rc === null) throw new Error("rank correlation undefined");
  if (rc < 0.7) {
    throw new Error("multi rank correlation " + rc.toFixed(3) + " < 0.7");
  }
  await sub.teardown();
});

test("5.7.5.11 top-frequency byte appears in substrate top 5 across all modules",
async function () {
  const corpus = W.buildCorpus();
  for (const name of ["add", "fib", "multi"]) {
    const wasmA = A.analyze(corpus[name].bytes);
    const sub = await intakeStandard(corpus[name].bytes, name + "-top1");
    const subA = SM.extract(sub);
    const top = wasmA.topByteRanks[0].byte;
    const subTop5 = subA.topBytes.slice(0, 5).map(e => e.byte);
    if (subTop5.indexOf(top) < 0) {
      throw new Error(name + ": top WASM byte 0x" +
        top.toString(16) + " not in substrate top 5: " +
        subTop5.map(b => "0x" + b.toString(16)).join(", "));
    }
    await sub.teardown();
  }
});

test("5.7.5.12 substrate produces sub-cascades for all modules",
async function () {
  const corpus = W.buildCorpus();
  for (const name of ["add", "fib", "multi"]) {
    const sub = await intakeStandard(corpus[name].bytes, name + "-subs");
    const subA = SM.extract(sub);
    if (subA.subcascades.count < 1) {
      throw new Error(name + " produced no sub-cascades after 8 cycles");
    }
    await sub.teardown();
  }
});

test("5.7.5.13 substrate settles for all modules (scalar delta < 0.5)",
async function () {
  const corpus = W.buildCorpus();
  for (const name of ["add", "fib", "multi"]) {
    const sub = await intakeStandard(corpus[name].bytes, name + "-settle");
    const subA = SM.extract(sub);
    if (subA.reachState.scalarDelta >= 0.5) {
      throw new Error(name + " did not settle: scalarDelta = " +
        subA.reachState.scalarDelta);
    }
    await sub.teardown();
  }
});

test("5.7.5.14 co-occurrence representation has non-trivial coverage",
async function () {
  const corpus = W.buildCorpus();
  for (const name of ["add", "fib", "multi"]) {
    const wasmA = A.analyze(corpus[name].bytes);
    const sub = await intakeStandard(corpus[name].bytes, name + "-cooc");
    const subA = SM.extract(sub);
    // Threshold is low (0.05) - we accept that the substrate's window-blind
    // co-occurrence and the analyzer's per-distance pairs disagree, but
    // expect at least some overlap.
    const cov = SM.coOccurrenceCoverage(wasmA.topCoOccurrences, subA.topCoOccurrences);
    if (cov < 0.05) {
      throw new Error(name + " co-occurrence coverage " +
        cov.toFixed(3) + " < 0.05 (substrate captured no top WASM pairs)");
    }
    await sub.teardown();
  }
});

// ----------------------------------------------------------------------------
// DISCRIMINATION - distinct modules produce distinct substrate state
// ----------------------------------------------------------------------------

test("5.7.5.15 distinct WASM modules produce distinct substrate state",
async function () {
  const corpus = W.buildCorpus();
  const states = {};
  for (const name of ["add", "fib", "multi"]) {
    const sub = await intakeStandard(corpus[name].bytes, name + "-disc");
    states[name] = SM.extract(sub);
    await sub.teardown();
  }
  // Pairwise: each pair should differ on at least one structural metric
  const pairs = [["add", "fib"], ["add", "multi"], ["fib", "multi"]];
  for (const [a, b] of pairs) {
    const sa = states[a], sb = states[b];
    const sameConstraints = sa.constraintCount === sb.constraintCount;
    const sameSubs = sa.subcascades.count === sb.subcascades.count;
    const sameDelta = Math.abs(sa.reachState.scalarDelta - sb.reachState.scalarDelta) < 1e-9;
    if (sameConstraints && sameSubs && sameDelta) {
      throw new Error(a + " and " + b + " produced identical substrate state");
    }
  }
});

test("5.7.5.16 distinct WASM modules produce distinct top-byte rankings",
async function () {
  const corpus = W.buildCorpus();
  const rankings = {};
  for (const name of ["add", "fib", "multi"]) {
    const sub = await intakeStandard(corpus[name].bytes, name + "-rdist");
    rankings[name] = SM.extract(sub).topBytes.slice(0, 10).map(e => e.byte).join(",");
    await sub.teardown();
  }
  if (rankings.add === rankings.fib) {
    throw new Error("add and fib produced same top-10 byte ranking");
  }
  if (rankings.add === rankings.multi) {
    throw new Error("add and multi produced same top-10 byte ranking");
  }
  if (rankings.fib === rankings.multi) {
    throw new Error("fib and multi produced same top-10 byte ranking");
  }
});

// ----------------------------------------------------------------------------
// REPRODUCIBILITY - per-instance same-input produces same metrics
// ----------------------------------------------------------------------------

test("5.7.5.17 same module on two fresh instances produces same substrate metrics",
async function () {
  const corpus = W.buildCorpus();
  const subA = await intakeStandard(corpus.fib.bytes, "fib-rep-a");
  const mA = SM.extract(subA);
  await subA.teardown();

  const subB = await intakeStandard(corpus.fib.bytes, "fib-rep-b");
  const mB = SM.extract(subB);
  await subB.teardown();

  // Structural fields (excluding id-bearing fields)
  if (mA.constraintCount !== mB.constraintCount) {
    throw new Error("constraint count differs: " +
      mA.constraintCount + " vs " + mB.constraintCount);
  }
  if (mA.subcascades.count !== mB.subcascades.count) {
    throw new Error("sub-cascade count differs");
  }
  if (Math.abs(mA.reachState.scalarDelta - mB.reachState.scalarDelta) > 1e-9) {
    throw new Error("scalar delta differs across runs: " +
      mA.reachState.scalarDelta + " vs " + mB.reachState.scalarDelta);
  }
  // Top byte must match exactly
  const topA = mA.topBytes.slice(0, 10).map(e => e.byte);
  const topB = mB.topBytes.slice(0, 10).map(e => e.byte);
  if (topA.join(",") !== topB.join(",")) {
    throw new Error("top byte rankings differ across fresh instances");
  }
});

// ----------------------------------------------------------------------------
// COVERAGE - substrate sees the structurally meaningful bytes
// ----------------------------------------------------------------------------

test("5.7.5.18 substrate represents WASM section IDs in its top constraints",
async function () {
  const corpus = W.buildCorpus();
  const sub = await intakeStandard(corpus.multi.bytes, "multi-secs");
  const subA = SM.extract(sub);
  // multi has sections type(0x01), function(0x03), memory(0x05), export(0x07), code(0x0a)
  // After 8 cycles, at least one of these should appear in top 10
  const top10 = subA.topBytes.slice(0, 10).map(e => e.byte);
  const expected = [0x01, 0x03, 0x05, 0x07, 0x0a];
  let foundCount = 0;
  for (const e of expected) {
    if (top10.indexOf(e) >= 0) foundCount += 1;
  }
  if (foundCount < 2) {
    throw new Error("substrate top 10 contains only " + foundCount +
      " of the 5 section IDs; got: " +
      top10.map(b => "0x" + b.toString(16)).join(", "));
  }
  await sub.teardown();
});

test("5.7.5.19 substrate detects local.get opcode (0x20) which is most common in code",
async function () {
  // 0x20 is local.get - the most common opcode in all three modules' bodies.
  // For modules where the code section is large enough relative to header,
  // 0x20 should rank in substrate's top constraints.
  const corpus = W.buildCorpus();
  // multi has the largest code section; 0x20 appears 6 times in its body
  const sub = await intakeStandard(corpus.multi.bytes, "multi-local");
  const subA = SM.extract(sub);
  const top10 = subA.topBytes.slice(0, 10).map(e => e.byte);
  if (top10.indexOf(0x20) < 0) {
    throw new Error("multi: 0x20 (local.get) not in substrate top 10: " +
      top10.map(b => "0x" + b.toString(16)).join(", "));
  }
  await sub.teardown();
});

test("5.7.5.20 substrate scales constraint count with input richness",
async function () {
  // More distinct bytes -> more constraints (not exact, but monotonic-ish).
  // add: 16 distinct, fib: 26 distinct, multi: 23 distinct
  // We expect: add < fib (16 < 26 distinct => more constraints)
  const corpus = W.buildCorpus();
  const states = {};
  for (const name of ["add", "fib", "multi"]) {
    const sub = await intakeStandard(corpus[name].bytes, name + "-scale");
    states[name] = SM.extract(sub);
    await sub.teardown();
  }
  // Expect fib to have more constraints than add (richer input)
  if (states.fib.constraintCount <= states.add.constraintCount) {
    throw new Error("fib (richer) had no more constraints than add: " +
      states.fib.constraintCount + " vs " + states.add.constraintCount);
  }
});

// ============================================================================
// runner
// ============================================================================

async function run() {
  let pass = 0, fail = 0;
  const failures = [];
  for (const t of tests) {
    try {
      await t.fn();
      console.log("  ok    " + t.name);
      pass += 1;
    } catch (e) {
      console.log("  FAIL  " + t.name);
      console.log("        " + (e && e.message || e));
      fail += 1;
      failures.push({ name: t.name, error: e && e.message || String(e) });
    }
  }
  console.log("");
  console.log(pass + "/" + tests.length + " tests passed");
  if (failures.length > 0) {
    console.log("");
    console.log("Failures:");
    for (const f of failures) {
      console.log("  " + f.name);
      console.log("    " + f.error);
    }
  }
  return { pass, fail, total: tests.length, failures };
}

if (require.main === module) {
  run().then(r => process.exit(r.fail === 0 ? 0 : 1));
}

module.exports = { run };
