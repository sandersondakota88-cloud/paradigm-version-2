// ============================================================================
// test-phase5-7-3-interaction.js  -  Phase 5.7.3 free-form interaction tests
// ============================================================================
//
// Verifies the substrate-interaction layer:
//   - Interactor accepts text, binary, replay interactions
//   - ResponseRecorder captures meaningful response deltas
//   - Restored substrates respond DIFFERENTLY to the same input than fresh
//     substrates do (the load-bearing claim)
//   - Two substrates restored from the same artifact respond identically
//     to the same input (S2 across restoration)
//   - Free-form binary interaction uses the binary-intake adapter cleanly
//
// The load-bearing claim, articulated precisely:
//
//   If two substrates A and B are both fed the same input I, but A starts
//   from a fresh state and B starts from a state restored from a stored
//   artifact, then A's response to I and B's response to I should DIFFER
//   in measurable ways. The difference reflects the stored shape's
//   influence on responsiveness.
//
//   Conversely, if two substrates B and C both start from the same restored
//   state and are fed the same input I, their responses should MATCH (per
//   S2 substrate-equivalent resolution).
//
// This is what makes the architecture "interactive media": the stored
// shape produces differentiated responses to interaction.
// ============================================================================

"use strict";

const SI = require("./substrate-instance.js");
const BI = require("./binary-intake.js");
const SM = require("./substrate-media.js");
const II = require("./substrate-interaction.js");

const tests = [];
function test(name, fn) { tests.push({ name: name, fn: fn }); }

function makeWasmFixture() {
  return new Uint8Array([
    0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00,
    0x01, 0x07, 0x01, 0x60, 0x02, 0x7F, 0x7F, 0x01, 0x7F,
    0x03, 0x02, 0x01, 0x00,
    0x07, 0x07, 0x01, 0x03, 0x61, 0x64, 0x64, 0x00, 0x00,
    0x0A, 0x09, 0x01, 0x07, 0x00,
    0x20, 0x00, 0x20, 0x01, 0x6A, 0x0B
  ]);
}

// ----------------------------------------------------------------------------
// 5.7.3.1: Interactor accepts text input and records response
// ----------------------------------------------------------------------------

test("5.7.3.1 Interactor records response to text interaction",
async function () {
  const sub = SI.createSubstrate({ id: "i.text" });
  const I = new II.Interactor(sub);

  const r = await I.sendText("alpha beta gamma");
  if (r.stepDelta <= 0) throw new Error("stepDelta should be positive after input");
  if (r.constraintDelta <= 0) {
    throw new Error("constraint count didn't grow under text input");
  }
  if (r.traceDelta <= 0) throw new Error("trace didn't grow under text input");

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.3.2: Interactor accepts binary input and records response
// ----------------------------------------------------------------------------

test("5.7.3.2 Interactor records response to binary interaction",
async function () {
  const sub = SI.createSubstrate({ id: "i.bin" });
  const I = new II.Interactor(sub);

  const r = await I.sendBinary(makeWasmFixture(), {
    mode: "windowed", windowSize: 8
  });
  if (r.constraintDelta <= 0) {
    throw new Error("binary input didn't grow constraint count");
  }
  if (r.traceDelta <= 0) {
    throw new Error("binary input didn't grow trace");
  }

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.3.3: Interactor.think advances substrate without external input
// ----------------------------------------------------------------------------

test("5.7.3.3 Interactor.think advances substrate via internal mechanisms",
async function () {
  const sub = SI.createSubstrate({ id: "i.think" });
  await sub.input("alpha beta");  // give it something to think about
  const I = new II.Interactor(sub);

  const beforeTrace = sub.getState().traceLength;
  const beforeConstraints = sub.getState().constraintCount;
  await I.think(5);
  const afterTrace = sub.getState().traceLength;
  const afterConstraints = sub.getState().constraintCount;

  // think() runs develop/correlate which don't increment step counter,
  // but they DO produce trace events and may produce new constraints
  // (meta constraints from develop, correlations from correlate). Verify
  // that internal mechanisms operated.
  if (afterTrace <= beforeTrace) {
    throw new Error("think() did not produce trace events");
  }

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.3.4: Restored vs fresh - same input produces different response
//
// LOAD-BEARING TEST: this is the architecture's core claim that stored
// shape influences responsiveness.
// ----------------------------------------------------------------------------

test("5.7.3.4 [LOAD-BEARING] restored substrate responds differently than fresh to same input",
async function () {
  // Build the source substrate and store its state
  const src = SI.createSubstrate({ id: "src" });
  for (let i = 0; i < 5; i++) {
    await BI.feedBinary(src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  }
  const artifact = SM.codecs.strong.encode(src);
  await src.teardown();

  // Fresh substrate response to a probe
  const fresh = SI.createSubstrate({ id: "fresh" });
  const Ifresh = new II.Interactor(fresh);
  await Ifresh.sendText("alpha beta gamma delta");
  const freshFingerprint = Ifresh.getFingerprint();
  await fresh.teardown();

  // Restored substrate response to the same probe
  const restored = SI.createSubstrate({ id: "restored" });
  SM.codecs.strong.decode(artifact).applyTo(restored);
  const Irestored = new II.Interactor(restored);
  await Irestored.sendText("alpha beta gamma delta");
  const restoredFingerprint = Irestored.getFingerprint();
  await restored.teardown();

  if (II.fingerprintsEqual(freshFingerprint, restoredFingerprint)) {
    throw new Error("restored and fresh substrates produced identical " +
      "response fingerprint - stored shape did not influence response");
  }
});

// ----------------------------------------------------------------------------
// 5.7.3.5: Two substrates restored from same artifact respond identically
//
// COMPANION CLAIM: S2 substrate-equivalence holds across restoration.
// ----------------------------------------------------------------------------

test("5.7.3.5 two substrates from same artifact respond identically to same input",
async function () {
  const src = SI.createSubstrate({ id: "src" });
  for (let i = 0; i < 3; i++) {
    await BI.feedBinary(src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  }
  const artifact = SM.codecs.strong.encode(src);
  await src.teardown();

  const a = SI.createSubstrate({ id: "a" });
  SM.codecs.strong.decode(artifact).applyTo(a);
  const Ia = new II.Interactor(a);
  await Ia.sendText("test probe input");
  const fpA = Ia.getFingerprint();
  await a.teardown();

  const b = SI.createSubstrate({ id: "b" });
  SM.codecs.strong.decode(artifact).applyTo(b);
  const Ib = new II.Interactor(b);
  await Ib.sendText("test probe input");
  const fpB = Ib.getFingerprint();
  await b.teardown();

  if (!II.fingerprintsEqual(fpA, fpB)) {
    throw new Error("two restorations of same artifact produced different " +
      "fingerprints under same input. " +
      "A=" + JSON.stringify(fpA) + " B=" + JSON.stringify(fpB));
  }
});

// ----------------------------------------------------------------------------
// 5.7.3.6: Replay reproduces the original substrate's path
// ----------------------------------------------------------------------------

test("5.7.3.6 replaying input on a fresh substrate produces equivalent state",
async function () {
  const inputs = [
    "alpha beta",
    "gamma delta",
    "alpha gamma",
    "beta epsilon"
  ];

  // Substrate A: fed normally
  const a = SI.createSubstrate({ id: "a" });
  for (const inp of inputs) await a.input(inp);
  const stateA = a.getState();
  await a.teardown();

  // Substrate B: replayed via Interactor
  const b = SI.createSubstrate({ id: "b" });
  const Ib = new II.Interactor(b);
  await Ib.replay(inputs);
  const stateB = b.getState();
  await b.teardown();

  // Structural equivalence (modulo per-instance ID counter from Phase 5.6
  // findings): kinds and counts should match
  if (stateA.constraintCount !== stateB.constraintCount) {
    throw new Error("replay diverged: " + stateA.constraintCount +
      " vs " + stateB.constraintCount + " constraints");
  }
  if (Math.abs(stateA.scalarDelta - stateB.scalarDelta) > 1e-9) {
    throw new Error("replay diverged on scalarDelta");
  }
});

// ----------------------------------------------------------------------------
// 5.7.3.7: Restored-from-promoted-codec is operational and responds
// ----------------------------------------------------------------------------

test("5.7.3.7 restored from promoted-codec responds to interaction",
async function () {
  const src = SI.createSubstrate({ id: "src" });
  for (let i = 0; i < 5; i++) {
    await BI.feedBinary(src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  }
  const artifact = SM.codecs.promoted.encode(src);
  await src.teardown();

  const restored = SI.createSubstrate({ id: "restored" });
  SM.codecs.promoted.decode(artifact).applyTo(restored);
  const I = new II.Interactor(restored);

  await I.sendText("interactive probe");
  await I.sendBinary(new Uint8Array([0x42, 0x43, 0x44]), {
    mode: "windowed", windowSize: 3
  });
  await I.think(3);

  const responses = I.getResponses();
  if (responses.length !== 3) throw new Error("expected 3 responses, got " + responses.length);

  // All three response kinds should produce some change
  for (const r of responses) {
    if (r.stepDelta === 0 && r.constraintDelta === 0 && r.traceDelta === 0) {
      throw new Error("no change under interaction: " +
        JSON.stringify(r.interaction));
    }
  }

  await restored.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.3.8: loadInteractor end-to-end
// ----------------------------------------------------------------------------

test("5.7.3.8 loadInteractor: end-to-end load-and-interact",
async function () {
  const src = SI.createSubstrate({ id: "src" });
  for (let i = 0; i < 3; i++) {
    await BI.feedBinary(src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  }
  const store = new SM.MediaStore();
  const result = await SM.encodeAndStore(src, "strong", store);
  await src.teardown();

  const I = await II.loadInteractor(result.address, store, { id: "loaded" });
  await I.sendText("hello");
  await I.sendBinary(new Uint8Array([1, 2, 3, 4, 5, 6, 7, 8]), {
    mode: "windowed", windowSize: 4
  });

  const responses = I.getResponses();
  if (responses.length !== 2) throw new Error("expected 2 responses");
  if (responses[0].traceDelta <= 0) throw new Error("text response had no trace delta");
  if (responses[1].traceDelta <= 0) throw new Error("binary response had no trace delta");

  await I.substrate.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.3.9: Different stored shapes produce different responses to same input
//
// COMPANION TO 5.7.3.4: not just "stored vs fresh," but two DIFFERENT
// stored shapes produce two DIFFERENT responses.
// ----------------------------------------------------------------------------

test("5.7.3.9 different stored shapes produce different responses",
async function () {
  // Source A: trained on WASM
  const srcA = SI.createSubstrate({ id: "srcA" });
  for (let i = 0; i < 5; i++) {
    await BI.feedBinary(srcA, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  }
  const artA = SM.codecs.strong.encode(srcA);
  await srcA.teardown();

  // Source B: trained on different data
  const srcB = SI.createSubstrate({ id: "srcB" });
  for (let i = 0; i < 5; i++) {
    await srcB.input("alpha beta gamma delta epsilon zeta eta theta");
  }
  const artB = SM.codecs.strong.encode(srcB);
  await srcB.teardown();

  // Probe both with same input
  const probe = "test alpha 123 !@#";

  const a = SI.createSubstrate({ id: "a" });
  SM.codecs.strong.decode(artA).applyTo(a);
  const Ia = new II.Interactor(a);
  await Ia.sendText(probe);
  const fpA = Ia.getFingerprint();
  await a.teardown();

  const b = SI.createSubstrate({ id: "b" });
  SM.codecs.strong.decode(artB).applyTo(b);
  const Ib = new II.Interactor(b);
  await Ib.sendText(probe);
  const fpB = Ib.getFingerprint();
  await b.teardown();

  if (II.fingerprintsEqual(fpA, fpB)) {
    throw new Error("differently-trained substrates responded identically to " +
      "same probe - stored shape didn't differentiate");
  }
});

// ----------------------------------------------------------------------------
// 5.7.3.10: compareResponses helper produces useful diffs
// ----------------------------------------------------------------------------

test("5.7.3.10 compareResponses identifies divergent response sequences",
async function () {
  const a = SI.createSubstrate({ id: "a" });
  const b = SI.createSubstrate({ id: "b" });

  // Differently-fed substrates
  await a.input("alpha");
  await b.input("alpha beta gamma delta epsilon");

  const Ia = new II.Interactor(a);
  const Ib = new II.Interactor(b);

  await Ia.sendText("probe");
  await Ib.sendText("probe");

  const cmp = II.compareResponses(Ia.getResponses(), Ib.getResponses());
  // They MAY be equal in early states, but very likely will differ
  if (cmp.equal) {
    // If they happen to match, that's possible but suspicious; note it
    // and let the test pass since compareResponses returned the structure
    // we asked for
  } else {
    if (cmp.diffCount === 0) {
      throw new Error("equal=false but diffCount=0; inconsistent compare");
    }
    if (!Array.isArray(cmp.diffs)) {
      throw new Error("diffs is not an array");
    }
  }

  await a.teardown();
  await b.teardown();
});

// ============================================================================
// runner
// ============================================================================

async function run() {
  let pass = 0, fail = 0;
  const failures = [];
  for (const t of tests) {
    try {
      await t.fn();
      console.log("  ok    " + t.name);
      pass += 1;
    } catch (e) {
      console.log("  FAIL  " + t.name);
      console.log("        " + (e && e.message || e));
      fail += 1;
      failures.push({ name: t.name, error: e && e.message || String(e) });
    }
  }
  console.log("");
  console.log(pass + "/" + tests.length + " tests passed");
  if (failures.length > 0) {
    console.log("");
    console.log("Failures:");
    for (const f of failures) {
      console.log("  " + f.name);
      console.log("    " + f.error);
    }
  }
  return { pass, fail, total: tests.length, failures };
}

if (require.main === module) {
  run().then(r => process.exit(r.fail === 0 ? 0 : 1));
}

module.exports = { run };
