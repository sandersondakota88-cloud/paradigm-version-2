// ============================================================================
// test-phase5-7-2-persistence.js  -  Phase 5.7.2 persistence tests
// ============================================================================
//
// Verifies the substrate-media layer:
//   - Three codecs (strong / promoted / trajectory)
//   - Content-addressed MediaStore
//   - Round-trip semantics for each codec
//   - Cross-instance restoration
//
// What this verifies:
//   1. Strong codec preserves full substrate state byte-equivalent
//   2. Promoted codec preserves the structural shape (subcascades + high
//      weight constraints + modulation) suitable for transmission
//   3. Trajectory codec captures snapshot sequence + final state
//   4. Content addresses are deterministic (same artifact -> same hash)
//   5. Same substrate state on different runs encodes to the same address
//      (modulo per-instance constraint-ID counter findings)
//   6. MediaStore put/get/has/delete work
//   7. Restoration into a fresh substrate produces equivalent state
// ============================================================================

"use strict";

const SI = require("./substrate-instance.js");
const BI = require("./binary-intake.js");
const SM = require("./substrate-media.js");

const tests = [];
function test(name, fn) { tests.push({ name: name, fn: fn }); }

function makeWasmFixture() {
  return new Uint8Array([
    0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00,
    0x01, 0x07, 0x01, 0x60, 0x02, 0x7F, 0x7F, 0x01, 0x7F,
    0x03, 0x02, 0x01, 0x00,
    0x07, 0x07, 0x01, 0x03, 0x61, 0x64, 0x64, 0x00, 0x00,
    0x0A, 0x09, 0x01, 0x07, 0x00,
    0x20, 0x00, 0x20, 0x01, 0x6A, 0x0B
  ]);
}

// ----------------------------------------------------------------------------
// 5.7.2.1: strong codec round-trip preserves substrate state
// ----------------------------------------------------------------------------

test("5.7.2.1 strong codec round-trips constraint count, deltas, modulation",
async function () {
  const src = SI.createSubstrate({ id: "src" });
  await BI.feedBinary(src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  const before = src.getState();

  const artifact = SM.codecs.strong.encode(src);
  await src.teardown();

  const dst = SI.createSubstrate({ id: "dst" });
  SM.codecs.strong.decode(artifact).applyTo(dst);
  const after = dst.getState();

  if (before.constraintCount !== after.constraintCount) {
    throw new Error("constraint count differs: " +
      before.constraintCount + " vs " + after.constraintCount);
  }
  if (Math.abs(before.scalarDelta - after.scalarDelta) > 1e-9) {
    throw new Error("scalar delta differs: " +
      before.scalarDelta + " vs " + after.scalarDelta);
  }
  if (Math.abs(before.slowDelta - after.slowDelta) > 1e-9) {
    throw new Error("slow delta differs");
  }
  if (Math.abs(before.slowMod - after.slowMod) > 1e-9) {
    throw new Error("slow mod differs");
  }
  if (before.subcascades.length !== after.subcascades.length) {
    throw new Error("subcascade count differs");
  }

  await dst.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.2.2: strong codec preserves seed constraint
// ----------------------------------------------------------------------------

test("5.7.2.2 strong codec preserves seed constraint identity",
async function () {
  const src = SI.createSubstrate({ id: "src" });
  await BI.feedBinary(src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  const beforeSeed = src.getState().constraints.find(c => c.kind === "seed");

  const artifact = SM.codecs.strong.encode(src);
  await src.teardown();

  const dst = SI.createSubstrate({ id: "dst" });
  SM.codecs.strong.decode(artifact).applyTo(dst);
  const afterSeed = dst.getState().constraints.find(c => c.kind === "seed");

  if (!afterSeed) throw new Error("seed missing after restore");
  if (afterSeed.id !== beforeSeed.id) {
    throw new Error("seed id changed: " + beforeSeed.id + " -> " + afterSeed.id);
  }

  await dst.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.2.3: promoted codec captures structural shape, drops one-shot details
// ----------------------------------------------------------------------------

test("5.7.2.3 promoted codec captures only weighted/used constraints",
async function () {
  const src = SI.createSubstrate({ id: "src" });
  // Drive enough cycles to produce both promoted and one-shot structure
  for (let i = 0; i < 5; i++) {
    await BI.feedBinary(src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  }

  const artifact = SM.codecs.promoted.encode(src);
  if (artifact.codec !== "promoted") throw new Error("wrong codec tag");
  if (!artifact.structural) throw new Error("no structural section in artifact");
  if (!Array.isArray(artifact.structural.constraints)) {
    throw new Error("structural.constraints not an array");
  }
  if (!Array.isArray(artifact.structural.subcascades)) {
    throw new Error("structural.subcascades not an array");
  }

  // Promoted codec should include the seed
  const seedIn = artifact.structural.constraints.find(c => c.kind === "seed");
  if (!seedIn) throw new Error("promoted artifact missing seed");

  // All non-seed constraints in artifact should meet the threshold
  for (const c of artifact.structural.constraints) {
    if (c.kind === "seed") continue;
    if (c.weight < (artifact.structural.minWeight || 1.05)) {
      throw new Error("promoted codec included low-weight constraint: w=" + c.weight);
    }
  }

  await src.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.2.4: promoted codec round-trips structural shape into a fresh substrate
// ----------------------------------------------------------------------------

test("5.7.2.4 promoted codec restores structural shape into fresh substrate",
async function () {
  const src = SI.createSubstrate({ id: "src" });
  for (let i = 0; i < 5; i++) {
    await BI.feedBinary(src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  }
  const before = src.getState();
  const artifact = SM.codecs.promoted.encode(src);

  const dst = SI.createSubstrate({ id: "dst" });
  SM.codecs.promoted.decode(artifact).applyTo(dst);
  const after = dst.getState();

  // Sub-cascades should round-trip
  if (after.subcascades.length !== before.subcascades.length) {
    throw new Error("subcascade count differs after promoted restore: " +
      before.subcascades.length + " -> " + after.subcascades.length);
  }
  // Slow modulation (permanent per SE-03) should round-trip
  if (Math.abs(after.slowMod - before.slowMod) > 1e-9) {
    throw new Error("slowMod not preserved by promoted codec");
  }
  // Promoted codec drops some constraints, so dst.constraintCount should
  // be <= src.constraintCount (with seed always present)
  if (after.constraintCount > before.constraintCount) {
    throw new Error("dst has MORE constraints than src after promoted restore");
  }
  if (after.constraintCount < 1) {
    throw new Error("dst has no constraints after promoted restore");
  }

  await src.teardown();
  await dst.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.2.5: trajectory codec records snapshot sequence
// ----------------------------------------------------------------------------

test("5.7.2.5 trajectory codec records snapshots across cycles",
async function () {
  const src = SI.createSubstrate({ id: "src" });
  const recorder = SM.codecs.trajectory.beginRecording(src);

  recorder.snapshot();  // initial
  for (let i = 0; i < 5; i++) {
    await BI.feedBinary(src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
    recorder.snapshot();
  }
  if (recorder.count !== 6) throw new Error("expected 6 snapshots, got " + recorder.count);

  const artifact = recorder.finalize();
  if (artifact.codec !== "trajectory") throw new Error("wrong codec tag");
  if (!Array.isArray(artifact.snapshots)) throw new Error("snapshots not array");
  if (artifact.snapshots.length !== 6) {
    throw new Error("expected 6 snapshots in artifact, got " + artifact.snapshots.length);
  }
  if (!artifact.finalState) throw new Error("trajectory missing finalState");
  if (artifact.finalState.codec !== "promoted") {
    throw new Error("finalState should use promoted codec, got " + artifact.finalState.codec);
  }

  // Each snapshot should have a stateHash
  for (const s of artifact.snapshots) {
    if (typeof s.stateHash !== "string" || s.stateHash.length === 0) {
      throw new Error("snapshot missing stateHash");
    }
    if (typeof s.constraintCount !== "number") {
      throw new Error("snapshot missing constraintCount");
    }
  }

  // Constraint count should grow monotonically (or at least not collapse)
  const counts = artifact.snapshots.map(s => s.constraintCount);
  if (counts[counts.length - 1] <= counts[0]) {
    throw new Error("trajectory shows no constraint growth: " + counts.join(","));
  }

  await src.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.2.6: trajectory codec restores final state via promoted decoder
// ----------------------------------------------------------------------------

test("5.7.2.6 trajectory codec restores into a fresh substrate",
async function () {
  const src = SI.createSubstrate({ id: "src" });
  const recorder = SM.codecs.trajectory.beginRecording(src);
  for (let i = 0; i < 5; i++) {
    await BI.feedBinary(src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
    recorder.snapshot();
  }
  const artifact = recorder.finalize();
  const beforeState = src.getState();

  const dst = SI.createSubstrate({ id: "dst" });
  const decoded = SM.codecs.trajectory.decode(artifact);
  decoded.applyTo(dst);
  const afterState = dst.getState();

  // Sub-cascade count should round-trip (uses promoted internally)
  if (afterState.subcascades.length !== beforeState.subcascades.length) {
    throw new Error("trajectory restore lost subcascades");
  }

  // getTrajectory() returns the snapshot sequence
  const traj = decoded.getTrajectory();
  if (traj.length !== artifact.snapshots.length) {
    throw new Error("getTrajectory() length differs from artifact snapshots");
  }

  await src.teardown();
  await dst.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.2.7: content addressing is deterministic
// ----------------------------------------------------------------------------

test("5.7.2.7 same artifact produces same content address",
async function () {
  const a = { codec: "test", x: 1, y: [1, 2, 3], z: { nested: true } };
  const b = { codec: "test", z: { nested: true }, y: [1, 2, 3], x: 1 };  // same content, different key order
  const addrA = SM.computeAddress(a);
  const addrB = SM.computeAddress(b);
  if (addrA !== addrB) {
    throw new Error("content addressing not key-order-stable: " +
      addrA.slice(0, 8) + "... vs " + addrB.slice(0, 8) + "...");
  }
  // Different content -> different address
  const c = { codec: "test", x: 2, y: [1, 2, 3], z: { nested: true } };
  const addrC = SM.computeAddress(c);
  if (addrA === addrC) throw new Error("different content produced same address");
});

// ----------------------------------------------------------------------------
// 5.7.2.8: MediaStore put/get/has/delete
// ----------------------------------------------------------------------------

test("5.7.2.8 MediaStore put/get/has/delete work",
async function () {
  const store = new SM.MediaStore();
  const artifact = { codec: "test", v: 1, payload: "hello" };

  const r1 = await store.put(artifact);
  if (!r1.address) throw new Error("put returned no address");
  if (r1.alreadyStored) throw new Error("first put reported alreadyStored");

  const has = await store.has(r1.address);
  if (!has) throw new Error("store doesn't have just-put artifact");

  const got = await store.get(r1.address);
  if (!got) throw new Error("store returned null for just-put artifact");
  if (got.payload !== "hello") throw new Error("retrieved artifact wrong");

  // Idempotent put
  const r2 = await store.put(artifact);
  if (r2.address !== r1.address) throw new Error("idempotent put returned different address");
  if (!r2.alreadyStored) throw new Error("second put didn't report alreadyStored");

  // Delete
  const deleted = await store.delete(r1.address);
  if (!deleted) throw new Error("delete returned false for existing address");
  const has2 = await store.has(r1.address);
  if (has2) throw new Error("store still has after delete");
});

// ----------------------------------------------------------------------------
// 5.7.2.9: encodeAndStore + retrieveAndDecode end-to-end
// ----------------------------------------------------------------------------

test("5.7.2.9 encodeAndStore + retrieveAndDecode round-trip end-to-end",
async function () {
  const src = SI.createSubstrate({ id: "src" });
  await BI.feedBinary(src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  const before = src.getState();
  const store = new SM.MediaStore();

  const result = await SM.encodeAndStore(src, "strong", store);
  if (!result.address) throw new Error("no address returned");
  if (!result.artifact) throw new Error("no artifact returned");
  await src.teardown();

  const decoded = await SM.retrieveAndDecode(result.address, store);
  if (!decoded) throw new Error("retrieveAndDecode returned null");

  const dst = SI.createSubstrate({ id: "dst" });
  decoded.applyTo(dst);
  const after = dst.getState();

  if (before.constraintCount !== after.constraintCount) {
    throw new Error("end-to-end round-trip lost constraints");
  }

  await dst.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.2.10: artifacts from different codecs at different addresses
// ----------------------------------------------------------------------------

test("5.7.2.10 strong/promoted/trajectory artifacts get different addresses",
async function () {
  const src = SI.createSubstrate({ id: "src" });
  for (let i = 0; i < 3; i++) {
    await BI.feedBinary(src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  }

  const strongA = SM.codecs.strong.encode(src);
  const promotedA = SM.codecs.promoted.encode(src);

  const recorder = SM.codecs.trajectory.beginRecording(src);
  recorder.snapshot();
  const trajA = recorder.finalize();

  const addrStrong = SM.computeAddress(strongA);
  const addrPromoted = SM.computeAddress(promotedA);
  const addrTraj = SM.computeAddress(trajA);

  if (addrStrong === addrPromoted) throw new Error("strong and promoted same address");
  if (addrStrong === addrTraj) throw new Error("strong and trajectory same address");
  if (addrPromoted === addrTraj) throw new Error("promoted and trajectory same address");

  await src.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.2.11: substrate state encoded via promoted codec restores enough
// shape that a downstream substrate can intake it (Phase 5.7.3 prep)
// ----------------------------------------------------------------------------

test("5.7.2.11 promoted-restored substrate is operational (can take input)",
async function () {
  const src = SI.createSubstrate({ id: "src" });
  for (let i = 0; i < 5; i++) {
    await BI.feedBinary(src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  }
  const artifact = SM.codecs.promoted.encode(src);
  await src.teardown();

  const dst = SI.createSubstrate({ id: "dst" });
  SM.codecs.promoted.decode(artifact).applyTo(dst);

  // Restored substrate should be operational - take input, produce trace
  const beforeFeed = dst.getState();
  await dst.input("alpha beta gamma");
  const afterFeed = dst.getState();

  if (afterFeed.step <= beforeFeed.step) {
    throw new Error("restored substrate did not advance step under input");
  }
  if (afterFeed.traceLength <= beforeFeed.traceLength) {
    throw new Error("restored substrate did not append to trace under input");
  }

  await dst.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.2.12: round-trip preserves Phase 5.7 stack architecture
// (encode Layer 1 substrate, restore into a fresh Layer 1, verify Layer 2
// can still read its output node)
// ----------------------------------------------------------------------------

test("5.7.2.12 strong-encoded Layer 1 restores in working Phase 5.7 stack",
async function () {
  const OR = require("./output-renderer.js");
  const CI = require("./cascade-intake.js");

  const L1src = SI.createSubstrate({ id: "L1src" });
  for (let i = 0; i < 3; i++) {
    await BI.feedBinary(L1src, makeWasmFixture(), { mode: "windowed", windowSize: 8 });
  }
  const artifact = SM.codecs.strong.encode(L1src);
  await L1src.teardown();

  const L1restored = SI.createSubstrate({ id: "L1restored" });
  SM.codecs.strong.decode(artifact).applyTo(L1restored);

  const L1node = OR.createOutputNode();
  OR.render(L1restored, L1node);

  // Layer 2 should be able to read this node and produce tokens
  const tokens = CI.readNode(L1node);
  if (!tokens || tokens.length === 0) {
    throw new Error("restored Layer 1's output node yielded no tokens for Layer 2");
  }

  const L2 = SI.createSubstrate({ id: "L2" });
  await CI.drive(L2, L1node);
  const L2state = L2.getState();
  if (L2state.constraintCount <= 1) {
    throw new Error("Layer 2 didn't process the restored substrate's output");
  }

  await L1restored.teardown();
  await L2.teardown();
});

// ============================================================================
// runner
// ============================================================================

async function run() {
  let pass = 0, fail = 0;
  const failures = [];
  for (const t of tests) {
    try {
      await t.fn();
      console.log("  ok    " + t.name);
      pass += 1;
    } catch (e) {
      console.log("  FAIL  " + t.name);
      console.log("        " + (e && e.message || e));
      fail += 1;
      failures.push({ name: t.name, error: e && e.message || String(e) });
    }
  }
  console.log("");
  console.log(pass + "/" + tests.length + " tests passed");
  if (failures.length > 0) {
    console.log("");
    console.log("Failures:");
    for (const f of failures) {
      console.log("  " + f.name);
      console.log("    " + f.error);
    }
  }
  return { pass, fail, total: tests.length, failures };
}

if (require.main === module) {
  run().then(r => process.exit(r.fail === 0 ? 0 : 1));
}

module.exports = { run };
