// ============================================================================
// substrate-interaction.js  -  Phase 5.7.3 - Free-form interaction layer
// ============================================================================
//
// Restored substrates accept arbitrary new input through the standard input
// pipeline. This module provides the interaction surface and tools for
// observing how stored shape influences responsiveness.
//
// Three kinds of interaction:
//
//   1. REPLAY: re-feed the original input stream that produced the stored
//      state. Useful for verifying that a restored substrate behaves
//      identically when re-fed identical input.
//
//   2. FREE-FORM (text): feed arbitrary text input. The substrate processes
//      it through the standard token-based pipeline. Trace, deltas, and
//      constraint counts respond.
//
//   3. FREE-FORM (binary): feed arbitrary binary through the binary-intake
//      adapter. Substrate intakes bytes the same way Phase 5.7 / Layer 1
//      does for fresh substrates.
//
// The structural claim being tested: a substrate restored from stored state
// responds DIFFERENTLY to the same input than a fresh substrate would, and
// the difference reflects what the stored shape "knows."
//
// ResponseRecorder captures the substrate's response to interaction in a
// form suitable for comparison: trace deltas, modulation deltas, constraint
// changes, sub-cascade activations.
//
// ============================================================================

"use strict";

const SI = require("./substrate-instance.js");
const SM = require("./substrate-media.js");
const BI = require("./binary-intake.js");

// ============================================================================
// ResponseRecorder
//
// Captures the substrate's response to one or more interactions. Each
// interaction is recorded as a "response delta" - what changed in the
// substrate as a result of the interaction.
// ============================================================================

class ResponseRecorder {
  constructor(substrate) {
    this.substrate = substrate;
    this.responses = [];
    this._snap = this._snapshot();
  }

  _snapshot() {
    const s = this.substrate.getState();
    return {
      step: s.step,
      constraintCount: s.constraintCount,
      subcascadeCount: s.subcascades.length,
      scalarDelta: s.scalarDelta,
      fastDelta: s.fastDelta,
      slowDelta: s.slowDelta,
      slowMod: s.slowMod,
      fastMod: s.fastMod,
      ratCount: s.ratCount,
      namedCount: s.namedCount,
      traceLength: s.traceLength
    };
  }

  // Record the response to an interaction. interaction is an opaque marker
  // (e.g., a string describing what was input). The recorder snapshots
  // before and after, computes the delta, and stores it.
  record(interaction) {
    const after = this._snapshot();
    const delta = {
      interaction: interaction,
      stepDelta: after.step - this._snap.step,
      constraintDelta: after.constraintCount - this._snap.constraintCount,
      subcascadeDelta: after.subcascadeCount - this._snap.subcascadeCount,
      scalarDeltaDelta: after.scalarDelta - this._snap.scalarDelta,
      fastDeltaDelta: after.fastDelta - this._snap.fastDelta,
      slowDeltaDelta: after.slowDelta - this._snap.slowDelta,
      slowModDelta: after.slowMod - this._snap.slowMod,
      fastModDelta: after.fastMod - this._snap.fastMod,
      ratDelta: after.ratCount - this._snap.ratCount,
      namedDelta: after.namedCount - this._snap.namedCount,
      traceDelta: after.traceLength - this._snap.traceLength,
      // Final state (after this interaction) for downstream comparison
      after: after
    };
    this.responses.push(delta);
    this._snap = after;
    return delta;
  }

  getResponses() { return this.responses.slice(); }

  // Compute a structural fingerprint of the recorded responses, suitable
  // for comparing two recorders' response shapes.
  fingerprint() {
    return this.responses.map(r => ({
      step: r.stepDelta,
      c: r.constraintDelta,
      sc: r.subcascadeDelta,
      // Float deltas need finer resolution to capture restored-vs-fresh
      // distinctions (which can be 0.001-0.1 range)
      sd: Math.round(r.scalarDeltaDelta * 1e6) / 1e6,
      fd: Math.round(r.fastDeltaDelta * 1e6) / 1e6,
      slowMod: Math.round(r.slowModDelta * 1e6) / 1e6,
      fastMod: Math.round(r.fastModDelta * 1e6) / 1e6,
      // After-state contributes the absolute structural position the
      // substrate is in after the interaction, which differs greatly
      // between fresh (step=1, trace=5) and restored (step=N+1, trace=N+5)
      afterStep: r.after.step,
      afterTrace: r.after.traceLength,
      afterCC: r.after.constraintCount,
      afterSC: r.after.subcascadeCount
    }));
  }
}

// ============================================================================
// Interactor
//
// Wraps a substrate (typically one restored from media) and provides three
// interaction modes. Each interaction is recorded by an attached
// ResponseRecorder.
// ============================================================================

class Interactor {
  constructor(substrate) {
    this.substrate = substrate;
    this.recorder = new ResponseRecorder(substrate);
  }

  // Replay: feed the original input stream that produced the stored state.
  // The caller provides the input array.
  async replay(inputs) {
    for (const input of inputs) {
      await this.substrate.input(input);
      this.recorder.record({ kind: "replay", input: input });
    }
    return this.recorder.responses.length;
  }

  // Free-form text interaction.
  async sendText(text) {
    await this.substrate.input(String(text));
    return this.recorder.record({ kind: "text", text: text });
  }

  // Free-form binary interaction. Bytes are intaken through binary-intake
  // (windowed mode by default, configurable).
  async sendBinary(bytes, opts) {
    opts = opts || {};
    const eventCount = await BI.feedBinary(this.substrate, bytes, opts);
    return this.recorder.record({
      kind: "binary",
      byteLength: bytes.length,
      eventCount: eventCount,
      mode: opts.mode || "windowed"
    });
  }

  // Settle without external input - drive internal mechanisms (develop,
  // correlate, reason) for n cycles.
  async think(n) {
    await this.substrate.settle((n | 0) || 1);
    return this.recorder.record({ kind: "think", cycles: n });
  }

  // Tick - drive internal time advancement.
  async tick(n) {
    await this.substrate.tick((n | 0) || 1);
    return this.recorder.record({ kind: "tick", cycles: n });
  }

  // Get all responses.
  getResponses() { return this.recorder.getResponses(); }
  getFingerprint() { return this.recorder.fingerprint(); }
}

// ============================================================================
// Comparison helpers
//
// Comparing how two substrates respond to the same interaction sequence
// is the load-bearing operation for verifying that stored shape influences
// responsiveness.
// ============================================================================

// Compare two response sequences. Returns a structural diff describing
// where they differ.
function compareResponses(a, b) {
  if (a.length !== b.length) {
    return { equal: false, reason: "different response counts: " +
      a.length + " vs " + b.length };
  }
  const diffs = [];
  for (let i = 0; i < a.length; i++) {
    const ra = a[i], rb = b[i];
    const fields = ["stepDelta", "constraintDelta", "subcascadeDelta"];
    const floatFields = ["scalarDeltaDelta", "slowModDelta"];
    for (const f of fields) {
      if (ra[f] !== rb[f]) {
        diffs.push({ index: i, field: f, a: ra[f], b: rb[f] });
      }
    }
    for (const f of floatFields) {
      if (Math.abs((ra[f] || 0) - (rb[f] || 0)) > 1e-6) {
        diffs.push({ index: i, field: f, a: ra[f], b: rb[f] });
      }
    }
  }
  return {
    equal: diffs.length === 0,
    diffCount: diffs.length,
    diffs: diffs
  };
}

// Compare fingerprints (compact response shape). Returns true iff identical.
function fingerprintsEqual(fa, fb) {
  return JSON.stringify(fa) === JSON.stringify(fb);
}

// ============================================================================
// Convenience: load a substrate from a stored artifact and return an
// Interactor wrapping it.
// ============================================================================

async function loadInteractor(address, store, opts) {
  opts = opts || {};
  const decoded = await SM.retrieveAndDecode(address, store);
  if (!decoded) throw new Error("no artifact at address " + address);
  const substrate = SI.createSubstrate({ id: opts.id || "interactor" });
  decoded.applyTo(substrate);
  return new Interactor(substrate);
}

// ============================================================================
// Exports
// ============================================================================

module.exports = {
  ResponseRecorder: ResponseRecorder,
  Interactor: Interactor,
  compareResponses: compareResponses,
  fingerprintsEqual: fingerprintsEqual,
  loadInteractor: loadInteractor
};
