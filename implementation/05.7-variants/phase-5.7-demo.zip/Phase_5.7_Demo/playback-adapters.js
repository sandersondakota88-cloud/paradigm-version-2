// ============================================================================
// playback-adapters.js  -  Phase 5.7.4 - Interactive playback layer
// ============================================================================
//
// Translates between human-perceptual interaction and substrate operation.
// Two adapters, working in opposite directions:
//
//   1. INPUT ADAPTER (human -> substrate): clicks, keystrokes, mouse moves,
//      and other interactive events are tokenized and fed to the substrate's
//      input pipeline. Every interaction is an observation per F5/SE-09.
//
//   2. RENDER ADAPTER (substrate -> UI): substrate state is projected to a
//      structural form a UI can render. Layout regions, highlight intensity,
//      affordances, response surfaces.
//
// The adapters are designed to be browser-runnable and Node-testable. The
// input adapter accepts plain event objects (the same shape DOM events have
// in their relevant parts: type, target, key, button, etc.) and emits
// tokens. The render adapter reads substrate state and produces a structured
// "scene" object that a renderer (HTML+CSS, canvas, terminal, anything)
// can consume.
//
// Testing: feed synthetic events to the input adapter, verify the substrate
// receives appropriate tokens. Drive the substrate, verify the render
// adapter produces a scene with the expected structural surface.
//
// ============================================================================

"use strict";

// ============================================================================
// InputAdapter: maps interactive events to substrate input tokens
// ============================================================================

class InputAdapter {
  constructor(substrate, opts) {
    opts = opts || {};
    this.substrate = substrate;
    this.tokenizers = Object.assign({
      click: defaultTokenizeClick,
      key: defaultTokenizeKey,
      mousemove: defaultTokenizeMousemove,
      scroll: defaultTokenizeScroll,
      gesture: defaultTokenizeGesture,
      text: defaultTokenizeText
    }, opts.tokenizers || {});
    this.eventLog = [];
    this.maxEventLog = (opts.maxEventLog | 0) || 1000;
  }

  // Submit a single event. Returns the tokens that were generated and
  // (optionally) sent to the substrate.
  async handle(event) {
    if (!event || typeof event.type !== "string") {
      throw new Error("InputAdapter.handle: event must have type field");
    }
    const tokenizer = this.tokenizers[event.type];
    if (!tokenizer) {
      // Unknown event type: log it but don't fail. Future tokenizers can
      // be plugged in for new event types.
      return { skipped: true, eventType: event.type };
    }
    const tokens = tokenizer(event);
    if (!tokens || tokens.length === 0) {
      return { tokens: "", sent: false };
    }
    const text = Array.isArray(tokens) ? tokens.join(" ") : String(tokens);
    await this.substrate.input(text);
    this._logEvent(event, text);
    return { tokens: text, sent: true };
  }

  _logEvent(event, tokens) {
    this.eventLog.push({
      type: event.type,
      tokens: tokens,
      atStep: this.substrate.Field.step
    });
    if (this.eventLog.length > this.maxEventLog) {
      this.eventLog.splice(0, this.eventLog.length - this.maxEventLog);
    }
  }

  getEventLog() { return this.eventLog.slice(); }
}

// ----------------------------------------------------------------------------
// Default tokenizers
//
// These produce structural tokens from common UI events. The tokens are
// designed to be: distinct enough that the substrate's promotion mechanics
// can find recurring patterns, coarse enough that small-noise variations
// don't fragment recognition.
// ----------------------------------------------------------------------------

// Click: tokens encode region/role/position-bucket
//
// event = { type: "click", target: <selector or region name>, x, y, region }
function defaultTokenizeClick(event) {
  const tokens = ["click"];
  if (event.region) tokens.push("region-" + sanitize(event.region));
  if (event.target) tokens.push("target-" + sanitize(event.target));
  if (typeof event.x === "number" && typeof event.y === "number") {
    tokens.push("pos-" + bucketCoord(event.x) + "-" + bucketCoord(event.y));
  }
  if (event.button !== undefined) tokens.push("btn-" + event.button);
  return tokens;
}

// Key: tokens encode key class and modifier state
//
// event = { type: "key", key: "a", code: "KeyA", shiftKey, ctrlKey, ... }
function defaultTokenizeKey(event) {
  const tokens = ["key"];
  if (event.key) {
    tokens.push("k-" + classifyKey(event.key));
    // Also emit the literal key as a token (sanitized) so distinct keys
    // produce distinct tokens; but bucketing for readability
    if (event.key.length === 1) {
      // Single character keys: bucket into letter/digit/symbol classes
      const c = event.key.charCodeAt(0);
      if (c >= 0x30 && c <= 0x39) tokens.push("k-digit");
      else if ((c >= 0x41 && c <= 0x5A) || (c >= 0x61 && c <= 0x7A)) tokens.push("k-alpha");
      else tokens.push("k-symbol");
    }
  }
  if (event.shiftKey) tokens.push("mod-shift");
  if (event.ctrlKey) tokens.push("mod-ctrl");
  if (event.altKey) tokens.push("mod-alt");
  if (event.metaKey) tokens.push("mod-meta");
  return tokens;
}

// Mousemove: tokens encode position bucket and direction
//
// event = { type: "mousemove", x, y, dx, dy }
function defaultTokenizeMousemove(event) {
  const tokens = ["mousemove"];
  if (typeof event.x === "number" && typeof event.y === "number") {
    tokens.push("pos-" + bucketCoord(event.x) + "-" + bucketCoord(event.y));
  }
  if (typeof event.dx === "number" && typeof event.dy === "number") {
    const dir = bucketDirection(event.dx, event.dy);
    if (dir) tokens.push("dir-" + dir);
  }
  return tokens;
}

// Scroll: vertical/horizontal direction, magnitude bucket
//
// event = { type: "scroll", deltaX, deltaY }
function defaultTokenizeScroll(event) {
  const tokens = ["scroll"];
  const dx = +event.deltaX || 0, dy = +event.deltaY || 0;
  if (Math.abs(dy) > 0.5) tokens.push(dy > 0 ? "scroll-down" : "scroll-up");
  if (Math.abs(dx) > 0.5) tokens.push(dx > 0 ? "scroll-right" : "scroll-left");
  tokens.push("mag-" + bucketMagnitude(Math.max(Math.abs(dx), Math.abs(dy))));
  return tokens;
}

// Gesture: arbitrary named gestures (swipe, pinch, etc.)
//
// event = { type: "gesture", name, direction, magnitude }
function defaultTokenizeGesture(event) {
  const tokens = ["gesture"];
  if (event.name) tokens.push("g-" + sanitize(event.name));
  if (event.direction) tokens.push("dir-" + sanitize(event.direction));
  if (typeof event.magnitude === "number") {
    tokens.push("mag-" + bucketMagnitude(event.magnitude));
  }
  return tokens;
}

// Text input: passes text through with a "text" prefix so the substrate can
// distinguish keyboard-text from event-text
//
// event = { type: "text", text: "..." }
function defaultTokenizeText(event) {
  if (typeof event.text !== "string") return [];
  return ["text", event.text];
}

function sanitize(s) {
  return String(s).replace(/[^a-zA-Z0-9_-]/g, "_").substring(0, 32);
}

function classifyKey(key) {
  if (key.length === 1) return "char";
  // Common named keys
  if (/^Arrow/.test(key)) return "arrow";
  if (key === "Enter" || key === "Tab" || key === "Space") return "whitespace";
  if (key === "Escape" || key === "Backspace" || key === "Delete") return "edit";
  if (/^F\d+$/.test(key)) return "function";
  return "named";
}

function bucketCoord(c) {
  c = +c || 0;
  if (c < 0) return "neg";
  if (c < 100) return "0-100";
  if (c < 300) return "100-300";
  if (c < 600) return "300-600";
  if (c < 1000) return "600-1000";
  return "over-1000";
}

function bucketDirection(dx, dy) {
  const adx = Math.abs(dx), ady = Math.abs(dy);
  if (adx + ady < 1) return null;  // no movement
  const angle = Math.atan2(dy, dx);  // -PI to PI
  // 8-way compass
  const sector = Math.round((angle + Math.PI) / (Math.PI / 4)) % 8;
  return ["west", "nw", "north", "ne", "east", "se", "south", "sw"][sector];
}

function bucketMagnitude(m) {
  m = Math.abs(+m || 0);
  if (m < 1) return "tiny";
  if (m < 5) return "small";
  if (m < 20) return "medium";
  if (m < 100) return "large";
  return "huge";
}

// ============================================================================
// RenderAdapter: projects substrate state to a structural scene object
// ============================================================================
//
// The scene is the structure a UI renderer consumes. It's not an HTML
// document or a canvas drawing - it's a structural description that any
// renderer can interpret. Examples: a layout-region map, an intensity
// field, an affordance list.
//
// A renderer (HTML, canvas, terminal, etc.) reads the scene and produces
// the actual visual output. The scene is the substrate-side commitment;
// renderers are the human-side commitment.
//
// ============================================================================

class RenderAdapter {
  constructor(substrate, opts) {
    opts = opts || {};
    this.substrate = substrate;
    this.maxRegions = (opts.maxRegions | 0) || 16;
  }

  // Produce a scene describing the substrate's current state.
  scene() {
    const state = this.substrate.getState();
    return {
      substrateId: state.id,
      step: state.step,
      // Overall reach state - how "settled" is the substrate
      reach: this._buildReach(state),
      // Constraint intensity by kind - which structural roles are active
      kindIntensity: this._buildKindIntensity(state),
      // Promoted regions - sub-cascades become regions in the scene
      regions: this._buildRegions(state),
      // Affordances - what the substrate predicts/expects (predictive
      // constraints become affordances)
      affordances: this._buildAffordances(state),
      // Settling activity - the trace's recent activity rate
      activity: this._buildActivity(state)
    };
  }

  _buildReach(state) {
    return {
      scalar: state.scalarDelta,
      fast: state.fastDelta,
      slow: state.slowDelta,
      gap: Math.abs(state.fastDelta - state.slowDelta),
      slowMod: state.slowMod,
      fastMod: state.fastMod
    };
  }

  _buildKindIntensity(state) {
    const counts = Object.create(null);
    let total = 0;
    for (const c of state.constraints) {
      counts[c.kind] = (counts[c.kind] || 0) + 1;
      total += 1;
    }
    const intensity = Object.create(null);
    for (const k in counts) {
      intensity[k] = total > 0 ? counts[k] / total : 0;
    }
    return intensity;
  }

  _buildRegions(state) {
    // Each sub-cascade is a region. Region "intensity" is its named-count
    // relative to the substrate's overall naming activity.
    const totalNamed = Math.max(1, state.namedCount);
    return state.subcascades.slice(0, this.maxRegions).map(sc => ({
      id: sc.id,
      named: sc.namedCount,
      intensity: sc.namedCount / totalNamed,
      delta: sc.localDelta
    }));
  }

  _buildAffordances(state) {
    // Predictive constraints become affordances - the substrate is
    // structurally expecting input that would close the gap.
    return state.constraints
      .filter(c => c.kind === "predictive")
      .slice(0, 16)
      .map(c => ({
        id: c.id,
        weight: c.weight
      }));
  }

  _buildActivity(state) {
    // Trace length / step ratio gives a coarse activity rate.
    return {
      traceLength: state.traceLength,
      stepCount: state.step,
      ratio: state.step > 0 ? state.traceLength / state.step : 0,
      ratCount: state.ratCount,
      namedCount: state.namedCount
    };
  }
}

// ============================================================================
// PlaybackSession: glues input adapter + render adapter to a substrate
// ============================================================================
//
// One per playing-back substrate. Receives events through input, exposes
// scene through render. Records both for replay/audit.
// ============================================================================

class PlaybackSession {
  constructor(substrate, opts) {
    opts = opts || {};
    this.substrate = substrate;
    this.input = new InputAdapter(substrate, opts.input);
    this.render = new RenderAdapter(substrate, opts.render);
    this.history = [];
    this.maxHistory = (opts.maxHistory | 0) || 500;
  }

  // Handle an event and return the resulting scene.
  async handle(event) {
    const result = await this.input.handle(event);
    const scene = this.render.scene();
    this.history.push({
      atStep: this.substrate.Field.step,
      eventType: event.type,
      tokens: result.tokens || "",
      reach: scene.reach,
      regionCount: scene.regions.length
    });
    if (this.history.length > this.maxHistory) {
      this.history.splice(0, this.history.length - this.maxHistory);
    }
    return scene;
  }

  // Get the current scene without sending an event.
  currentScene() { return this.render.scene(); }

  getHistory() { return this.history.slice(); }
}

module.exports = {
  InputAdapter: InputAdapter,
  RenderAdapter: RenderAdapter,
  PlaybackSession: PlaybackSession,
  // Tokenizers exposed for custom override or testing
  defaultTokenizeClick: defaultTokenizeClick,
  defaultTokenizeKey: defaultTokenizeKey,
  defaultTokenizeMousemove: defaultTokenizeMousemove,
  defaultTokenizeScroll: defaultTokenizeScroll,
  defaultTokenizeGesture: defaultTokenizeGesture,
  defaultTokenizeText: defaultTokenizeText,
  // Bucketing helpers
  bucketCoord: bucketCoord,
  bucketDirection: bucketDirection,
  bucketMagnitude: bucketMagnitude,
  classifyKey: classifyKey
};
