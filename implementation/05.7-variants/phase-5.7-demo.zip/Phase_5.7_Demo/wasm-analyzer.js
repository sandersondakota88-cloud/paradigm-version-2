// ============================================================================
// wasm-analyzer.js  -  Spec-derived structural metrics from WASM bytes
// ============================================================================
//
// Computes ground-truth metrics about a WASM module by inspecting the bytes
// directly. No substrate involvement. The output is the reference against
// which substrate behavior is compared.
//
// Metrics computed:
//
//   length          : total byte count
//   sectionMap      : array of { id, idName, byteOffset, byteLength }
//   byteFrequency   : array index 0..255 -> count of that byte in module
//   topByteRanks    : top-N bytes ranked by frequency
//   opcodeCounts    : { opcodeHex: count } for opcodes that appear in code
//                     section bodies (not for header/section-id bytes)
//   coOccurrences   : { "byteA-byteB": count } for ordered pairs within a
//                     window of W bytes
//   topCoOccurrences: top pairs by frequency (after filtering)
//   structuralBytes : counts of bytes that have specific structural meaning
//                     (magic numbers, section IDs, opcodes)
//
// Limitations: this is a metric extractor, not a full WASM disassembler. It
// trusts that the input is well-formed WASM. It does not validate semantics.
// For our corpus modules (built from spec), the bytes are guaranteed valid.
// ============================================================================

"use strict";

const W = require("./wasm-corpus.js");

// ----------------------------------------------------------------------------
// Section ID -> human name mapping
// ----------------------------------------------------------------------------

const SECTION_NAME = Object.freeze({
  0x00: "custom",
  0x01: "type",
  0x02: "import",
  0x03: "function",
  0x04: "table",
  0x05: "memory",
  0x06: "global",
  0x07: "export",
  0x08: "start",
  0x09: "element",
  0x0A: "code",
  0x0B: "data"
});

// ----------------------------------------------------------------------------
// LEB128 unsigned decoder
// ----------------------------------------------------------------------------

function readLEB128u(bytes, offset) {
  let result = 0;
  let shift = 0;
  let pos = offset;
  while (true) {
    const byte = bytes[pos++];
    result |= (byte & 0x7F) << shift;
    if ((byte & 0x80) === 0) break;
    shift += 7;
  }
  return { value: result, length: pos - offset };
}

// ----------------------------------------------------------------------------
// Section map: walk the module, record where each section starts/ends
// ----------------------------------------------------------------------------

function buildSectionMap(bytes) {
  // Magic + version is the first 8 bytes
  if (bytes.length < 8) throw new Error("module too short for header");
  if (bytes[0] !== 0x00 || bytes[1] !== 0x61 || bytes[2] !== 0x73 || bytes[3] !== 0x6D) {
    throw new Error("not a WASM module: bad magic");
  }

  const sections = [];
  let pos = 8;  // past magic + version
  while (pos < bytes.length) {
    const id = bytes[pos];
    const sizeStart = pos + 1;
    const { value: payloadSize, length: sizeLen } = readLEB128u(bytes, sizeStart);
    const payloadStart = sizeStart + sizeLen;
    const payloadEnd = payloadStart + payloadSize;
    sections.push({
      id: id,
      idName: SECTION_NAME[id] || ("unknown-" + id),
      byteOffset: pos,
      byteLength: 1 + sizeLen + payloadSize,
      payloadOffset: payloadStart,
      payloadLength: payloadSize
    });
    pos = payloadEnd;
  }
  return sections;
}

// ----------------------------------------------------------------------------
// Byte frequency table
// ----------------------------------------------------------------------------

function byteFrequency(bytes) {
  const freq = new Array(256).fill(0);
  for (let i = 0; i < bytes.length; i++) {
    freq[bytes[i]] += 1;
  }
  return freq;
}

function topByteRanks(freq, n) {
  const entries = [];
  for (let b = 0; b < 256; b++) {
    if (freq[b] > 0) entries.push({ byte: b, count: freq[b] });
  }
  entries.sort((a, b) => b.count - a.count || a.byte - b.byte);
  return entries.slice(0, n || 10);
}

// ----------------------------------------------------------------------------
// Opcode counts: scan the code section bodies for known opcodes
//
// We do a permissive scan - count any byte that matches a known opcode
// inside the code section's body region. This is approximate; some bytes
// in code section bodies are immediates (like local indices), not opcodes.
// We accept that approximation here; it's consistent across modules.
// ----------------------------------------------------------------------------

function opcodeCounts(bytes, sections) {
  const known = {
    0x02: "block", 0x03: "loop", 0x04: "if", 0x05: "else",
    0x0B: "end", 0x0C: "br", 0x0D: "br_if", 0x0F: "return",
    0x10: "call", 0x20: "local.get", 0x21: "local.set",
    0x41: "i32.const", 0x45: "i32.eqz", 0x48: "i32.lt_s",
    0x6A: "i32.add", 0x6B: "i32.sub", 0x6C: "i32.mul"
  };

  const counts = Object.create(null);
  for (const k of Object.values(known)) counts[k] = 0;

  const codeSec = sections.find(s => s.id === 0x0A);
  if (!codeSec) return counts;

  // Permissive byte-scan within code section body
  const start = codeSec.payloadOffset;
  const end = start + codeSec.payloadLength;
  for (let i = start; i < end; i++) {
    const name = known[bytes[i]];
    if (name) counts[name] = (counts[name] || 0) + 1;
  }
  return counts;
}

// ----------------------------------------------------------------------------
// Co-occurrence: count ordered byte pairs within a window
//
// For each position i, for each j in [i+1, i+windowSize], record the pair
// (bytes[i], bytes[j]). Returns a map { "AA-BB": count } where AA, BB are
// the bytes in lowercase 2-digit hex.
// ----------------------------------------------------------------------------

function coOccurrences(bytes, windowSize) {
  const W = (windowSize | 0) || 4;
  const out = Object.create(null);
  for (let i = 0; i < bytes.length - 1; i++) {
    const a = bytes[i];
    for (let k = 1; k <= W && i + k < bytes.length; k++) {
      const b = bytes[i + k];
      const key = a.toString(16).padStart(2, "0") + "-" +
                  b.toString(16).padStart(2, "0");
      out[key] = (out[key] || 0) + 1;
    }
  }
  return out;
}

function topCoOccurrences(coMap, n) {
  const entries = Object.entries(coMap).map(([k, v]) => ({ pair: k, count: v }));
  entries.sort((a, b) => b.count - a.count || (a.pair < b.pair ? -1 : 1));
  return entries.slice(0, n || 10);
}

// ----------------------------------------------------------------------------
// Full analysis: package everything together
// ----------------------------------------------------------------------------

function analyze(bytes, opts) {
  opts = opts || {};
  const windowSize = opts.windowSize || 4;
  const sectionMap = buildSectionMap(bytes);
  const freq = byteFrequency(bytes);
  const top = topByteRanks(freq, 10);
  const opcodes = opcodeCounts(bytes, sectionMap);
  const co = coOccurrences(bytes, windowSize);
  const topCo = topCoOccurrences(co, 10);

  return {
    length: bytes.length,
    sectionMap: sectionMap,
    byteFrequency: freq,
    topByteRanks: top,
    opcodeCounts: opcodes,
    coOccurrences: co,
    topCoOccurrences: topCo,
    nonzeroByteCount: top.length === 10
      ? freq.filter(c => c > 0).length
      : top.length
  };
}

module.exports = {
  buildSectionMap: buildSectionMap,
  byteFrequency:   byteFrequency,
  topByteRanks:    topByteRanks,
  opcodeCounts:    opcodeCounts,
  coOccurrences:   coOccurrences,
  topCoOccurrences: topCoOccurrences,
  analyze:         analyze,
  readLEB128u:     readLEB128u,
  SECTION_NAME:    SECTION_NAME
};
