// ============================================================================
// wasm-corpus.js  -  Hand-built WASM modules with known structure
// ============================================================================
//
// Generates three small, valid WASM 1.0 modules whose byte-level structure is
// fully known. Used as ground-truth fixtures for substrate alignment tests.
//
// Each module's byte layout is documented inline. Anyone can verify the bytes
// against the WASM spec at https://webassembly.github.io/spec/core/binary/.
//
// Three modules:
//
//   1. ADD: single function add(i32, i32) -> i32 returning sum.
//      Smallest meaningful WASM. Few opcodes, simple structure.
//
//   2. FIB: recursive fibonacci(i32) -> i32.
//      Has control flow (if/else), self-call (recursion), more opcode
//      variety.
//
//   3. MULTI: three functions (add, sub, mul) plus a memory section.
//      Most structurally rich. Multiple function bodies. Multiple
//      sections. Higher byte variety.
//
// Each module's "ground truth" object lists exactly which bytes appear
// where, what opcodes are present, what sections exist, and what
// co-occurrences hold. Tests use this ground truth as the reference.
//
// ============================================================================

"use strict";

// ----------------------------------------------------------------------------
// Helpers: LEB128 encoding (unsigned)
// ----------------------------------------------------------------------------

function leb128u(n) {
  const out = [];
  do {
    let byte = n & 0x7F;
    n >>>= 7;
    if (n !== 0) byte |= 0x80;
    out.push(byte);
  } while (n !== 0);
  return out;
}

// Build one section: [section_id, leb128(payload.length), ...payload]
function section(id, payload) {
  return [id, ...leb128u(payload.length), ...payload];
}

// vec(payload) prepends payload count (LEB128).
function vec(items) {
  return [...leb128u(items.length), ...items.flat()];
}

// ----------------------------------------------------------------------------
// WASM constants we use
// ----------------------------------------------------------------------------

// Magic + version (fixed first 8 bytes of every WASM module)
const MAGIC = [0x00, 0x61, 0x73, 0x6D];
const VERSION = [0x01, 0x00, 0x00, 0x00];

// Section IDs
const SEC = {
  TYPE:     0x01,
  IMPORT:   0x02,
  FUNCTION: 0x03,
  MEMORY:   0x05,
  EXPORT:   0x07,
  CODE:     0x0A
};

// Value types
const VAL = {
  I32: 0x7F,
  I64: 0x7E
};

// Type form
const FUNC_TYPE = 0x60;

// Export kinds
const EXPORT_KIND = {
  FUNC: 0x00,
  MEMORY: 0x02
};

// Opcodes we use
const OP = {
  END:           0x0B,
  RETURN:        0x0F,
  CALL:          0x10,
  LOCAL_GET:     0x20,
  LOCAL_SET:     0x21,
  I32_CONST:     0x41,
  I32_EQZ:       0x45,
  I32_LT_S:      0x48,
  I32_ADD:       0x6A,
  I32_SUB:       0x6B,
  I32_MUL:       0x6C,
  IF:            0x04,
  ELSE:          0x05,
  BLOCK:         0x02
};

// ----------------------------------------------------------------------------
// MODULE 1: ADD
// ----------------------------------------------------------------------------
//
// Function add(a: i32, b: i32) -> i32 { return a + b; }
// Body: local.get 0; local.get 1; i32.add; end
//
// Sections:
//   1 (type):     1 type: func(i32, i32) -> i32
//   3 (function): 1 function of type 0
//   7 (export):   "add" -> func 0
//   10 (code):    1 body: 0 locals; local.get 0; local.get 1; i32.add; end
// ----------------------------------------------------------------------------

function buildAddModule() {
  // Type section: 1 entry, func(i32,i32)->i32
  const typeSection = section(SEC.TYPE, [
    0x01,                            // 1 type entry
    FUNC_TYPE,                       // 0x60
    0x02, VAL.I32, VAL.I32,          // 2 params: i32, i32
    0x01, VAL.I32                    // 1 result: i32
  ]);

  // Function section: 1 function with type index 0
  const funcSection = section(SEC.FUNCTION, [
    0x01,                            // 1 function entry
    0x00                             // type index 0
  ]);

  // Export section: 1 export: "add" -> func 0
  const exportName = [0x61, 0x64, 0x64];  // "add"
  const exportSection = section(SEC.EXPORT, [
    0x01,                            // 1 export
    exportName.length, ...exportName,
    EXPORT_KIND.FUNC, 0x00
  ]);

  // Code section: 1 body
  const body = [
    0x00,                            // 0 local declarations
    OP.LOCAL_GET, 0x00,
    OP.LOCAL_GET, 0x01,
    OP.I32_ADD,
    OP.END
  ];
  const codeSection = section(SEC.CODE, [
    0x01,                            // 1 body
    body.length, ...body
  ]);

  return new Uint8Array([
    ...MAGIC, ...VERSION,
    ...typeSection,
    ...funcSection,
    ...exportSection,
    ...codeSection
  ]);
}

// ----------------------------------------------------------------------------
// MODULE 2: FIB
// ----------------------------------------------------------------------------
//
// Function fib(n: i32) -> i32 {
//   if (n < 2) return n;
//   return fib(n - 1) + fib(n - 2);
// }
//
// Sections:
//   1 (type):     1 type: func(i32) -> i32
//   3 (function): 1 function of type 0
//   7 (export):   "fib" -> func 0
//   10 (code):    1 body with control flow and self-call
// ----------------------------------------------------------------------------

function buildFibModule() {
  const typeSection = section(SEC.TYPE, [
    0x01, FUNC_TYPE,
    0x01, VAL.I32,                   // 1 param: i32
    0x01, VAL.I32                    // 1 result: i32
  ]);

  const funcSection = section(SEC.FUNCTION, [0x01, 0x00]);

  const exportName = [0x66, 0x69, 0x62];  // "fib"
  const exportSection = section(SEC.EXPORT, [
    0x01,
    exportName.length, ...exportName,
    EXPORT_KIND.FUNC, 0x00
  ]);

  // Body:
  //   local.get 0
  //   i32.const 2
  //   i32.lt_s              // n < 2 ?
  //   if (i32 result)
  //     local.get 0         // return n
  //   else
  //     local.get 0
  //     i32.const 1
  //     i32.sub
  //     call 0              // fib(n-1)
  //     local.get 0
  //     i32.const 2
  //     i32.sub
  //     call 0              // fib(n-2)
  //     i32.add
  //   end
  //   end
  const body = [
    0x00,                            // 0 local declarations
    OP.LOCAL_GET, 0x00,
    OP.I32_CONST, 0x02,
    OP.I32_LT_S,
    OP.IF, VAL.I32,                  // if returns i32
      OP.LOCAL_GET, 0x00,
    OP.ELSE,
      OP.LOCAL_GET, 0x00,
      OP.I32_CONST, 0x01,
      OP.I32_SUB,
      OP.CALL, 0x00,
      OP.LOCAL_GET, 0x00,
      OP.I32_CONST, 0x02,
      OP.I32_SUB,
      OP.CALL, 0x00,
      OP.I32_ADD,
    OP.END,                          // end of if
    OP.END                           // end of function
  ];
  const codeSection = section(SEC.CODE, [
    0x01,
    body.length, ...body
  ]);

  return new Uint8Array([
    ...MAGIC, ...VERSION,
    ...typeSection,
    ...funcSection,
    ...exportSection,
    ...codeSection
  ]);
}

// ----------------------------------------------------------------------------
// MODULE 3: MULTI
// ----------------------------------------------------------------------------
//
// Three functions:
//   add(i32,i32)->i32  : a + b
//   sub(i32,i32)->i32  : a - b
//   mul(i32,i32)->i32  : a * b
// Plus a memory section (1 page minimum, no maximum).
//
// All three functions share one type signature. Three exports. Three bodies.
// Memory exported as "mem".
// ----------------------------------------------------------------------------

function buildMultiModule() {
  const typeSection = section(SEC.TYPE, [
    0x01, FUNC_TYPE,
    0x02, VAL.I32, VAL.I32,
    0x01, VAL.I32
  ]);

  // Three functions, all type 0
  const funcSection = section(SEC.FUNCTION, [
    0x03, 0x00, 0x00, 0x00
  ]);

  // Memory section: 1 memory, no maximum, initial = 1 page
  const memorySection = section(SEC.MEMORY, [
    0x01,                            // 1 memory entry
    0x00,                            // limits flag: no max
    0x01                             // initial = 1 page
  ]);

  // Exports: "add"->func 0, "sub"->func 1, "mul"->func 2, "mem"->memory 0
  const addName = [0x61, 0x64, 0x64];
  const subName = [0x73, 0x75, 0x62];
  const mulName = [0x6D, 0x75, 0x6C];
  const memName = [0x6D, 0x65, 0x6D];
  const exportSection = section(SEC.EXPORT, [
    0x04,                            // 4 exports
    addName.length, ...addName, EXPORT_KIND.FUNC, 0x00,
    subName.length, ...subName, EXPORT_KIND.FUNC, 0x01,
    mulName.length, ...mulName, EXPORT_KIND.FUNC, 0x02,
    memName.length, ...memName, EXPORT_KIND.MEMORY, 0x00
  ]);

  // Three bodies
  const addBody = [0x00, OP.LOCAL_GET, 0x00, OP.LOCAL_GET, 0x01, OP.I32_ADD, OP.END];
  const subBody = [0x00, OP.LOCAL_GET, 0x00, OP.LOCAL_GET, 0x01, OP.I32_SUB, OP.END];
  const mulBody = [0x00, OP.LOCAL_GET, 0x00, OP.LOCAL_GET, 0x01, OP.I32_MUL, OP.END];

  const codeSection = section(SEC.CODE, [
    0x03,                            // 3 bodies
    addBody.length, ...addBody,
    subBody.length, ...subBody,
    mulBody.length, ...mulBody
  ]);

  return new Uint8Array([
    ...MAGIC, ...VERSION,
    ...typeSection,
    ...funcSection,
    ...memorySection,
    ...exportSection,
    ...codeSection
  ]);
}

// ----------------------------------------------------------------------------
// Ground-truth metadata for each module
// ----------------------------------------------------------------------------
//
// Each module's metadata tells the alignment tests:
//   - Total byte length
//   - Section list with byte offsets and IDs
//   - Opcodes present and their counts
//   - Top byte frequencies
//   - Co-occurrence pairs (within window distance)
//
// All values computed by inspecting the bytes the build functions produce.
// ----------------------------------------------------------------------------

function buildCorpus() {
  return {
    add:   { name: "add",   bytes: buildAddModule()   },
    fib:   { name: "fib",   bytes: buildFibModule()   },
    multi: { name: "multi", bytes: buildMultiModule() }
  };
}

module.exports = {
  buildAddModule:   buildAddModule,
  buildFibModule:   buildFibModule,
  buildMultiModule: buildMultiModule,
  buildCorpus:      buildCorpus,
  SEC: SEC,
  OP:  OP,
  VAL: VAL,
  MAGIC: MAGIC,
  VERSION: VERSION,
  leb128u: leb128u
};
