// ============================================================================
// browser-verify.js  -  Real-browser verification of playback-harness.html
// ============================================================================
//
// Spins up a local HTTP server, launches headless Chromium via Playwright,
// loads playback-harness.html, runs a programmatic interaction sequence,
// and reports:
//   - Console errors (anything logged at error level)
//   - Page exceptions (uncaught throws)
//   - Whether each interaction produced the expected substrate state change
//
// What this verifies:
//   1. The harness loads without errors (script loading, module imports)
//   2. The Train button drives the substrate (constraint count grows)
//   3. The Save button creates a saved-state entry
//   4. The Load button restores from a saved state
//   5. Canvas clicks advance the substrate
//   6. Text input advances the substrate
//   7. Reset returns the substrate to fresh state
//
// Anything failing produces a clear FAIL line; everything else is OK.
//
// ============================================================================

"use strict";

const path = require("path");
const http = require("http");
const fs = require("fs");
const url = require("url");

const PLAYWRIGHT_PATH = "/home/claude/.npm-global/lib/node_modules/playwright";
const pw = require(PLAYWRIGHT_PATH);

const ROOT = __dirname;
const PORT = 18373;

// ----------------------------------------------------------------------------
// Tiny static HTTP server scoped to the verification dir
// ----------------------------------------------------------------------------

function startServer() {
  const MIME = {
    ".html": "text/html",
    ".js":   "application/javascript",
    ".css":  "text/css",
    ".json": "application/json",
    ".wgsl": "text/plain"
  };
  const server = http.createServer((req, res) => {
    const u = url.parse(req.url);
    const requested = decodeURIComponent(u.pathname);
    const safe = path.normalize(requested).replace(/^(\.\.[\/\\])+/, "");
    const filepath = path.join(ROOT, safe);
    if (!filepath.startsWith(ROOT)) {
      res.writeHead(403); res.end("forbidden"); return;
    }
    fs.stat(filepath, (err, stat) => {
      if (err || !stat.isFile()) {
        res.writeHead(404); res.end("not found: " + safe); return;
      }
      const ext = path.extname(filepath).toLowerCase();
      res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
      fs.createReadStream(filepath).pipe(res);
    });
  });
  return new Promise(resolve => {
    server.listen(PORT, "127.0.0.1", () => resolve(server));
  });
}

// ----------------------------------------------------------------------------
// Verification flow
// ----------------------------------------------------------------------------

async function verify() {
  const issues = [];
  const checks = [];

  function log(kind, msg) {
    const line = "  " + kind.padEnd(6, " ") + " " + msg;
    console.log(line);
    checks.push({ kind, msg });
    if (kind === "FAIL") issues.push(msg);
  }

  const server = await startServer();
  log("ok", "static server up on 127.0.0.1:" + PORT);

  let browser;
  try {
    browser = await pw.chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Capture console errors and page exceptions
    const consoleErrors = [];
    const pageErrors = [];
    page.on("console", m => {
      if (m.type() === "error") consoleErrors.push(m.text());
    });
    page.on("pageerror", e => pageErrors.push(e.message + (e.stack ? "\n" + e.stack : "")));

    // Load the harness
    await page.goto("http://127.0.0.1:" + PORT + "/playback-harness.html", {
      waitUntil: "networkidle",
      timeout: 15000
    });
    log("ok", "page navigated to playback-harness.html");

    // Wait for the script-block's top-level awaits to finish (loading the
    // 5 module scripts plus initial render). The status text changes to
    // "READY" at the end of the script block.
    try {
      await page.waitForFunction(() => {
        const el = document.getElementById("status");
        return el && el.textContent === "READY";
      }, { timeout: 10000 });
      log("ok", "status reached READY (all module scripts loaded)");
    } catch (e) {
      log("FAIL", "status never reached READY: " + e.message);
      // Capture current state for diagnosis
      const status = await page.$eval("#status", el => el.textContent).catch(() => "<missing>");
      log("info", "current status: " + status);
    }

    // ---- Verify Train button drives substrate ----
    let preTrainCN = await page.$eval("#m-cn", el => +el.textContent).catch(() => null);
    log("info", "pre-train constraint count: " + preTrainCN);

    await page.click("#train-btn");
    // Train fires 5 cycles of feedBinary; can take a moment
    await page.waitForFunction(prev => {
      const el = document.getElementById("m-cn");
      return el && +el.textContent > prev;
    }, preTrainCN === null ? 0 : preTrainCN, { timeout: 15000 }).catch(() => null);

    let postTrainCN = await page.$eval("#m-cn", el => +el.textContent).catch(() => null);
    let postTrainStep = await page.$eval("#m-step", el => +el.textContent).catch(() => null);
    log("info", "post-train constraint count: " + postTrainCN + " step: " + postTrainStep);

    if (postTrainCN === null || preTrainCN === null) {
      log("FAIL", "could not read constraint count metric from page");
    } else if (postTrainCN <= preTrainCN) {
      log("FAIL", "Train did not advance constraints: " + preTrainCN + " -> " + postTrainCN);
    } else {
      log("ok", "Train button drove substrate (constraints " + preTrainCN + " -> " + postTrainCN + ")");
    }

    // ---- Verify Save button ----
    await page.click("#save-btn");
    await page.waitForTimeout(150);
    const savedListContent = await page.$eval("#saved-list", el => el.textContent || el.innerText).catch(() => "");
    if (savedListContent.includes("(no saved states)") || savedListContent.length < 5) {
      log("FAIL", "Save button did not produce a saved-state entry. saved-list: " + JSON.stringify(savedListContent));
    } else {
      log("ok", "Save button created saved-state entry");
    }

    // ---- Verify Reset, then Load to restore ----
    await page.click("#reset-btn");
    await page.waitForTimeout(150);
    const afterResetCN = await page.$eval("#m-cn", el => +el.textContent).catch(() => null);
    if (afterResetCN === null) {
      log("FAIL", "could not read constraint count after reset");
    } else if (afterResetCN > 5) {
      log("FAIL", "Reset did not return substrate to fresh state: " + afterResetCN + " constraints");
    } else {
      log("ok", "Reset returned substrate to fresh state (" + afterResetCN + " constraints)");
    }

    await page.click("#load-btn");
    await page.waitForTimeout(200);
    const afterLoadCN = await page.$eval("#m-cn", el => +el.textContent).catch(() => null);
    if (afterLoadCN === null) {
      log("FAIL", "could not read constraint count after load");
    } else if (afterLoadCN <= afterResetCN) {
      log("FAIL", "Load did not restore from saved state: " + afterResetCN + " -> " + afterLoadCN);
    } else {
      log("ok", "Load restored saved state (" + afterResetCN + " -> " + afterLoadCN + ")");
    }

    // ---- Verify canvas clicks ----
    const preCanvasStep = await page.$eval("#m-step", el => +el.textContent).catch(() => null);
    const canvasBox = await page.$("#canvas").then(h => h.boundingBox());
    if (canvasBox) {
      await page.mouse.click(canvasBox.x + 100, canvasBox.y + 100);
      await page.waitForTimeout(150);
      const postCanvasStep = await page.$eval("#m-step", el => +el.textContent).catch(() => null);
      if (postCanvasStep === null) {
        log("FAIL", "could not read step after canvas click");
      } else if (postCanvasStep <= preCanvasStep) {
        log("FAIL", "Canvas click did not advance substrate: step " + preCanvasStep + " -> " + postCanvasStep);
      } else {
        log("ok", "Canvas click advanced substrate (step " + preCanvasStep + " -> " + postCanvasStep + ")");
      }
    } else {
      log("FAIL", "canvas element has no bounding box");
    }

    // ---- Verify text input ----
    const preTextStep = await page.$eval("#m-step", el => +el.textContent).catch(() => null);
    await page.fill("#text-input", "alpha beta gamma");
    await page.press("#text-input", "Enter");
    await page.waitForTimeout(150);
    const postTextStep = await page.$eval("#m-step", el => +el.textContent).catch(() => null);
    if (postTextStep === null) {
      log("FAIL", "could not read step after text input");
    } else if (postTextStep <= preTextStep) {
      log("FAIL", "Text input did not advance substrate: " + preTextStep + " -> " + postTextStep);
    } else {
      log("ok", "Text input advanced substrate (step " + preTextStep + " -> " + postTextStep + ")");
    }

    // ---- Capture screenshot for visual record ----
    const shotPath = path.join(ROOT, "playback-harness.screenshot.png");
    await page.screenshot({ path: shotPath, fullPage: false });
    log("ok", "screenshot saved: " + shotPath);

    // ---- Final console / page error tally ----
    if (consoleErrors.length > 0) {
      log("FAIL", consoleErrors.length + " console error(s):");
      for (const ce of consoleErrors) console.log("         | " + ce);
    } else {
      log("ok", "no console errors");
    }
    if (pageErrors.length > 0) {
      log("FAIL", pageErrors.length + " page exception(s):");
      for (const pe of pageErrors) console.log("         | " + pe.split("\n")[0]);
    } else {
      log("ok", "no page exceptions");
    }
  } catch (e) {
    log("FAIL", "verification threw: " + e.message);
    if (e.stack) console.log(e.stack);
  } finally {
    if (browser) await browser.close();
    server.close();
  }

  console.log("");
  if (issues.length === 0) {
    console.log("VERIFY OK - browser harness works as expected");
    return 0;
  } else {
    console.log("VERIFY FAILED with " + issues.length + " issue(s):");
    for (const i of issues) console.log("  - " + i);
    return 1;
  }
}

if (require.main === module) {
  verify().then(code => process.exit(code));
}
