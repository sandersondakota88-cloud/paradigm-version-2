// ============================================================================
// test-phase5-7-6-recursive.js  -  Phase 5.7.6 recursive feedback tests
// ============================================================================
//
// Verifies the recursive-feedback experiment empirically:
//
//   1. Recursive coupling converges (no divergence/oscillation)
//   2. Architecture's bounding mechanisms hold under recursion (eviction
//      caps constraint count, F4/X2 hold)
//   3. Naive recursive encoding saturates around encoding markers (real
//      finding from initial run; documents the failure mode)
//   4. Low-saturation encoding partially desaturates but kind-codes still
//      dominate
//   5. Spectral-subtraction (delta) encoding desaturates fully and
//      preserves WASM signal
//   6. Recursive amplification with desaturation improves co-occurrence
//      detection above baseline
//   7. Determinism: same input + same encoding mode produces same final state
//
// The test suite documents that recursive feedback works AND that
// desaturation is required to preserve signal under recursion. Both halves
// are empirical findings.
// ============================================================================

"use strict";

const W = require("./wasm-corpus.js");
const A = require("./wasm-analyzer.js");
const SI = require("./substrate-instance.js");
const SM = require("./substrate-metrics.js");
const RR = require("./recursive-reencoder.js");

const tests = [];
function test(name, fn) { tests.push({ name: name, fn: fn }); }

async function runCondition(bytes, opts) {
  const sub = SI.createSubstrate({ id: "rec-test" });
  const recs = await RR.driveRecursive(sub, bytes, opts);
  const final = SM.extract(sub);
  await sub.teardown();
  return { records: recs, final: final };
}

// ----------------------------------------------------------------------------
// 5.7.6.1: re-encoder produces non-empty bytes from a populated node
// ----------------------------------------------------------------------------

test("5.7.6.1 reencoder produces bytes from populated node", async function () {
  const SI = require("./substrate-instance.js");
  const BI = require("./binary-intake.js");
  const OR = require("./output-renderer.js");

  const sub = SI.createSubstrate({ id: "encode-test" });
  const node = OR.createOutputNode();
  await BI.feedBinary(sub, W.buildCorpus().add.bytes, { mode: "windowed", windowSize: 4 });
  OR.render(sub, node);

  const fullBytes = RR.reencode(node);
  const lowSatBytes = RR.reencode(node, { lowSaturation: true });

  if (fullBytes.length < 20) throw new Error("full encoding too short: " + fullBytes.length);
  if (lowSatBytes.length < 5) throw new Error("low-sat encoding too short: " + lowSatBytes.length);
  if (fullBytes.length <= lowSatBytes.length) {
    throw new Error("low-sat should be smaller than full encoding");
  }

  await sub.teardown();
});

// ----------------------------------------------------------------------------
// 5.7.6.2: recursive coupling converges (no divergence, constraint count bounded)
// ----------------------------------------------------------------------------

test("5.7.6.2 recursive coupling converges to bounded constraint count",
async function () {
  const bytes = W.buildCorpus().add.bytes;
  const result = await runCondition(bytes, { cycles: 20, recursive: true });

  // After 20 cycles, constraint count should plateau (eviction kicks in)
  // Specifically: counts should not grow monotonically
  const counts = result.records.map(r => r.constraintCount);
  const lastFew = counts.slice(-5);
  const first = lastFew[0];
  const last = lastFew[lastFew.length - 1];
  if (last > first * 1.1) {
    throw new Error("constraint count still growing in last 5 cycles: " + lastFew.join(","));
  }
  // Final count should be bounded - the substrate's eviction mechanism caps it
  if (result.final.constraintCount > 500) {
    throw new Error("constraint count unbounded: " + result.final.constraintCount);
  }
});

// ----------------------------------------------------------------------------
// 5.7.6.3: F4/X2 hold under recursion (substrate doesn't collapse to delta=0)
// ----------------------------------------------------------------------------

test("5.7.6.3 substrate maintains non-zero scalar delta under recursion",
async function () {
  const bytes = W.buildCorpus().add.bytes;
  const result = await runCondition(bytes, { cycles: 20, recursive: true });
  if (result.final.reachState.scalarDelta < 1e-6) {
    throw new Error("substrate collapsed to delta=0 under recursion");
  }
  // Settling indicator (slow delta) should remain bounded too
  if (result.final.reachState.slowDelta < 0.01) {
    throw new Error("slow delta collapsed under recursion");
  }
});

// ----------------------------------------------------------------------------
// 5.7.6.4: naive recursive encoding saturates around marker bytes
// ----------------------------------------------------------------------------

test("5.7.6.4 naive recursive encoding saturates (top bytes are markers)",
async function () {
  const bytes = W.buildCorpus().add.bytes;
  const result = await runCondition(bytes, { cycles: 20, recursive: true });
  const topBytes = result.final.topBytes.slice(0, 3).map(e => e.byte);
  // Naive encoding has 0xFF separators and 0xC8 constraint markers; both
  // should appear in top 3 (this documents the saturation behavior)
  if (topBytes.indexOf(0xFF) < 0 && topBytes.indexOf(0xC8) < 0) {
    throw new Error("expected marker saturation: top bytes are " +
      topBytes.map(b => "0x" + b.toString(16)).join(", "));
  }
});

// ----------------------------------------------------------------------------
// 5.7.6.5: WASM ground-truth alignment is destroyed under naive recursion
// ----------------------------------------------------------------------------

test("5.7.6.5 naive recursion destroys WASM rank correlation",
async function () {
  const bytes = W.buildCorpus().add.bytes;
  const wasmA = A.analyze(bytes);
  const result = await runCondition(bytes, { cycles: 20, recursive: true });
  const rc = SM.rankCorrelation(wasmA.topByteRanks, result.final.topBytes);
  // The naive recursion should have low or negative correlation; it
  // documents the destruction. We expect rc < 0.5 (much worse than baseline)
  if (rc !== null && rc >= 0.5) {
    throw new Error("naive recursion preserved high correlation (" +
      rc.toFixed(3) + "); expected destruction");
  }
});

// ----------------------------------------------------------------------------
// 5.7.6.6: spectral-subtraction (delta) encoding desaturates - top bytes
// are WASM bytes, not encoding markers
// ----------------------------------------------------------------------------

test("5.7.6.6 delta encoding desaturates (top bytes are WASM bytes)",
async function () {
  const bytes = W.buildCorpus().add.bytes;
  const result = await runCondition(bytes, {
    cycles: 20,
    recursive: true,
    reencodeOpts: { lowSaturation: true },
    useDelta: true
  });
  const topBytes = result.final.topBytes.slice(0, 5).map(e => e.byte);
  // None of the marker bytes (0xFF, 0xC0-0xCD) should be in top 5
  for (const b of topBytes) {
    if (b === 0xFF || (b >= 0xC0 && b <= 0xCF)) {
      throw new Error("delta encoding still saturating around marker 0x" +
        b.toString(16) + " in top 5: " +
        topBytes.map(x => "0x" + x.toString(16)).join(", "));
    }
  }
  // 0x00 and 0x01 are the most common WASM bytes; at least one must be in top 5
  if (topBytes.indexOf(0x00) < 0 && topBytes.indexOf(0x01) < 0) {
    throw new Error("delta encoding lost WASM signal: top 5 = " +
      topBytes.map(x => "0x" + x.toString(16)).join(", "));
  }
});

// ----------------------------------------------------------------------------
// 5.7.6.7: delta encoding preserves WASM rank correlation under recursion
// ----------------------------------------------------------------------------

test("5.7.6.7 delta encoding preserves WASM rank correlation (>= 0.7)",
async function () {
  const bytes = W.buildCorpus().add.bytes;
  const wasmA = A.analyze(bytes);
  const result = await runCondition(bytes, {
    cycles: 20,
    recursive: true,
    reencodeOpts: { lowSaturation: true },
    useDelta: true
  });
  const rc = SM.rankCorrelation(wasmA.topByteRanks, result.final.topBytes);
  if (rc === null) throw new Error("rank correlation undefined");
  if (rc < 0.7) {
    throw new Error("delta-encoding rank correlation " + rc.toFixed(3) + " < 0.7");
  }
});

// ----------------------------------------------------------------------------
// 5.7.6.8: recursive feedback with desaturation improves co-occurrence coverage
// over non-recursive baseline
// ----------------------------------------------------------------------------

test("5.7.6.8 recursive-delta improves co-occurrence coverage over baseline",
async function () {
  const bytes = W.buildCorpus().add.bytes;
  const wasmA = A.analyze(bytes);

  const baseline = await runCondition(bytes, { cycles: 20, recursive: false });
  const recursive = await runCondition(bytes, {
    cycles: 20,
    recursive: true,
    reencodeOpts: { lowSaturation: true },
    useDelta: true
  });

  const baseCov = SM.coOccurrenceCoverage(wasmA.topCoOccurrences,
    baseline.final.topCoOccurrences);
  const recCov = SM.coOccurrenceCoverage(wasmA.topCoOccurrences,
    recursive.final.topCoOccurrences);

  // Recursive-delta should match or exceed baseline coverage. This is the
  // load-bearing claim: recursive amplification with desaturation surfaces
  // more WASM structure than one-shot intake.
  if (recCov < baseCov) {
    throw new Error("recursive-delta coverage " + recCov.toFixed(3) +
      " < baseline " + baseCov.toFixed(3));
  }
});

// ----------------------------------------------------------------------------
// 5.7.6.9: determinism - same input + same encoding mode gives same final state
// ----------------------------------------------------------------------------

test("5.7.6.9 recursive-delta is deterministic across fresh instances",
async function () {
  const bytes = W.buildCorpus().add.bytes;
  const opts = {
    cycles: 15,
    recursive: true,
    reencodeOpts: { lowSaturation: true },
    useDelta: true
  };
  const a = await runCondition(bytes, opts);
  const b = await runCondition(bytes, opts);

  if (a.final.constraintCount !== b.final.constraintCount) {
    throw new Error("constraint count differs across fresh instances: " +
      a.final.constraintCount + " vs " + b.final.constraintCount);
  }
  if (Math.abs(a.final.reachState.scalarDelta - b.final.reachState.scalarDelta) > 1e-9) {
    throw new Error("scalar delta differs across fresh instances");
  }
  // Top byte rankings must match
  const aTop = a.final.topBytes.slice(0, 5).map(e => e.byte).join(",");
  const bTop = b.final.topBytes.slice(0, 5).map(e => e.byte).join(",");
  if (aTop !== bTop) {
    throw new Error("top byte rankings differ: " + aTop + " vs " + bTop);
  }
});

// ----------------------------------------------------------------------------
// 5.7.6.10: distinct inputs produce distinct recursive states
// ----------------------------------------------------------------------------

test("5.7.6.10 distinct WASM modules produce distinct recursive states",
async function () {
  const corpus = W.buildCorpus();
  const opts = {
    cycles: 15,
    recursive: true,
    reencodeOpts: { lowSaturation: true },
    useDelta: true
  };

  const states = {};
  for (const name of ["add", "fib", "multi"]) {
    states[name] = (await runCondition(corpus[name].bytes, opts)).final;
  }

  // Pairwise: each pair must differ on at least one structural metric
  const pairs = [["add", "fib"], ["add", "multi"], ["fib", "multi"]];
  for (const [a, b] of pairs) {
    const sa = states[a], sb = states[b];
    if (sa.constraintCount === sb.constraintCount &&
        sa.subcascades.count === sb.subcascades.count &&
        Math.abs(sa.reachState.scalarDelta - sb.reachState.scalarDelta) < 1e-9) {
      throw new Error(a + " and " + b + " produced identical recursive state");
    }
  }
});

// ----------------------------------------------------------------------------
// 5.7.6.11: recursive coupling holds across all corpus modules
// ----------------------------------------------------------------------------

test("5.7.6.11 recursive-delta works on all corpus modules without divergence",
async function () {
  const corpus = W.buildCorpus();
  const opts = {
    cycles: 15,
    recursive: true,
    reencodeOpts: { lowSaturation: true },
    useDelta: true
  };
  for (const name of ["add", "fib", "multi"]) {
    const result = await runCondition(corpus[name].bytes, opts);
    if (result.final.constraintCount > 500) {
      throw new Error(name + " constraint count unbounded: " +
        result.final.constraintCount);
    }
    if (result.final.reachState.scalarDelta < 1e-6) {
      throw new Error(name + " collapsed to delta=0");
    }
    if (result.final.subcascades.count < 1) {
      throw new Error(name + " has no sub-cascades after recursive feedback");
    }
  }
});

// ----------------------------------------------------------------------------
// 5.7.6.12: trajectory is monotonic-toward-plateau (sanity on convergence
// shape; constraint count grows then plateaus, not oscillates)
// ----------------------------------------------------------------------------

test("5.7.6.12 trajectory shape: grows then plateaus (no oscillation)",
async function () {
  const bytes = W.buildCorpus().add.bytes;
  const result = await runCondition(bytes, {
    cycles: 20,
    recursive: true,
    reencodeOpts: { lowSaturation: true },
    useDelta: true
  });

  // Compute first-difference of constraint count
  const counts = result.records.map(r => r.constraintCount);
  let oscillations = 0;
  for (let i = 2; i < counts.length; i++) {
    const d1 = counts[i - 1] - counts[i - 2];
    const d2 = counts[i] - counts[i - 1];
    // sign flip with non-trivial magnitude = oscillation
    if (d1 > 5 && d2 < -5) oscillations += 1;
    if (d1 < -5 && d2 > 5) oscillations += 1;
  }
  if (oscillations > 2) {
    throw new Error("trajectory has " + oscillations + " oscillations: " + counts.join(","));
  }
});

// ============================================================================
// runner
// ============================================================================

async function run() {
  let pass = 0, fail = 0;
  const failures = [];
  for (const t of tests) {
    try {
      await t.fn();
      console.log("  ok    " + t.name);
      pass += 1;
    } catch (e) {
      console.log("  FAIL  " + t.name);
      console.log("        " + (e && e.message || e));
      fail += 1;
      failures.push({ name: t.name, error: e && e.message || String(e) });
    }
  }
  console.log("");
  console.log(pass + "/" + tests.length + " tests passed");
  if (failures.length > 0) {
    console.log("");
    console.log("Failures:");
    for (const f of failures) {
      console.log("  " + f.name);
      console.log("    " + f.error);
    }
  }
  return { pass, fail, total: tests.length, failures };
}

if (require.main === module) {
  run().then(r => process.exit(r.fail === 0 ? 0 : 1));
}

module.exports = { run };
