# Phase 5.7 Unified Demo

The substrate IS the processor. This demo wires WGSL/WebGPU + IndexedDB + interactive input + the Phase 5.7 substrate stack into a single browser-runnable artifact and verifies all surfaces in tandem.

## Run the demo (browser)

Start any static HTTP server in this directory (HTTP origin is required for ES modules and WebGPU access):

```
python3 -m http.server 8000
```

Then open `http://localhost:8000/demo.html`.

The demo will:

1. Load the substrate modules (`field.js`, `constraint-compiler.js`, `cpu-oracle.js`, `er-engine.js`, `ct-engine.js`)
2. Initialize the ER engine with WebGPU; if WebGPU is unavailable, fall back to the CPU oracle (per SE-06 substrate independence). The header pill shows which runtime is active.
3. Open IndexedDB for persistence
4. Load the WASM corpus from Phase 5.7.5 (add / fib / multi)
5. Show alignment metrics live: substrate top-byte ranking next to WASM-spec ground-truth ranking, with Spearman correlation

Click `TRAIN ON SELECTED WASM` to feed the substrate. Click `SAVE TO INDEXEDDB` to persist state. Reload the page; the saved state survives. Click on a saved record to restore it. Type in the text input or click on the canvas to interact directly.

## Run the verification (programmatic)

```
node demo-verify.js
```

Uses Playwright to launch headless Chromium, load the demo, run an interaction sequence including a full page reload to prove IndexedDB persistence is real, and capture screenshots.

## What the verification confirms

22 checks across the demo's surfaces:

- All five module scripts load without error
- ER engine initialization completes (with either GPU or CPU runtime; both are SE-06 compliant)
- IndexedDB opens cleanly
- WASM corpus renders all 3 modules
- Train button drives the substrate (constraints grow from baseline)
- Alignment metric vs WASM ground truth populates and passes the Phase 5.7.5 threshold of Spearman 0.7
- Save creates an IndexedDB record
- **Page reload** then verify saved record is still in IndexedDB
- Load restores substrate state from IndexedDB across the reload
- Canvas click, text input, keyboard input all advance the substrate
- Tick (develop/correlate without external input) extends the trace
- Reset returns to fresh state
- No console errors, no page exceptions

A successful run prints `VERIFY OK - Phase 5.7 demo verified end-to-end` and saves two screenshots (`demo.before-reload.png`, `demo.final.png`).

## What this proves architecturally

Empirically, in a real browser:

- The Phase 5.7 substrate runs against real WebGPU shader code (when available) using the same code path that's CPU-tested in the 228-test Node regression, with the architecture's substrate-independence commitment ensuring identical evaluation semantics either way.
- IndexedDB-backed persistence works across page reloads. Substrate state encoded by `Field.serialize()` round-trips through real browser storage and restores byte-equivalent.
- The interactive input surface (clicks, keys, text, gestures) drives the substrate per F5/SE-09. Each interaction is an observation that deposits irreversible configuration change.
- The substrate's Phase 5.7.5 alignment property (substrate's top byte ranking matches WASM-spec byte frequency at Spearman >= 0.7) holds in a browser context, not just in the headless Node test harness.
- All this composes in a single artifact without any architectural commitment changing.

## File map

```
demo.html              The unified demo
demo-storage.js        IndexedDB-backed MediaStore
demo-verify.js         Playwright verification script

resolve-fresh.wgsl     Real WebGPU compute shader (used when GPU available)

field.js               Substrate Field state (1341 lines, unchanged from Phase 5.6)
constraint-compiler.js Constraint -> shader instruction compiler
cpu-oracle.js          Reference CPU evaluator matching the WGSL semantics
er-engine.js           ER engine: WebGPU or CPU fallback per SE-06
ct-engine.js           CT engine: input pipeline, promotion, settlement

playback-harness.html  Earlier Phase 5.7.4 harness
browser-verify.js      Playwright verification for playback-harness.html

PHASE_5_7_OBSERVATIONS.md         Empirical findings from substrate stack experiments
PHASE_5_7_2_3_4_OBSERVATIONS.md   Empirical findings from 5.7.2/.3/.4
```

## Test totals

- Node regression: 228/228 passing across 20 test files
- Static coupling: 9/9 passing
- In-browser verification: 22/22 checks passing including IndexedDB persistence across page reload

## Architectural commitments verified

F1, F4, F5, K1, M1, S2, X1, X2, SE-06, SE-08, SE-09 - all hold under the conditions tested. See PHASE_5_7_OBSERVATIONS.md for the empirical breakdown.
