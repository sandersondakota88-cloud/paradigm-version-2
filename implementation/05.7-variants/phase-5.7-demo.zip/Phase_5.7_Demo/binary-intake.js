// ============================================================================
// binary-intake.js  -  Binary stream input adapter (Phase 5.7)
// ============================================================================
//
// Per SE-08, sensor input enters at the rendering substrate as a feature
// stream. For Phase 5.7 / Layer 1, the "sensor" is a binary buffer (a WASM
// module, a media file, any byte sequence). This adapter converts byte
// streams into substrate-readable input tokens.
//
// Design choice: each byte becomes a hex-prefixed token (e.g., 0x41 -> "b41").
// The substrate's existing tokenizer and char-class predicates handle these
// as ordinary tokens. The substrate at Layer 1 doesn't need to know its
// input is "bytes" any more than it knows English text is "language" - it
// settles around whatever recurs.
//
// The hex prefix "b" is structurally consequential: it makes every byte token
// distinct from any text token (which won't have a "b" followed by exactly
// two hex digits in this systematic way). Layer 1's promotion thus settles
// purely around byte-level regularities.
//
// Three input modes, ranked by structural fidelity:
//
//   1. WINDOWED (default): bytes presented in fixed-size windows as tokens
//      that co-occur within the window. The substrate's co-occurrence
//      machinery (algorithm 22, K1 promotion) finds recurring byte patterns.
//
//   2. STREAMED: each byte presented as its own input event in order. The
//      substrate sees per-byte temporal succession; M1's vector delta tracks
//      different time scales over the byte stream.
//
//   3. STRUCTURED: bytes pre-grouped into structural units (e.g., WASM
//      sections) and each unit becomes one input event. Caller-driven; the
//      adapter doesn't know structure, the caller provides chunking.
//
// Per Phase 5.7's Layer 1 scope: WINDOWED is the default. STREAMED and
// STRUCTURED are available for experiments.
//
// ============================================================================

"use strict";

// ----------------------------------------------------------------------------
// Hex tokens: byte 0xNN -> "b<hex>"
// ----------------------------------------------------------------------------

const HEX_TOKENS = new Array(256);
for (let i = 0; i < 256; i++) {
  HEX_TOKENS[i] = "b" + i.toString(16).padStart(2, "0");
}

function byteToken(b) {
  return HEX_TOKENS[b & 0xFF];
}

// ----------------------------------------------------------------------------
// Byte-class hints: surface structural categories in the byte stream that
// might be useful for the substrate's char-class predicates beyond the
// hex-token mechanism.
//
// These are auxiliary tokens emitted alongside the main byte tokens. They
// give Layer 1 an additional structural signal without requiring it to
// learn byte-class structure from scratch.
// ----------------------------------------------------------------------------

const BYTE_CLASS = Object.freeze({
  NULL:       0x00,             // exactly 0x00
  CONTROL:    [0x01, 0x1F],     // 1..31 (control characters)
  PRINTABLE:  [0x20, 0x7E],     // 32..126 (ASCII printable)
  DEL:        0x7F,             // exactly 0x7F
  HIGH:       [0x80, 0xFF]      // high-bit bytes
});

function classOf(b) {
  if (b === 0x00) return "null";
  if (b >= 0x01 && b <= 0x1F) return "ctrl";
  if (b >= 0x20 && b <= 0x7E) return "print";
  if (b === 0x7F) return "del";
  return "high";  // 0x80..0xFF
}

// ----------------------------------------------------------------------------
// WINDOWED input: present bytes in fixed-size windows. Each window becomes
// one input event consisting of W byte-tokens.
//
// opts:
//   windowSize   (default 16) -- bytes per input event
//   overlap      (default 0)  -- bytes shared with the previous window
//   includeClass (default true) -- emit class tokens alongside hex tokens
//
// Returns an array of input strings, each ready for substrate.input(text).
// ----------------------------------------------------------------------------

function windowedInputs(bytes, opts) {
  opts = opts || {};
  const W = (opts.windowSize | 0) || 16;
  const overlap = (opts.overlap | 0) || 0;
  const includeClass = opts.includeClass !== false;
  const stride = Math.max(1, W - overlap);

  if (W <= 0) throw new Error("binary-intake: windowSize must be > 0");
  if (overlap >= W) throw new Error("binary-intake: overlap must be < windowSize");

  const out = [];
  for (let i = 0; i + W <= bytes.length; i += stride) {
    const tokens = [];
    let lastClass = null;
    for (let j = 0; j < W; j++) {
      const b = bytes[i + j] & 0xFF;
      tokens.push(byteToken(b));
      if (includeClass) {
        const cls = classOf(b);
        // Only emit class tokens when the class changes - reduces noise
        // while still letting Layer 1 see class transitions.
        if (cls !== lastClass) {
          tokens.push("c" + cls);
          lastClass = cls;
        }
      }
    }
    out.push(tokens.join(" "));
  }
  return out;
}

// ----------------------------------------------------------------------------
// STREAMED input: one byte per input event, in order.
//
// opts:
//   includeClass (default true) -- emit class with each byte
// ----------------------------------------------------------------------------

function streamedInputs(bytes, opts) {
  opts = opts || {};
  const includeClass = opts.includeClass !== false;
  const out = [];
  for (let i = 0; i < bytes.length; i++) {
    const b = bytes[i] & 0xFF;
    if (includeClass) {
      out.push(byteToken(b) + " c" + classOf(b));
    } else {
      out.push(byteToken(b));
    }
  }
  return out;
}

// ----------------------------------------------------------------------------
// STRUCTURED input: caller pre-chunks bytes into structural units.
//
// chunks: array of Uint8Array or array of byte arrays. Each chunk becomes
// one input event with all its bytes as space-separated hex tokens.
//
// Use case: WASM section boundaries are known; pass each section as its
// own chunk. Layer 1 sees one "input" per section, with the section's
// bytes as co-occurring tokens.
// ----------------------------------------------------------------------------

function structuredInputs(chunks, opts) {
  opts = opts || {};
  const includeClass = opts.includeClass !== false;
  const out = [];
  for (const chunk of chunks) {
    const tokens = [];
    let lastClass = null;
    for (let i = 0; i < chunk.length; i++) {
      const b = chunk[i] & 0xFF;
      tokens.push(byteToken(b));
      if (includeClass) {
        const cls = classOf(b);
        if (cls !== lastClass) {
          tokens.push("c" + cls);
          lastClass = cls;
        }
      }
    }
    out.push(tokens.join(" "));
  }
  return out;
}

// ----------------------------------------------------------------------------
// Drive a substrate with binary input
//
// substrate: instance from substrate-instance.js
// bytes: Uint8Array or array of bytes
// opts: passed through to the chosen input mode
// ----------------------------------------------------------------------------

async function feedBinary(substrate, bytes, opts) {
  opts = opts || {};
  const mode = opts.mode || "windowed";
  let inputs;
  if (mode === "windowed") inputs = windowedInputs(bytes, opts);
  else if (mode === "streamed") inputs = streamedInputs(bytes, opts);
  else if (mode === "structured") inputs = structuredInputs(bytes, opts);
  else throw new Error("binary-intake: unknown mode '" + mode + "'");

  for (const input of inputs) {
    await substrate.input(input);
  }
  return inputs.length;
}

// ----------------------------------------------------------------------------
// Diagnostic: produce a summary of the binary stream to compare against
// what the substrate finds. This is observation-side only; it doesn't
// change substrate behavior.
// ----------------------------------------------------------------------------

function describeBytes(bytes) {
  const counts = new Array(256).fill(0);
  const classCounts = { null: 0, ctrl: 0, print: 0, del: 0, high: 0 };
  for (let i = 0; i < bytes.length; i++) {
    const b = bytes[i] & 0xFF;
    counts[b] += 1;
    classCounts[classOf(b)] += 1;
  }
  // Top byte values
  const top = counts.map((n, b) => ({ byte: b, n: n }))
    .filter(e => e.n > 0)
    .sort((a, b) => b.n - a.n)
    .slice(0, 10);
  return {
    length: bytes.length,
    classCounts: classCounts,
    topBytes: top.map(e => ({ token: byteToken(e.byte), n: e.n }))
  };
}

module.exports = {
  byteToken: byteToken,
  classOf: classOf,
  windowedInputs: windowedInputs,
  streamedInputs: streamedInputs,
  structuredInputs: structuredInputs,
  feedBinary: feedBinary,
  describeBytes: describeBytes
};
