// ============================================================================
// output-renderer.js  -  Substrate output port (Phase 5.7)
// ============================================================================
//
// Per the substrate stack architecture (Phase 5.7+), each layer's output is
// a set of CSS custom properties on a designated DOM node. The next layer's
// SE-08 intake reads those properties via getComputedStyle().
//
// In headless Node, no DOM exists. This module provides a minimal node-like
// object that exposes the same setProperty / getPropertyValue interface the
// browser cascade would, so Layer 1 and Layer 2 can be tested and run on
// the server before any browser harness is built.
//
// What gets written:
//
//   --substrate-id          : instance id
//   --step                  : current substrate step
//   --scalar-delta          : current canonical scalar delta
//   --fast-delta            : fast layer delta
//   --slow-delta            : slow layer delta
//   --fast-mod              : fast modulation accumulator
//   --slow-mod              : slow modulation accumulator
//   --rat-count             : ratification count
//   --named-count           : naming count
//   --constraint-count      : total constraints
//   --subcascade-count      : total sub-cascades
//
//   per-constraint:
//     --c-N-id, --c-N-kind, --c-N-uses, --c-N-weight
//
//   per-subcascade:
//     --sc-N-id, --sc-N-named, --sc-N-delta
//
// Per-constraint and per-subcascade properties are bounded; default
// limits are 32 constraints and 16 sub-cascades to keep the output port
// manageable. The substrate's full state is always available via
// substrate.getState() for diagnostic purposes; the output port is the
// part that's structurally exposed for Layer 2 consumption.
//
// ============================================================================

"use strict";

// ----------------------------------------------------------------------------
// Minimal DOM-like node for headless use
// ----------------------------------------------------------------------------

function createOutputNode() {
  const props = Object.create(null);
  return {
    style: {
      setProperty(name, value) {
        props[name] = String(value);
      },
      getPropertyValue(name) {
        return props[name] || "";
      },
      removeProperty(name) {
        const v = props[name] || "";
        delete props[name];
        return v;
      }
    },
    // Browser-mirror: in real DOM, getComputedStyle returns a map of
    // custom properties. Here we expose them directly for testing.
    getAllProperties() {
      return Object.assign({}, props);
    }
  };
}

// ----------------------------------------------------------------------------
// Render substrate state to output node
//
// substrate: instance from substrate-instance.js
// node: output node from createOutputNode() (or a real DOM node in browser)
// opts:
//   maxConstraints (default 32) -- how many constraint slots to expose
//   maxSubcascades (default 16) -- how many subcascade slots to expose
//   includeMeta (default true)  -- emit --substrate-id and similar metadata
// ----------------------------------------------------------------------------

function render(substrate, node, opts) {
  opts = opts || {};
  const maxC = (opts.maxConstraints | 0) || 32;
  const maxS = (opts.maxSubcascades | 0) || 16;
  const includeMeta = opts.includeMeta !== false;

  const state = substrate.getState();

  if (includeMeta) {
    node.style.setProperty("--substrate-id", state.id);
    node.style.setProperty("--step", state.step);
  }

  // Scalar fields
  node.style.setProperty("--scalar-delta", fmt(state.scalarDelta));
  node.style.setProperty("--fast-delta", fmt(state.fastDelta));
  node.style.setProperty("--slow-delta", fmt(state.slowDelta));
  node.style.setProperty("--exec-scalar-delta", fmt(state.execScalarDelta));
  node.style.setProperty("--exec-fast-delta", fmt(state.execFastDelta));
  node.style.setProperty("--exec-slow-delta", fmt(state.execSlowDelta));
  node.style.setProperty("--fast-mod", fmt(state.fastMod));
  node.style.setProperty("--slow-mod", fmt(state.slowMod));
  node.style.setProperty("--rat-count", state.ratCount);
  node.style.setProperty("--named-count", state.namedCount);
  node.style.setProperty("--input-count", state.inputCount);
  node.style.setProperty("--constraint-count", state.constraintCount);
  node.style.setProperty("--subcascade-count", state.subcascades.length);
  node.style.setProperty("--trace-length", state.traceLength);

  // Per-constraint slots. Slot 0 is always the seed (per F1/X1: the seed
  // is structurally distinct and must always be visible to Layer 2). Slots
  // 1..maxC-1 are the top remaining constraints by weight, ties broken by
  // most-recent use.
  const seedC = state.constraints.find(c => c.kind === "seed");
  const nonSeed = state.constraints.filter(c => c.kind !== "seed");
  const sortedNonSeed = nonSeed.sort(function (a, b) {
    if (b.weight !== a.weight) return b.weight - a.weight;
    return b.lastUsed - a.lastUsed;
  });

  // Clear any old slots first to avoid stale data
  for (let i = 0; i < maxC; i++) {
    node.style.removeProperty("--c-" + i + "-id");
    node.style.removeProperty("--c-" + i + "-kind");
    node.style.removeProperty("--c-" + i + "-uses");
    node.style.removeProperty("--c-" + i + "-weight");
    node.style.removeProperty("--c-" + i + "-last-used");
  }

  // Slot 0: seed (if present)
  let slotIdx = 0;
  if (seedC && maxC > 0) {
    node.style.setProperty("--c-0-id", seedC.id);
    node.style.setProperty("--c-0-kind", seedC.kind);
    node.style.setProperty("--c-0-uses", seedC.uses);
    node.style.setProperty("--c-0-weight", fmt(seedC.weight));
    node.style.setProperty("--c-0-last-used", seedC.lastUsed);
    slotIdx = 1;
  }

  // Slots 1+: top non-seed constraints by weight/recency
  for (let i = 0; i < sortedNonSeed.length && slotIdx < maxC; i++, slotIdx++) {
    const c = sortedNonSeed[i];
    node.style.setProperty("--c-" + slotIdx + "-id", c.id);
    node.style.setProperty("--c-" + slotIdx + "-kind", c.kind);
    node.style.setProperty("--c-" + slotIdx + "-uses", c.uses);
    node.style.setProperty("--c-" + slotIdx + "-weight", fmt(c.weight));
    node.style.setProperty("--c-" + slotIdx + "-last-used", c.lastUsed);
  }

  // Per-subcascade slots
  for (let i = 0; i < maxS; i++) {
    node.style.removeProperty("--sc-" + i + "-id");
    node.style.removeProperty("--sc-" + i + "-named");
    node.style.removeProperty("--sc-" + i + "-delta");
  }

  for (let i = 0; i < Math.min(maxS, state.subcascades.length); i++) {
    const sc = state.subcascades[i];
    node.style.setProperty("--sc-" + i + "-id", sc.id);
    node.style.setProperty("--sc-" + i + "-named", sc.namedCount);
    node.style.setProperty("--sc-" + i + "-delta", fmt(sc.localDelta));
  }

  // Class-distribution: aggregate counts of constraints by kind. Layer 2's
  // intake might find this useful as a coarse signal.
  const kindCounts = Object.create(null);
  for (const c of state.constraints) {
    kindCounts[c.kind] = (kindCounts[c.kind] || 0) + 1;
  }
  for (const k of ["seed", "derived", "predictive", "meta", "compound", "ratified"]) {
    node.style.setProperty("--kind-" + k + "-count", kindCounts[k] || 0);
  }

  return node;
}

// ----------------------------------------------------------------------------
// Format a number for CSS custom property output. CSS custom properties are
// strings; floats need bounded precision to keep the output diff-stable.
// ----------------------------------------------------------------------------

function fmt(n) {
  if (typeof n !== "number" || !isFinite(n)) return "0";
  // 6 significant digits is enough for the substrate's dynamics; trims
  // trailing-zero noise that would make output diff-unstable.
  if (Number.isInteger(n)) return String(n);
  return Number(n.toPrecision(6)).toString();
}

// ----------------------------------------------------------------------------
// Diagnostic: dump all properties as a sorted key-value list. Useful for
// visual inspection of what's on the output port.
// ----------------------------------------------------------------------------

function dumpNode(node) {
  const all = node.getAllProperties ? node.getAllProperties() : {};
  const keys = Object.keys(all).sort();
  return keys.map(k => k + " = " + all[k]).join("\n");
}

module.exports = {
  createOutputNode: createOutputNode,
  render: render,
  dumpNode: dumpNode
};
