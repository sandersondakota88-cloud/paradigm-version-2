﻿# Phase 11 Source-Substrate (Standalone)

Self-contained snapshot of the Phase 11 build. Six phases complete; no
external dependencies beyond Node (for the static server) and a modern
browser.

## Run

    cd <this-dir>
    node implementation/11-source-substrate/serve.js

Open http://localhost:8080/ in any browser. The default route is
source-nav.html.

## Try in this order

1. Pick a corpus from the dropdown (field.js / vlan-sync / TodoMVC JS-only
   / TodoMVC three-language) and click BOOT LATTICE.
2. Once ready, click DOWNLOAD TRAJECTORY TSV to capture metrics.
3. Click DEPOSIT CSS to emit the substrate's settled state as a stylesheet.
4. Click DEPOSIT PROBE HTML to emit the verifier page.
5. Rename the downloaded CSS to drop its timestamp (so it matches the
   probe page's href), put both files in the same directory, open the
   probe HTML, click RESOLVE FULL JOINT COORD SPACE.

The browser's native CSS cascade should resolve the substrate's
understanding byte-identically to the in-app resolution.

## Pre-generated artifacts

implementation/11-source-substrate/depositions/ contains a CSS
deposition + matching probe HTML from a TodoMVC three-language run
(matched=9530, unresolved=2970, lattice-scope delta=0.2376). Open the
probe HTML in any browser to verify directly without running the full
ingestion.

## Read the build

implementation/11-source-substrate/PLAN.md is the master plan and live
status. Per-phase trajectory analysis in the *.md files alongside.
